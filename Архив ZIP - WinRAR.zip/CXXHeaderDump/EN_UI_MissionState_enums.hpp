namespace EN_UI_MissionState {
    enum Type {
        NewEnumerator0 = 0,
        NewEnumerator1 = 1,
        NewEnumerator2 = 2,
        EN_UI_MAX = 3,
    };
}

