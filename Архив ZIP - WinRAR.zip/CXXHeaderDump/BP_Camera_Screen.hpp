#ifndef UE4SS_SDK_BP_Camera_Screen_HPP
#define UE4SS_SDK_BP_Camera_Screen_HPP

class ABP_Camera_Screen_C : public AActor
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x0220 (size: 0x8)
    class UStaticMeshComponent* StaticMesh;                                           // 0x0228 (size: 0x8)
    class USceneComponent* DefaultSceneRoot;                                          // 0x0230 (size: 0x8)
    class UMaterialInstanceDynamic* DynamicTV;                                        // 0x0238 (size: 0x8)
    int32 TVIndex;                                                                    // 0x0240 (size: 0x4)
    class UMaterialInstance* Material;                                                // 0x0248 (size: 0x8)
    class UTextureRenderTarget2D* RenderTarget;                                       // 0x0250 (size: 0x8)
    bool IsCorrect;                                                                   // 0x0258 (size: 0x1)
    bool UsePlaceholder;                                                              // 0x0259 (size: 0x1)
    bool ShouldReset;                                                                 // 0x025A (size: 0x1)
    class UTexture* Texture;                                                          // 0x0260 (size: 0x8)

    void SetFirstTexture(class UTexture*& Texture);
    void OnRep_ShouldReset();
    void OnRep_UsePlaceholder();
    void OnRep_IsCorrect();
    void ReceiveBeginPlay();
    void ExecuteUbergraph_BP_Camera_Screen(int32 EntryPoint);
}; // Size: 0x268

#endif
