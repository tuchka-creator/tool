#ifndef UE4SS_SDK_BPI_UserInterface_HPP
#define UE4SS_SDK_BPI_UserInterface_HPP

class IBPI_UserInterface_C : public IInterface
{

    void ToggleEnabled(bool IsEnabled);
    void ToggleHover(bool IsHovered);
    void ToggleFocus(bool IsFocused);
}; // Size: 0x28

#endif
