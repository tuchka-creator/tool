#ifndef UE4SS_SDK_HUD_DroppedItem_HPP
#define UE4SS_SDK_HUD_DroppedItem_HPP

class UHUD_DroppedItem_C : public UUserWidget
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x0270 (size: 0x8)
    class UWidgetAnimation* SpawnAnim;                                                // 0x0278 (size: 0x8)
    class UTextBlock* ItemName;                                                       // 0x0280 (size: 0x8)
    class UW_Input_Icon_C* W_Input_Icon;                                              // 0x0288 (size: 0x8)

    void Construct();
    void ExecuteUbergraph_HUD_DroppedItem(int32 EntryPoint);
}; // Size: 0x290

#endif
