#ifndef UE4SS_SDK_InteractWithGrass_BP_HPP
#define UE4SS_SDK_InteractWithGrass_BP_HPP

class UInteractWithGrass_BP_C : public USceneComponent
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x0200 (size: 0x8)
    bool useDisplacementInteraction;                                                  // 0x0208 (size: 0x1)
    TEnumAsByte<GrassInteractionType::Type> howToInteract;                            // 0x0209 (size: 0x1)
    float checkRadius;                                                                // 0x020C (size: 0x4)
    float checkInterval;                                                              // 0x0210 (size: 0x4)
    float interactionCullDistance;                                                    // 0x0214 (size: 0x4)
    bool alwaysSimulate;                                                              // 0x0218 (size: 0x1)
    float trample_BendAngle;                                                          // 0x021C (size: 0x4)
    float trample_Z-Scale;                                                            // 0x0220 (size: 0x4)
    float trample_BendDuration;                                                       // 0x0224 (size: 0x4)
    int32 InstanceIndex;                                                              // 0x0228 (size: 0x4)
    class AInteractiveGrassManager_BP_C* grassManager;                                // 0x0230 (size: 0x8)
    class UINTERACTIVE_FoliageComp_BP_C* InteractiveFoliageComp;                      // 0x0238 (size: 0x8)
    bool hasAssignedInteractionChannel;                                               // 0x0240 (size: 0x1)
    int32 takenInteractionChannel;                                                    // 0x0244 (size: 0x4)
    FName interactionLocationChannelName;                                             // 0x0248 (size: 0x8)
    FName interactionRadiusChannelName;                                               // 0x0250 (size: 0x8)
    FName interactionStrengthChannelName;                                             // 0x0258 (size: 0x8)
    bool useMaterialInteraction;                                                      // 0x0260 (size: 0x1)
    float materialEffectRadius;                                                       // 0x0264 (size: 0x4)
    float materialEffectStrength;                                                     // 0x0268 (size: 0x4)
    float matInteractionCullDistance;                                                 // 0x026C (size: 0x4)
    FTimerHandle timer_UpdateMatInterParam;                                           // 0x0270 (size: 0x8)
    bool isForPrioritizedActor;                                                       // 0x0278 (size: 0x1)
    bool trample_IgnoreFoliageTypeWeights;                                            // 0x0279 (size: 0x1)
    FTimerHandle timer_CheckNearbyGrass;                                              // 0x0280 (size: 0x8)
    float BendAwayStrength;                                                           // 0x0288 (size: 0x4)
    float BendAwayZ_Offset;                                                           // 0x028C (size: 0x4)
    float BendAwayDuration;                                                           // 0x0290 (size: 0x4)
    bool BendAway_IgnoreFoliageTypeWeights;                                           // 0x0294 (size: 0x1)
    float calculatedTrampleBendAngle;                                                 // 0x0298 (size: 0x4)
    float calculatedTrample_Z-Scale;                                                  // 0x029C (size: 0x4)
    float calculatedTrampleBendDuration;                                              // 0x02A0 (size: 0x4)
    bool isUsingDispInteraction;                                                      // 0x02A4 (size: 0x1)
    TArray<class AInteractiveFoliageChunk_BP_C*> nearInterFoliageChunks;              // 0x02A8 (size: 0x10)
    FVector previousCheckedLocation;                                                  // 0x02B8 (size: 0xC)
    TArray<class AInteractiveFoliageChunk_BP_C*> chunksToDeactivate;                  // 0x02C8 (size: 0x10)
    bool skipVelocityCheck;                                                           // 0x02D8 (size: 0x1)
    TArray<int32> detectedInstances;                                                  // 0x02E0 (size: 0x10)
    FTimerHandle timer_UpdateMatInterParam_MainActor;                                 // 0x02F0 (size: 0x8)
    FTimerHandle timer_DetectNearbyComponents;                                        // 0x02F8 (size: 0x8)
    FTimerHandle timer_CheckIfComponentsStillNear;                                    // 0x0300 (size: 0x8)
    bool componentTurnedOFF;                                                          // 0x0308 (size: 0x1)
    bool startTurnedOFF;                                                              // 0x0309 (size: 0x1)
    bool useMaxDistanceFromInstance;                                                  // 0x030A (size: 0x1)
    float maxDistanceFromInstance;                                                    // 0x030C (size: 0x4)
    int32 CurrentIndex;                                                               // 0x0310 (size: 0x4)
    int32 LastIndex;                                                                  // 0x0314 (size: 0x4)
    class UINTERACTIVE_FoliageComp_BP_C* start_Component;                             // 0x0318 (size: 0x8)
    FVector Vector;                                                                   // 0x0320 (size: 0xC)
    FVector newPrevOffset;                                                            // 0x032C (size: 0xC)
    float StartTime;                                                                  // 0x0338 (size: 0x4)
    float StartUnDeformSpeed;                                                         // 0x033C (size: 0x4)

    void IsInDistanceToViewTarget(float inDistance, bool& isInDistance, float& currentDistance);
    void ReceiveBeginPlay();
    void CheckNearbyGrass();
    void FreeUpInteractionChannel();
    void OnOwnerDestroyed(class AActor* DestroyedActor);
    void CheckIfShould_ENABLE_MatInteraction();
    void CheckIfShould_DISABLE_MatInteraction();
    void UpdateMatInteractionParam();
    void UpdateMatInterParamForMainActor();
    void CheckIfShouldTurn_ON_DispInteraction();
    void CheckIfShouldTurn_OFF_DispInteraction();
    void CheckIfComponentsStillNear();
    void DetectNearbyComponents();
    void TurnOFF();
    void TurnON();
    void Start Interacting();
    void ExecuteUbergraph_InteractWithGrass_BP(int32 EntryPoint);
}; // Size: 0x340

#endif
