#ifndef UE4SS_SDK_BP_Storm_Volume_HPP
#define UE4SS_SDK_BP_Storm_Volume_HPP

class ABP_Storm_Volume_C : public ATriggerBox
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x0228 (size: 0x8)
    class UAudioComponent* Audio;                                                     // 0x0230 (size: 0x8)
    class ABP_Ocean_Manager_C* OceanManager;                                          // 0x0238 (size: 0x8)
    class ABP_Lighthouse_C* Lighthouse;                                               // 0x0240 (size: 0x8)

    void ReceiveActorBeginOverlap(class AActor* OtherActor);
    void ReceiveActorEndOverlap(class AActor* OtherActor);
    void StartRising();
    void StopRising();
    void ResetRising();
    void ResetStop();
    void ExecuteUbergraph_BP_Storm_Volume(int32 EntryPoint);
}; // Size: 0x248

#endif
