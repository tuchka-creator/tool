#ifndef UE4SS_SDK_BP_EventManager_HPP
#define UE4SS_SDK_BP_EventManager_HPP

class ABP_EventManager_C : public AActor
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x0220 (size: 0x8)
    class USceneComponent* DefaultSceneRoot;                                          // 0x0228 (size: 0x8)
    TArray<FS_EventActor> EventActors;                                                // 0x0230 (size: 0x10)
    TArray<class AStaticMeshActor*> SpawnedActors;                                    // 0x0240 (size: 0x10)

    void ReceiveBeginPlay();
    void OnEventLoaded(EFancyEventType EventType);
    void ToggleEvent(bool Enable);
    void ExecuteUbergraph_BP_EventManager(int32 EntryPoint);
}; // Size: 0x250

#endif
