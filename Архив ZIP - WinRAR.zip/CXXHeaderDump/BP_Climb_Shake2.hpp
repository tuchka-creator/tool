#ifndef UE4SS_SDK_BP_Climb_Shake2_HPP
#define UE4SS_SDK_BP_Climb_Shake2_HPP

class UBP_Climb_Shake2_C : public UMatineeCameraShake
{
}; // Size: 0x1B0

#endif
