#ifndef UE4SS_SDK_AIC_Hound_HPP
#define UE4SS_SDK_AIC_Hound_HPP

class AAIC_Hound_C : public AAIController
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x0328 (size: 0x8)
    class UPawnSensingComponent* PawnSensing;                                         // 0x0330 (size: 0x8)
    FName CanSeeKey;                                                                  // 0x0338 (size: 0x8)
    FName Target;                                                                     // 0x0340 (size: 0x8)
    FName IsRetreated;                                                                // 0x0348 (size: 0x8)
    FName IsWarning;                                                                  // 0x0350 (size: 0x8)
    float DelayAmount;                                                                // 0x0358 (size: 0x4)

    void Setup AI(class UBehaviorTree* BTAsset);
    void BndEvt__Bacteria_AIC_PawnSensing_K2Node_ComponentBoundEvent_0_SeePawnDelegate__DelegateSignature(class APawn* Pawn);
    void Retreat();
    void TriggerAggressive(class ABPCharacter_Demo_C* Target);
    void BndEvt__AIC_Hound_PawnSensing_K2Node_ComponentBoundEvent_1_HearNoiseDelegate__DelegateSignature(class APawn* Instigator, const FVector& Location, float Volume);
    void WarnPlayer(class ABPCharacter_Demo_C* Target);
    void ResetAggressive();
    void ResetFlashlightCheck();
    void ExecuteUbergraph_AIC_Hound(int32 EntryPoint);
}; // Size: 0x35C

#endif
