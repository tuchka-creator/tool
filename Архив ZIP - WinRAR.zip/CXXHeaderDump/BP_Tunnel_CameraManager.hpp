#ifndef UE4SS_SDK_BP_Tunnel_CameraManager_HPP
#define UE4SS_SDK_BP_Tunnel_CameraManager_HPP

class ABP_Tunnel_CameraManager_C : public AActor
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x0220 (size: 0x8)
    class USceneComponent* DefaultSceneRoot;                                          // 0x0228 (size: 0x8)
    TArray<class ABP_Camera_Screen_C*> Cameras;                                       // 0x0230 (size: 0x10)
    float MaxPictureDistance;                                                         // 0x0240 (size: 0x4)
    int32 CurrentIndex;                                                               // 0x0244 (size: 0x4)
    TArray<FS_CameraTarget> CameraTargets;                                            // 0x0248 (size: 0x10)
    class ABP_Ceiling_Gate_C* ExitGate;                                               // 0x0258 (size: 0x8)
    class ABP_Elevator_C* Elevator;                                                   // 0x0260 (size: 0x8)
    int32 NumPlayers;                                                                 // 0x0268 (size: 0x4)
    class ABP_Photo_Image_C* FirstImage;                                              // 0x0270 (size: 0x8)

    void CheckTargets(TArray<class AActor*>& Targets, class AFancyCharacter* Player, bool& Completed);
    void CheckPlayers();
    void OnRep_CurrentIndex();
    void Set Prop(TSubclassOf<class AActor> Actor, int32 ObjectsNeeded);
    void CheckPhotograph(class AFancyCharacter* Player);
    void ReceiveBeginPlay();
    void SetComplete();
    void UpdatePlayers();
    void ExecuteUbergraph_BP_Tunnel_CameraManager(int32 EntryPoint);
}; // Size: 0x278

#endif
