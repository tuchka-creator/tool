#ifndef UE4SS_SDK_BP_RopeZone_HPP
#define UE4SS_SDK_BP_RopeZone_HPP

class ABP_RopeZone_C : public AInteractableActor
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x0248 (size: 0x8)
    class USceneComponent* Offset;                                                    // 0x0250 (size: 0x8)
    class UStaticMeshComponent* Rope;                                                 // 0x0258 (size: 0x8)
    float MoveUp_Alpha_F32F04094CB5C4ECEC5706AB2379D307;                              // 0x0260 (size: 0x4)
    TEnumAsByte<ETimelineDirection::Type> MoveUp__Direction_F32F04094CB5C4ECEC5706AB2379D307; // 0x0264 (size: 0x1)
    class UTimelineComponent* MoveUp;                                                 // 0x0268 (size: 0x8)
    FTransform TargetTransform;                                                       // 0x0270 (size: 0x30)
    FTransform StartingTransform;                                                     // 0x02A0 (size: 0x30)
    bool DidAnimate;                                                                  // 0x02D0 (size: 0x1)
    class ABPCharacter_Demo_C* ClimbingPlayer;                                        // 0x02D8 (size: 0x8)
    class AActor* RopeHolder;                                                         // 0x02E0 (size: 0x8)

    void MoveUp__FinishedFunc();
    void MoveUp__UpdateFunc();
    void OnActorUsed(class ACharacter* Character);
    void ReceiveDestroyed();
    void TeleportPlayer();
    void ReceiveBeginPlay();
    void StopClimb();
    void ExecuteUbergraph_BP_RopeZone(int32 EntryPoint);
}; // Size: 0x2E8

#endif
