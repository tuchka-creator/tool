#ifndef UE4SS_SDK_BP_FallingPlank_HPP
#define UE4SS_SDK_BP_FallingPlank_HPP

class ABP_FallingPlank_C : public AActor
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x0220 (size: 0x8)
    class USceneComponent* CableStart;                                                // 0x0228 (size: 0x8)
    class UCableComponent* Cable02;                                                   // 0x0230 (size: 0x8)
    class UCableComponent* Cable01;                                                   // 0x0238 (size: 0x8)
    class USceneComponent* CableEnd;                                                  // 0x0240 (size: 0x8)
    class UStaticMeshComponent* PlankMesh;                                            // 0x0248 (size: 0x8)
    class USceneComponent* Scene;                                                     // 0x0250 (size: 0x8)
    bool DidFall;                                                                     // 0x0258 (size: 0x1)
    bool ContinueSimulate;                                                            // 0x0259 (size: 0x1)
    float SoundDelay;                                                                 // 0x025C (size: 0x4)
    FVector SoundLocation;                                                            // 0x0260 (size: 0xC)
    float FallDelay;                                                                  // 0x026C (size: 0x4)

    void OnRep_DidFall();
    void PlankFall();
    void StopPhysics();
    void ResetPhysics();
    void BndEvt__BP_FallingPlank_PlankMesh_K2Node_ComponentBoundEvent_1_ComponentHitSignature__DelegateSignature(class UPrimitiveComponent* HitComponent, class AActor* OtherActor, class UPrimitiveComponent* OtherComp, FVector NormalImpulse, const FHitResult& Hit);
    void MC_ImpactSound(FVector Location);
    void ExecuteUbergraph_BP_FallingPlank(int32 EntryPoint);
}; // Size: 0x270

#endif
