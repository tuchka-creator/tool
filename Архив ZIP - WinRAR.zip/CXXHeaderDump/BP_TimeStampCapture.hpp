#ifndef UE4SS_SDK_BP_TimeStampCapture_HPP
#define UE4SS_SDK_BP_TimeStampCapture_HPP

class ABP_TimeStampCapture_C : public AActor
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x0220 (size: 0x8)
    class UStaticMeshComponent* Plane;                                                // 0x0228 (size: 0x8)
    class USceneComponent* DefaultSceneRoot;                                          // 0x0230 (size: 0x8)
    class UTextureRenderTarget2D* TimeStampRenderTarget;                              // 0x0238 (size: 0x8)
    class UMaterialInstanceDynamic* MatInstance;                                      // 0x0240 (size: 0x8)

    void ReceiveBeginPlay();
    void Test();
    void ExecuteUbergraph_BP_TimeStampCapture(int32 EntryPoint);
}; // Size: 0x248

#endif
