enum class EAxleType {
    Undefined = 0,
    Front = 1,
    Rear = 2,
    EAxleType_MAX = 3,
};

enum class ESteeringType {
    SingleAngle = 0,
    AngleRatio = 1,
    Ackermann = 2,
    ESteeringType_MAX = 3,
};

enum class ESweepShape {
    Raycast = 0,
    Spherecast = 1,
    Shapecast = 2,
    ESweepShape_MAX = 3,
};

enum class ESweepType {
    SimpleSweep = 0,
    ComplexSweep = 1,
    ESweepType_MAX = 2,
};

enum class EVehicleAerofoilType {
    Fixed = 0,
    Wing = 1,
    Rudder = 2,
    Elevator = 3,
    EVehicleAerofoilType_MAX = 4,
};

enum class EVehicleDifferential {
    AllWheelDrive = 0,
    FrontWheelDrive = 1,
    RearWheelDrive = 2,
    EVehicleDifferential_MAX = 3,
};

enum class EVehicleThrustType {
    Fixed = 0,
    Wing = 1,
    Rudder = 2,
    Elevator = 3,
    EVehicleThrustType_MAX = 4,
};

