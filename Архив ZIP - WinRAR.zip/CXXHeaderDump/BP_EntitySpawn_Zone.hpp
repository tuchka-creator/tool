#ifndef UE4SS_SDK_BP_EntitySpawn_Zone_HPP
#define UE4SS_SDK_BP_EntitySpawn_Zone_HPP

class ABP_EntitySpawn_Zone_C : public ATriggerBox
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x0228 (size: 0x8)
    class UBoxComponent* ClimbBox;                                                    // 0x0230 (size: 0x8)
    TArray<FString> FallenPlayers;                                                    // 0x0238 (size: 0x10)
    class ABacteria_BP_C* Bacteria;                                                   // 0x0248 (size: 0x8)

    void BndEvt__BP_EntitySpawn_Zone_CollisionComponent_K2Node_ComponentBoundEvent_0_ComponentBeginOverlapSignature__DelegateSignature(class UPrimitiveComponent* OverlappedComponent, class AActor* OtherActor, class UPrimitiveComponent* OtherComp, int32 OtherBodyIndex, bool bFromSweep, const FHitResult& SweepResult);
    void BndEvt__BP_EntitySpawn_Zone_Box_K2Node_ComponentBoundEvent_2_ComponentBeginOverlapSignature__DelegateSignature(class UPrimitiveComponent* OverlappedComponent, class AActor* OtherActor, class UPrimitiveComponent* OtherComp, int32 OtherBodyIndex, bool bFromSweep, const FHitResult& SweepResult);
    void SpawnEntity();
    void ExecuteUbergraph_BP_EntitySpawn_Zone(int32 EntryPoint);
}; // Size: 0x250

#endif
