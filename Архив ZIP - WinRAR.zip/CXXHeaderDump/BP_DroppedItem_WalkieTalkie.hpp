#ifndef UE4SS_SDK_BP_DroppedItem_WalkieTalkie_HPP
#define UE4SS_SDK_BP_DroppedItem_WalkieTalkie_HPP

class ABP_DroppedItem_WalkieTalkie_C : public ABP_DroppedItem_C
{
    class UStaticMeshComponent* Walkie_Talkie_low_Antenna_low;                        // 0x0270 (size: 0x8)
    class UStaticMeshComponent* Walkie_Talkie_low_RightButton_low;                    // 0x0278 (size: 0x8)
    class UStaticMeshComponent* Walkie_Talkie_low_MidButton_low;                      // 0x0280 (size: 0x8)
    class UStaticMeshComponent* Walkie_Talkie_low_LeftButton_low;                     // 0x0288 (size: 0x8)
    class UStaticMeshComponent* Walkie_Talkie_low_Hanger_low;                         // 0x0290 (size: 0x8)

}; // Size: 0x298

#endif
