#ifndef UE4SS_SDK_BP_EnergyBar_HPP
#define UE4SS_SDK_BP_EnergyBar_HPP

class ABP_EnergyBar_C : public ABP_Item_C
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x0258 (size: 0x8)
    class UStaticMeshComponent* StaticMesh2;                                          // 0x0260 (size: 0x8)
    class UStaticMeshComponent* StaticMesh1;                                          // 0x0268 (size: 0x8)
    class UStaticMeshComponent* StaticMesh;                                           // 0x0270 (size: 0x8)
    float Timeline_0_Y_0779EE794E105AA3B4D9F38CAA933400;                              // 0x0278 (size: 0x4)
    float Timeline_0_X_0779EE794E105AA3B4D9F38CAA933400;                              // 0x027C (size: 0x4)
    TEnumAsByte<ETimelineDirection::Type> Timeline_0__Direction_0779EE794E105AA3B4D9F38CAA933400; // 0x0280 (size: 0x1)
    class UTimelineComponent* Timeline_0;                                             // 0x0288 (size: 0x8)

    void SetMaterial(bool EnabledFOV);
    void Timeline_0__FinishedFunc();
    void Timeline_0__UpdateFunc();
    void OnNotifyEnd_2EF3CB7C458DDF5DC53EA4A7CA6DA62A(FName NotifyName);
    void OnNotifyBegin_2EF3CB7C458DDF5DC53EA4A7CA6DA62A(FName NotifyName);
    void OnInterrupted_2EF3CB7C458DDF5DC53EA4A7CA6DA62A(FName NotifyName);
    void OnBlendOut_2EF3CB7C458DDF5DC53EA4A7CA6DA62A(FName NotifyName);
    void OnCompleted_2EF3CB7C458DDF5DC53EA4A7CA6DA62A(FName NotifyName);
    void OnNotifyEnd_AE2A3D66458122E1C7ABE08F22ADD52E(FName NotifyName);
    void OnNotifyBegin_AE2A3D66458122E1C7ABE08F22ADD52E(FName NotifyName);
    void OnInterrupted_AE2A3D66458122E1C7ABE08F22ADD52E(FName NotifyName);
    void OnBlendOut_AE2A3D66458122E1C7ABE08F22ADD52E(FName NotifyName);
    void OnCompleted_AE2A3D66458122E1C7ABE08F22ADD52E(FName NotifyName);
    void UseItem();
    void PlayAnimation();
    void SRV_FinishEat();
    void ExecuteUbergraph_BP_EnergyBar(int32 EntryPoint);
}; // Size: 0x290

#endif
