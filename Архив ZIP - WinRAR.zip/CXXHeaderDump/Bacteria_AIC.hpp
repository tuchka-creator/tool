#ifndef UE4SS_SDK_Bacteria_AIC_HPP
#define UE4SS_SDK_Bacteria_AIC_HPP

class ABacteria_AIC_C : public AAIController
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x0328 (size: 0x8)
    class UPawnSensingComponent* PawnSensing;                                         // 0x0330 (size: 0x8)
    class UBehaviorTree* BTAsset;                                                     // 0x0338 (size: 0x8)
    FName CanSeeKey;                                                                  // 0x0340 (size: 0x8)
    FName Target;                                                                     // 0x0348 (size: 0x8)
    FName ShouldTeleport;                                                             // 0x0350 (size: 0x8)
    float DelayAmount;                                                                // 0x0358 (size: 0x4)

    void ReceiveBeginPlay();
    void Setup AI(class UBehaviorTree* Behavior Tree);
    void BndEvt__Bacteria_AIC_PawnSensing_K2Node_ComponentBoundEvent_0_SeePawnDelegate__DelegateSignature(class APawn* Pawn);
    void SetCanTeleport();
    void SetChase();
    void OnQueryFinish(class UEnvQueryInstanceBlueprintWrapper* QueryInstance, TEnumAsByte<EEnvQueryStatus::Type> QueryStatus);
    void ExecuteUbergraph_Bacteria_AIC(int32 EntryPoint);
}; // Size: 0x35C

#endif
