#ifndef UE4SS_SDK_AnimBP_Elevator_Lever_HPP
#define UE4SS_SDK_AnimBP_Elevator_Lever_HPP

class UAnimBP_Elevator_Lever_C : public UAnimInstance
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x02C0 (size: 0x8)
    FAnimNode_Root AnimGraphNode_Root;                                                // 0x02C8 (size: 0x30)
    FAnimNode_ModifyBone AnimGraphNode_ModifyBone_3;                                  // 0x02F8 (size: 0x108)
    FAnimNode_ModifyBone AnimGraphNode_ModifyBone_2;                                  // 0x0400 (size: 0x108)
    FAnimNode_ConvertComponentToLocalSpace AnimGraphNode_ComponentToLocalSpace_3;     // 0x0508 (size: 0x20)
    FAnimNode_ConvertComponentToLocalSpace AnimGraphNode_ComponentToLocalSpace_2;     // 0x0528 (size: 0x20)
    FAnimNode_MeshSpaceRefPose AnimGraphNode_MeshRefPose_3;                           // 0x0548 (size: 0x10)
    FAnimNode_MeshSpaceRefPose AnimGraphNode_MeshRefPose_2;                           // 0x0558 (size: 0x10)
    FAnimNode_BlendListByInt AnimGraphNode_BlendListByInt;                            // 0x0568 (size: 0xA0)
    FAnimNode_ModifyBone AnimGraphNode_ModifyBone_1;                                  // 0x0608 (size: 0x108)
    FAnimNode_ConvertComponentToLocalSpace AnimGraphNode_ComponentToLocalSpace_1;     // 0x0710 (size: 0x20)
    FAnimNode_MeshSpaceRefPose AnimGraphNode_MeshRefPose_1;                           // 0x0730 (size: 0x10)
    FAnimNode_ModifyBone AnimGraphNode_ModifyBone;                                    // 0x0740 (size: 0x108)
    FAnimNode_ConvertComponentToLocalSpace AnimGraphNode_ComponentToLocalSpace;       // 0x0848 (size: 0x20)
    FAnimNode_MeshSpaceRefPose AnimGraphNode_MeshRefPose;                             // 0x0868 (size: 0x10)
    int32 LeverState;                                                                 // 0x0878 (size: 0x4)

    void AnimGraph(FPoseLink& AnimGraph);
    void BlueprintUpdateAnimation(float DeltaTimeX);
    void ExecuteUbergraph_AnimBP_Elevator_Lever(int32 EntryPoint);
}; // Size: 0x87C

#endif
