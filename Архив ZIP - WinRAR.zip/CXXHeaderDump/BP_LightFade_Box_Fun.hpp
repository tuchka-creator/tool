#ifndef UE4SS_SDK_BP_LightFade_Box_Fun_HPP
#define UE4SS_SDK_BP_LightFade_Box_Fun_HPP

class ABP_LightFade_Box_Fun_C : public ABP_LightFade_Box_C
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x0230 (size: 0x8)

    void ReceiveActorBeginOverlap(class AActor* OtherActor);
    void ReceiveActorEndOverlap(class AActor* OtherActor);
    void ExecuteUbergraph_BP_LightFade_Box_Fun(int32 EntryPoint);
}; // Size: 0x238

#endif
