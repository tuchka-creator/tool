#ifndef UE4SS_SDK_AC_Swimming_HPP
#define UE4SS_SDK_AC_Swimming_HPP

class UAC_Swimming_C : public UActorComponent
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x00B0 (size: 0x8)
    class ABPCharacter_Demo_C* Character Reference;                                   // 0x00B8 (size: 0x8)
    class UCharacterMovementComponent* Movement component reference;                  // 0x00C0 (size: 0x8)
    class USkeletalMeshComponent* Character Mesh Reference;                           // 0x00C8 (size: 0x8)
    bool Is Overlapping Physics Volume;                                               // 0x00D0 (size: 0x1)
    bool Is in Water;                                                                 // 0x00D1 (size: 0x1)
    bool Is Underwater;                                                               // 0x00D2 (size: 0x1)
    class USceneComponent* Breathing Point Reference;                                 // 0x00D8 (size: 0x8)
    bool Is not Drowned;                                                              // 0x00E0 (size: 0x1)
    TArray<class UParticleSystemComponent*> Spawned ambient underwater particles;     // 0x00E8 (size: 0x10)
    bool Is Diving;                                                                   // 0x00F8 (size: 0x1)
    FRotator From Rot;                                                                // 0x00FC (size: 0xC)
    FRotator To Rot;                                                                  // 0x0108 (size: 0xC)
    FRotator Current Control Rot;                                                     // 0x0114 (size: 0xC)
    bool Is sprinting in water;                                                       // 0x0120 (size: 0x1)
    FAC_Swimming_CIs In Water Event Is In Water Event;                                // 0x0128 (size: 0x10)
    void Is In Water Event(bool Is in Water);
    FAC_Swimming_CIs Underwater Event Is Underwater Event;                            // 0x0138 (size: 0x10)
    void Is Underwater Event(bool Is Underwater);
    float WaterHeight;                                                                // 0x0148 (size: 0x4)
    class ABP_Underwater_C* Underwater;                                               // 0x0150 (size: 0x8)
    TArray<class AActor*> Lights;                                                     // 0x0158 (size: 0x10)
    bool IsSwimmingUp;                                                                // 0x0168 (size: 0x1)
    bool HasDivingHelmet;                                                             // 0x0169 (size: 0x1)
    class AWaterMeshActor* Water;                                                     // 0x0170 (size: 0x8)
    bool CanDrown;                                                                    // 0x0178 (size: 0x1)
    bool IsSwimmingDown;                                                              // 0x0179 (size: 0x1)
    bool ShouldPlaySounds;                                                            // 0x017A (size: 0x1)

    void SwimDownMovementLogic();
    void GetSwimSprintSpeed(float& Speed);
    void GetSwimSpeed(float& Speed);
    void SwimUpMovementLogic();
    void CustomDiveMovementLogic(float ScaleValue);
    void DiveMovementLogic(float ScaleValue);
    void SetSmoothCharacterRotationOnStrafeMovement();
    void Destroy underwater ambient particle();
    void pause underwater ambient particle();
    void unpause underwater ambient particle();
    void ReplicateRotationToServer(FRotator DesiredRotation);
    void Start underwater ambient particle timer();
    void On Begin Play Logic - Swimming();
    void On Tick logic - Swimming();
    void Event switch diving mode();
    void Event Sprint swim();
    void Event normal swim();
    void Set normal swim speed on server();
    void Set normal swim speed on client();
    void Set Sprint speed on server();
    void Set Sprint speed on client();
    void EventIsInWater(bool IsInWater);
    void EventIsUnderwater(bool IsUnderwater);
    void Spawn sound(class USoundBase* Sound);
    void OnMovementModeChanged(TEnumAsByte<EMovementMode> PrevMovementMode, TEnumAsByte<EMovementMode> NewMovementMode, uint8 PrevCustomMode, uint8 NewCustomMode);
    void ReceiveTick(float DeltaSeconds);
    void ReceiveBeginPlay();
    void MC_Surface();
    void MC_Swim();
    void ToggleUnderwater();
    void ToggleSurface();
    void Spawn swimming ambient particle();
    void ExecuteUbergraph_AC_Swimming(int32 EntryPoint);
    void Is Underwater Event__DelegateSignature(bool Is Underwater);
    void Is In Water Event__DelegateSignature(bool Is in Water);
}; // Size: 0x17B

#endif
