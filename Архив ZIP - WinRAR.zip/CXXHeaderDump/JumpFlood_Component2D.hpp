#ifndef UE4SS_SDK_JumpFlood_Component2D_HPP
#define UE4SS_SDK_JumpFlood_Component2D_HPP

class UJumpFlood_Component2D_C : public UActorComponent
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x00B0 (size: 0x8)
    class UMaterialInstanceDynamic* JumpStepMID;                                      // 0x00B8 (size: 0x8)
    class UMaterialInstanceDynamic* FindEdgesMID;                                     // 0x00C0 (size: 0x8)
    class UMaterialInstanceDynamic* BlurEdgesMID;                                     // 0x00C8 (size: 0x8)
    class UMaterialInstanceDynamic* FixBandMID;                                       // 0x00D0 (size: 0x8)
    int32 Resolution;                                                                 // 0x00D8 (size: 0x4)
    int32 RequiredPasses;                                                             // 0x00DC (size: 0x4)
    int32 CompletedPasses;                                                            // 0x00E0 (size: 0x4)
    FVector2D TextureSize;                                                            // 0x00E4 (size: 0x8)
    class UTextureRenderTarget2D* RTA;                                                // 0x00F0 (size: 0x8)
    class UTextureRenderTarget2D* RTB;                                                // 0x00F8 (size: 0x8)
    bool UseBlur;                                                                     // 0x0100 (size: 0x1)
    int32 BlurPasses;                                                                 // 0x0104 (size: 0x4)
    int32 CompletedBlurPasses;                                                        // 0x0108 (size: 0x4)
    int32 PingPongOffset;                                                             // 0x010C (size: 0x4)

    void SingleBlurStep(class UTextureRenderTarget2D*& Result RT);
    void FindEdges_Debug(class UTextureRenderTarget2D* SeedRT, float CaptureZ, FLinearColor Curl, class UTextureRenderTarget2D* DestRT, float ZOffset);
    void FindEdges(class UTextureRenderTarget2D* SeedRT, float CaptureZ, FLinearColor Curl, bool UseDepth, float Z Location, class UTextureRenderTarget2D*& Result RT);
    void SingleJumpStep(class UTextureRenderTarget2D*& Result RT);
    void JumpFlood(class UTextureRenderTarget2D* SeedRT, float SceneCaptureZ, FLinearColor Curl, bool UseDepth, float Z Location);
    void Assign RenderTargets(class UTextureRenderTarget2D* RTA, class UTextureRenderTarget2D* RTB);
    void ExecuteUbergraph_JumpFlood_Component2D(int32 EntryPoint);
}; // Size: 0x110

#endif
