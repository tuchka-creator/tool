#ifndef UE4SS_SDK_BP_SimpleFancyError_HPP
#define UE4SS_SDK_BP_SimpleFancyError_HPP

class UBP_SimpleFancyError_C : public UFancyUserFlow
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x00A8 (size: 0x8)
    FText Title;                                                                      // 0x00B0 (size: 0x18)
    FText Message;                                                                    // 0x00C8 (size: 0x18)
    FText Header;                                                                     // 0x00E0 (size: 0x18)
    FText OkButton;                                                                   // 0x00F8 (size: 0x18)
    bool bForceReturnToMenu;                                                          // 0x0110 (size: 0x1)

    void Run();
    void ExecuteUbergraph_BP_SimpleFancyError(int32 EntryPoint);
}; // Size: 0x111

#endif
