#ifndef UE4SS_SDK_BP_CloseableInterface_HPP
#define UE4SS_SDK_BP_CloseableInterface_HPP

class IBP_CloseableInterface_C : public IInterface
{

    void CanClose();
}; // Size: 0x28

#endif
