#ifndef UE4SS_SDK_BP_Pool_Ladder_HPP
#define UE4SS_SDK_BP_Pool_Ladder_HPP

class ABP_Pool_Ladder_C : public AActor
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x0220 (size: 0x8)
    class USceneComponent* FinishLocation;                                            // 0x0228 (size: 0x8)
    class UBoxComponent* Box1;                                                        // 0x0230 (size: 0x8)
    class USceneComponent* DefaultSceneRoot;                                          // 0x0238 (size: 0x8)
    int32 Height;                                                                     // 0x0240 (size: 0x4)
    float Scale;                                                                      // 0x0244 (size: 0x4)
    float SpeedMultiplier;                                                            // 0x0248 (size: 0x4)

    FVector GetHeightPoint();
    bool CanClimb(class APawn* Pawn);
    FVector GetStartPoint();
    void UserConstructionScript();
    void BndEvt__BP_Ladder_Box1_K2Node_ComponentBoundEvent_2_ComponentBeginOverlapSignature__DelegateSignature(class UPrimitiveComponent* OverlappedComponent, class AActor* OtherActor, class UPrimitiveComponent* OtherComp, int32 OtherBodyIndex, bool bFromSweep, const FHitResult& SweepResult);
    void ExecuteUbergraph_BP_Pool_Ladder(int32 EntryPoint);
}; // Size: 0x24C

#endif
