#ifndef UE4SS_SDK_BP_AttemptToEnterLobby_Flow_HPP
#define UE4SS_SDK_BP_AttemptToEnterLobby_Flow_HPP

class UBP_AttemptToEnterLobby_Flow_C : public UFancyUserFlow
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x00A8 (size: 0x8)
    FBlueprintSessionResult SessionResult;                                            // 0x00B0 (size: 0x108)
    class APlayerController* PlayerController;                                        // 0x01B8 (size: 0x8)
    bool ShowLoadingScreen;                                                           // 0x01C0 (size: 0x1)
    bool bSuccess;                                                                    // 0x01C1 (size: 0x1)
    bool bIsFromInvitation;                                                           // 0x01C2 (size: 0x1)
    bool bRefreshServerListOnFailure;                                                 // 0x01C3 (size: 0x1)
    bool bReturnFocusOnFailure;                                                       // 0x01C4 (size: 0x1)
    class UWidget* PreviousWidget;                                                    // 0x01C8 (size: 0x8)

    void CompleteAndReturnFocus();
    void OnFailure_1AF601CC4208579E90FF82B097455828(const bool SessionInfo);
    void OnSuccess_1AF601CC4208579E90FF82B097455828(const bool SessionInfo);
    void OnFailure_1ADC80B6492FC6B5A0960B9340AF9E0E(EOnJoinSessionCompleteFancyResult Result);
    void OnSuccess_1ADC80B6492FC6B5A0960B9340AF9E0E(EOnJoinSessionCompleteFancyResult Result);
    void OnFailure_B1BF65AF49076E0F06E67587572CA75C();
    void OnSuccess_B1BF65AF49076E0F06E67587572CA75C();
    void OnFailure_A06C510E4D9B000C1DADD78D0EB0A162();
    void OnSuccess_A06C510E4D9B000C1DADD78D0EB0A162();
    void Run();
    void HandleCrossplayPrivilegeCheckComplete(bool bSuccess);
    void ExecuteUbergraph_BP_AttemptToEnterLobby_Flow(int32 EntryPoint);
}; // Size: 0x1D0

#endif
