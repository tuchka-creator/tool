namespace EModifierKeys {
    enum Type {
        NewEnumerator2 = 0,
        NewEnumerator0 = 1,
        NewEnumerator1 = 2,
        NewEnumerator6 = 3,
        NewEnumerator3 = 4,
        NewEnumerator4 = 5,
        NewEnumerator5 = 6,
        NewEnumerator7 = 7,
        NewEnumerator8 = 8,
        EModifierKeys_MAX = 9,
    };
}

