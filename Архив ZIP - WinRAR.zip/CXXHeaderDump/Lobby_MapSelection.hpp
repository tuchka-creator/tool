#ifndef UE4SS_SDK_Lobby_MapSelection_HPP
#define UE4SS_SDK_Lobby_MapSelection_HPP

class ULobby_MapSelection_C : public UUserWidget
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x0270 (size: 0x8)
    class USizeBox* DescriptionBox;                                                   // 0x0278 (size: 0x8)
    class UTextBlock* Difficulty_Description_Text;                                    // 0x0280 (size: 0x8)
    class USizeBox* DifficultySwitcherBox;                                            // 0x0288 (size: 0x8)
    class UTextBlock* GameMode_Description_Text;                                      // 0x0290 (size: 0x8)
    class ULobby_DifficultySwitcher_C* Lobby_DifficultySwitcher;                      // 0x0298 (size: 0x8)
    class ULobby_Level_Switcher_C* Lobby_Level_Switcher_C_0;                          // 0x02A0 (size: 0x8)
    class ULobby_Name_Box_C* Lobby_Name_Box_C_1;                                      // 0x02A8 (size: 0x8)
    class ULobby_Save_Switcher_C* Lobby_Save_Switcher;                                // 0x02B0 (size: 0x8)
    class UImage* Map_Image;                                                          // 0x02B8 (size: 0x8)
    class UTextBlock* MapName_Text;                                                   // 0x02C0 (size: 0x8)
    class USizeBox* MapSwitcherBox;                                                   // 0x02C8 (size: 0x8)
    class USizeBox* NameBox;                                                          // 0x02D0 (size: 0x8)
    class USizeBox* SaveSwitcherBox;                                                  // 0x02D8 (size: 0x8)
    class UTextBlock* TextBlock_Error;                                                // 0x02E0 (size: 0x8)
    class UTextBlock* Time;                                                           // 0x02E8 (size: 0x8)
    bool Show_MapSwitcher?;                                                           // 0x02F0 (size: 0x1)
    FString Selected_Option;                                                          // 0x02F8 (size: 0x10)
    FLobby_MapSelection_COnSwitched_Map OnSwitched_Map;                               // 0x0308 (size: 0x10)
    void OnSwitched_Map(FString Selected_Map);
    bool Show_DifficultySwitcher;                                                     // 0x0318 (size: 0x1)
    bool Show_SaveGameSwitcher;                                                       // 0x0319 (size: 0x1)
    FText SaveName;                                                                   // 0x0320 (size: 0x18)
    TArray<FString> CharacterArray;                                                   // 0x0338 (size: 0x10)
    FLobby_MapSelection_COnSwitched_Save OnSwitched_Save;                             // 0x0348 (size: 0x10)
    void OnSwitched_Save(FString SaveName);
    FString SlotName;                                                                 // 0x0358 (size: 0x10)
    FLobby_MapSelection_COnSwitched_Difficulty OnSwitched_Difficulty;                 // 0x0368 (size: 0x10)
    void OnSwitched_Difficulty(TEnumAsByte<E_Difficulty::Type> Difficulty);

    void CheckName(bool& IsValid);
    void Set_SaveName_Visibility();
    void Set_SaveButtons_Visibility();
    void ResetLevelSelection(TEnumAsByte<E_Difficulty::Type> Difficulty);
    void GetLevelFromName(FString Name, FName& LevelName);
    void GetMapFromName(FString Name, class UTexture*& Image);
    FText GetTime(float Time);
    void RoundedTime(float Time, FString& RoundedTime);
    void Set_Selected_Save(FString Slot, bool CallDelegate?);
    void Set_Selected_Level(FString Level, bool CallDelegate?);
    void Set_Selected_Difficulty(FString Difficulty, bool CallDelegate?);
    void Set_DifficultyButtons_Visibility();
    void Set_OptionButtons_Visibility();
    void Set_Selected_Map(FString MapName, bool CallDelegate?);
    void SetUp();
    void BndEvt__Lobby_MapSelection_Lobby_Level_Switcher_C_0_K2Node_ComponentBoundEvent_3_OnLevelSwitched__DelegateSignature(FString SelectedOption);
    void PreConstruct(bool IsDesignTime);
    void CanClose();
    void BndEvt__Lobby_MapSelection_Lobby_Save_Switcher_K2Node_ComponentBoundEvent_4_OnSaveSwitched__DelegateSignature(FString SelectedOption);
    void BndEvt__Lobby_MapSelection_Lobby_DifficultySwitcher_K2Node_ComponentBoundEvent_0_OnDifficultySwitched__DelegateSignature(FString SelectedOption);
    void BndEvt__Lobby_MapSelection_Lobby_Name_Box_C_1_K2Node_ComponentBoundEvent_0_OnNameSwitched__DelegateSignature(FText SelectedOption);
    void ExecuteUbergraph_Lobby_MapSelection(int32 EntryPoint);
    void OnSwitched_Difficulty__DelegateSignature(TEnumAsByte<E_Difficulty::Type> Difficulty);
    void OnSwitched_Save__DelegateSignature(FString SaveName);
    void OnSwitched_Map__DelegateSignature(FString Selected_Map);
}; // Size: 0x378

#endif
