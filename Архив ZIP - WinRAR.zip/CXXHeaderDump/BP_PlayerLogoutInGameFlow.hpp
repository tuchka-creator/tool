#ifndef UE4SS_SDK_BP_PlayerLogoutInGameFlow_HPP
#define UE4SS_SDK_BP_PlayerLogoutInGameFlow_HPP

class UBP_PlayerLogoutInGameFlow_C : public UFancyUserFlow
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x00A8 (size: 0x8)
    class APlayerController* Player Controller;                                       // 0x00B0 (size: 0x8)
    class UWidget* FocusedWidget;                                                     // 0x00B8 (size: 0x8)
    bool bIsServer;                                                                   // 0x00C0 (size: 0x1)

    void OnFailure_243C165E4A404AB42AA97DA2E6012E06();
    void OnSuccess_243C165E4A404AB42AA97DA2E6012E06();
    void Run();
    void ExecuteUbergraph_BP_PlayerLogoutInGameFlow(int32 EntryPoint);
}; // Size: 0xC1

#endif
