#ifndef UE4SS_SDK_Grass_Interaction_Other_HPP
#define UE4SS_SDK_Grass_Interaction_Other_HPP

class UGrass_Interaction_Other_C : public UInteractWithGrass_BP_C
{
}; // Size: 0x340

#endif
