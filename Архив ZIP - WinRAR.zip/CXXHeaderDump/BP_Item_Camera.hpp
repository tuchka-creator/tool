#ifndef UE4SS_SDK_BP_Item_Camera_HPP
#define UE4SS_SDK_BP_Item_Camera_HPP

class ABP_Item_Camera_C : public ABP_Item_C
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x0258 (size: 0x8)
    class USpotLightComponent* SpotLight;                                             // 0x0260 (size: 0x8)
    class UStaticMeshComponent* Tube_Panel_low_Plates_low49;                          // 0x0268 (size: 0x8)
    class UStaticMeshComponent* Tube_Panel_low_Plates_low48;                          // 0x0270 (size: 0x8)
    class UStaticMeshComponent* Tube_Panel_low_Plates_low47;                          // 0x0278 (size: 0x8)
    class UStaticMeshComponent* Tube_Panel_low_Plates_low46;                          // 0x0280 (size: 0x8)
    class UStaticMeshComponent* Tube_Panel_low_Plates_low45;                          // 0x0288 (size: 0x8)
    class UStaticMeshComponent* Tube_Panel_low_Plates_low44;                          // 0x0290 (size: 0x8)
    class UStaticMeshComponent* Tube_Panel_low_Plates_low43;                          // 0x0298 (size: 0x8)
    class UStaticMeshComponent* Tube_Panel_low_Plates_low42;                          // 0x02A0 (size: 0x8)
    class UStaticMeshComponent* Tube_Panel_low_Plates_low41;                          // 0x02A8 (size: 0x8)
    class UStaticMeshComponent* Tube_Panel_low_Plates_low40;                          // 0x02B0 (size: 0x8)
    class UStaticMeshComponent* Tube_Panel_low_Plates_low39;                          // 0x02B8 (size: 0x8)
    class UStaticMeshComponent* Tube_Panel_low_Plates_low38;                          // 0x02C0 (size: 0x8)
    class UStaticMeshComponent* Tube_Panel_low_Plates_low37;                          // 0x02C8 (size: 0x8)
    class UStaticMeshComponent* Tube_Panel_low_Plates_low36;                          // 0x02D0 (size: 0x8)
    class UStaticMeshComponent* Tube_Panel_low_Plates_low35;                          // 0x02D8 (size: 0x8)
    class UStaticMeshComponent* Tube_Panel_low_Plates_low34;                          // 0x02E0 (size: 0x8)
    class UStaticMeshComponent* Tube_Panel_low_Plates_low33;                          // 0x02E8 (size: 0x8)
    class UStaticMeshComponent* Tube_Panel_low_Plates_low32;                          // 0x02F0 (size: 0x8)
    class UStaticMeshComponent* Tube_Panel_low_Plates_low31;                          // 0x02F8 (size: 0x8)
    class UStaticMeshComponent* Tube_Panel_low_Plates_low30;                          // 0x0300 (size: 0x8)
    class UStaticMeshComponent* Tube_Panel_low_Plates_low29;                          // 0x0308 (size: 0x8)
    class UStaticMeshComponent* Tube_Panel_low_Plates_low28;                          // 0x0310 (size: 0x8)
    class UStaticMeshComponent* Tube_Panel_low_Plates_low27;                          // 0x0318 (size: 0x8)
    class UStaticMeshComponent* Tube_Panel_low_Plates_low26;                          // 0x0320 (size: 0x8)
    class UStaticMeshComponent* Tube_Panel_low_Plates_low25;                          // 0x0328 (size: 0x8)
    class UStaticMeshComponent* Tube_Panel_low_Plates_low24;                          // 0x0330 (size: 0x8)
    class UStaticMeshComponent* Tube_Panel_low_Plates_low23;                          // 0x0338 (size: 0x8)
    class UStaticMeshComponent* Tube_Panel_low_Plates_low22;                          // 0x0340 (size: 0x8)
    class UStaticMeshComponent* Tube_Panel_low_Plates_low21;                          // 0x0348 (size: 0x8)
    class UStaticMeshComponent* Tube_Panel_low_Plates_low20;                          // 0x0350 (size: 0x8)
    class UStaticMeshComponent* Tube_Panel_low_Plates_low19;                          // 0x0358 (size: 0x8)
    class UStaticMeshComponent* Tube_Panel_low_Plates_low18;                          // 0x0360 (size: 0x8)
    class UStaticMeshComponent* Tube_Panel_low_Plates_low17;                          // 0x0368 (size: 0x8)
    class UStaticMeshComponent* Tube_Panel_low_Plates_low16;                          // 0x0370 (size: 0x8)
    class UStaticMeshComponent* Tube_Panel_low_Plates_low15;                          // 0x0378 (size: 0x8)
    class UStaticMeshComponent* Tube_Panel_low_Plates_low14;                          // 0x0380 (size: 0x8)
    class UStaticMeshComponent* Tube_Panel_low_Plates_low13;                          // 0x0388 (size: 0x8)
    class UStaticMeshComponent* Tube_Panel_low_Plates_low12;                          // 0x0390 (size: 0x8)
    class UStaticMeshComponent* Tube_Panel_low_Plates_low11;                          // 0x0398 (size: 0x8)
    class UPointLightComponent* PointLight1;                                          // 0x03A0 (size: 0x8)
    class UStaticMeshComponent* SM_InstantPhoto;                                      // 0x03A8 (size: 0x8)
    class UPointLightComponent* PointLight;                                           // 0x03B0 (size: 0x8)
    class USceneCaptureComponent2D* SceneCaptureComponent2D;                          // 0x03B8 (size: 0x8)
    float Flash_Alpha_123048234F34F59E9AA4BCB6DABD2FF5;                               // 0x03C0 (size: 0x4)
    TEnumAsByte<ETimelineDirection::Type> Flash__Direction_123048234F34F59E9AA4BCB6DABD2FF5; // 0x03C4 (size: 0x1)
    class UTimelineComponent* Flash;                                                  // 0x03C8 (size: 0x8)
    class UTextureRenderTarget2D* Target;                                             // 0x03D0 (size: 0x8)
    bool CanUse;                                                                      // 0x03D8 (size: 0x1)
    class ABP_Tunnel_CameraManager_C* CameraManager;                                  // 0x03E0 (size: 0x8)
    int32 CurrentPicture;                                                             // 0x03E8 (size: 0x4)
    class UMaterialInstanceDynamic* DynMat;                                           // 0x03F0 (size: 0x8)
    bool IsFlashlightOn;                                                              // 0x03F8 (size: 0x1)

    void OnRep_IsFlashlightOn();
    void SetMaterial(bool EnabledFOV);
    void OnRep_CurrentPicture();
    void UserConstructionScript();
    void Flash__FinishedFunc();
    void Flash__UpdateFunc();
    void Flash__Snap__EventFunc();
    void OnNotifyEnd_3ABC687248F18F6E8E9F69BF9EB015A7(FName NotifyName);
    void OnNotifyBegin_3ABC687248F18F6E8E9F69BF9EB015A7(FName NotifyName);
    void OnInterrupted_3ABC687248F18F6E8E9F69BF9EB015A7(FName NotifyName);
    void OnBlendOut_3ABC687248F18F6E8E9F69BF9EB015A7(FName NotifyName);
    void OnCompleted_3ABC687248F18F6E8E9F69BF9EB015A7(FName NotifyName);
    void OnNotifyEnd_E8F7DC85419A58268AB58B8CC984D2BD(FName NotifyName);
    void OnNotifyBegin_E8F7DC85419A58268AB58B8CC984D2BD(FName NotifyName);
    void OnInterrupted_E8F7DC85419A58268AB58B8CC984D2BD(FName NotifyName);
    void OnBlendOut_E8F7DC85419A58268AB58B8CC984D2BD(FName NotifyName);
    void OnCompleted_E8F7DC85419A58268AB58B8CC984D2BD(FName NotifyName);
    void OnNotifyEnd_49041A0D437647D77BE07E918FD7721C(FName NotifyName);
    void OnNotifyBegin_49041A0D437647D77BE07E918FD7721C(FName NotifyName);
    void OnInterrupted_49041A0D437647D77BE07E918FD7721C(FName NotifyName);
    void OnBlendOut_49041A0D437647D77BE07E918FD7721C(FName NotifyName);
    void OnCompleted_49041A0D437647D77BE07E918FD7721C(FName NotifyName);
    void UseItem();
    void SnapPicture();
    void ReceiveBeginPlay();
    void Update();
    void ReceiveTick(float DeltaSeconds);
    void MC_StartPicture(class AFancyCharacter* Player);
    void StopPicture();
    void MC_SwitchPhotos();
    void PlayAnimation();
    void SRV_ToggleLight(bool Enabled);
    void ExecuteUbergraph_BP_Item_Camera(int32 EntryPoint);
}; // Size: 0x3F9

#endif
