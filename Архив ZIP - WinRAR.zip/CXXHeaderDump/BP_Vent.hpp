#ifndef UE4SS_SDK_BP_Vent_HPP
#define UE4SS_SDK_BP_Vent_HPP

class ABP_Vent_C : public AInteractableActor
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x0248 (size: 0x8)
    class UStaticMeshComponent* BreakableVent_SM_Ventilation16_LOD0_011;              // 0x0250 (size: 0x8)
    class UStaticMeshComponent* BreakableVent_SM_Ventilation16_LOD0_010;              // 0x0258 (size: 0x8)
    class UStaticMeshComponent* BreakableVent_SM_Ventilation16_LOD0_009;              // 0x0260 (size: 0x8)
    class UStaticMeshComponent* BreakableVent_SM_Ventilation16_LOD0_008;              // 0x0268 (size: 0x8)
    class UStaticMeshComponent* BreakableVent_SM_Ventilation16_LOD0_007;              // 0x0270 (size: 0x8)
    class UStaticMeshComponent* BreakableVent_SM_Ventilation16_LOD0_006;              // 0x0278 (size: 0x8)
    class UStaticMeshComponent* BreakableVent_SM_Ventilation16_LOD0_005;              // 0x0280 (size: 0x8)
    class UStaticMeshComponent* BreakableVent_SM_Ventilation16_LOD0_004;              // 0x0288 (size: 0x8)
    class UStaticMeshComponent* BreakableVent_SM_Ventilation16_LOD0_003;              // 0x0290 (size: 0x8)
    class UStaticMeshComponent* BreakableVent_SM_Ventilation16_LOD0_002;              // 0x0298 (size: 0x8)
    class UStaticMeshComponent* BreakableVent_SM_Ventilation16_LOD0_001;              // 0x02A0 (size: 0x8)
    class UStaticMeshComponent* BreakableVent_SM_Ventilation16_LOD0;                  // 0x02A8 (size: 0x8)
    class UStaticMeshComponent* BreakableVent_SM_Ventilation16_LOD0_012;              // 0x02B0 (size: 0x8)
    bool WasBroken;                                                                   // 0x02B8 (size: 0x1)
    bool IsSpawnVent;                                                                 // 0x02B9 (size: 0x1)

    void OnRep_WasBroken();
    void Damage(class ACharacter* Character);
    void OnUsed();
    void MC_Break();
    void ReceiveBeginPlay();
    void ExecuteUbergraph_BP_Vent(int32 EntryPoint);
}; // Size: 0x2BA

#endif
