#ifndef UE4SS_SDK_FluidForceSocketInfo_HPP
#define UE4SS_SDK_FluidForceSocketInfo_HPP

struct FFluidForceSocketInfo
{
    TMap<class FName, class FName> SocketsandEndpoints_6_B3EDD8FC43A7C681151F46BE0AA158C5; // 0x0000 (size: 0x50)

}; // Size: 0x50

#endif
