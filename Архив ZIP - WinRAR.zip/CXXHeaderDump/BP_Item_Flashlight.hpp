#ifndef UE4SS_SDK_BP_Item_Flashlight_HPP
#define UE4SS_SDK_BP_Item_Flashlight_HPP

class ABP_Item_Flashlight_C : public ABP_Item_C
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x0258 (size: 0x8)
    class USpringArmComponent* FlashlightArm;                                         // 0x0260 (size: 0x8)
    class USpotLightComponent* FlashlightFakeGI;                                      // 0x0268 (size: 0x8)
    class USpotLightComponent* Flashlight;                                            // 0x0270 (size: 0x8)
    class UPointLightComponent* PointLight;                                           // 0x0278 (size: 0x8)
    float Timeline_2_Intensity_008846C045F53BBD4D1894AF62ABCDA4;                      // 0x0280 (size: 0x4)
    TEnumAsByte<ETimelineDirection::Type> Timeline_2__Direction_008846C045F53BBD4D1894AF62ABCDA4; // 0x0284 (size: 0x1)
    class UTimelineComponent* Timeline_2;                                             // 0x0288 (size: 0x8)
    float TogglePower_ConeAngle_13371DEB4B39ADCC2F805FA1A0243354;                     // 0x0290 (size: 0x4)
    float TogglePower_Radius_13371DEB4B39ADCC2F805FA1A0243354;                        // 0x0294 (size: 0x4)
    float TogglePower_Intensity_13371DEB4B39ADCC2F805FA1A0243354;                     // 0x0298 (size: 0x4)
    TEnumAsByte<ETimelineDirection::Type> TogglePower__Direction_13371DEB4B39ADCC2F805FA1A0243354; // 0x029C (size: 0x1)
    class UTimelineComponent* TogglePower;                                            // 0x02A0 (size: 0x8)
    float Timeline_1_Attenuation_E0EC2A9E45AAEE86A82C75B21D1308FD;                    // 0x02A8 (size: 0x4)
    float Timeline_1_Intensity_E0EC2A9E45AAEE86A82C75B21D1308FD;                      // 0x02AC (size: 0x4)
    TEnumAsByte<ETimelineDirection::Type> Timeline_1__Direction_E0EC2A9E45AAEE86A82C75B21D1308FD; // 0x02B0 (size: 0x1)
    class UTimelineComponent* Timeline_1;                                             // 0x02B8 (size: 0x8)
    float Timeline_0_Intensity_EDA80A064DE4869B230E87B5CA1781E4;                      // 0x02C0 (size: 0x4)
    TEnumAsByte<ETimelineDirection::Type> Timeline_0__Direction_EDA80A064DE4869B230E87B5CA1781E4; // 0x02C4 (size: 0x1)
    class UTimelineComponent* Timeline_0;                                             // 0x02C8 (size: 0x8)
    bool IsFlashlightOn;                                                              // 0x02D0 (size: 0x1)
    float Intensity;                                                                  // 0x02D4 (size: 0x4)
    bool HasGI;                                                                       // 0x02D8 (size: 0x1)

    void SetMaterial(bool EnabledFOV);
    void GetAdjustedRadius(float Radius, float& Adjusted);
    void GetAdjustedIntensity(float Intensity, float& Adjusted);
    void OnRep_IsFlashlightOn();
    void Timeline_0__FinishedFunc();
    void Timeline_0__UpdateFunc();
    void Timeline_1__FinishedFunc();
    void Timeline_1__UpdateFunc();
    void TogglePower__FinishedFunc();
    void TogglePower__UpdateFunc();
    void Timeline_2__FinishedFunc();
    void Timeline_2__UpdateFunc();
    void OnNotifyEnd_858C6BED431A8EBEEAB2D09BA256DAA6(FName NotifyName);
    void OnNotifyBegin_858C6BED431A8EBEEAB2D09BA256DAA6(FName NotifyName);
    void OnInterrupted_858C6BED431A8EBEEAB2D09BA256DAA6(FName NotifyName);
    void OnBlendOut_858C6BED431A8EBEEAB2D09BA256DAA6(FName NotifyName);
    void OnCompleted_858C6BED431A8EBEEAB2D09BA256DAA6(FName NotifyName);
    void UseItem();
    void ReceiveBeginPlay();
    void ToggleFadePower(bool FadeOut);
    void PlayAnimation();
    void StartFlicker();
    void ToggleFlashlightPower(bool Power);
    void FadeLight(bool FadeOut);
    void ExecuteUbergraph_BP_Item_Flashlight(int32 EntryPoint);
}; // Size: 0x2D9

#endif
