namespace E_GameMode {
    enum Type {
        NewEnumerator0 = 0,
        NewEnumerator1 = 1,
        E_MAX = 2,
    };
}

