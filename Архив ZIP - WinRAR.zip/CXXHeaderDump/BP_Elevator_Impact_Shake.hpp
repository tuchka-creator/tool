#ifndef UE4SS_SDK_BP_Elevator_Impact_Shake_HPP
#define UE4SS_SDK_BP_Elevator_Impact_Shake_HPP

class UBP_Elevator_Impact_Shake_C : public UMatineeCameraShake
{
}; // Size: 0x1B0

#endif
