#ifndef UE4SS_SDK_Lobby_PlayerList_HPP
#define UE4SS_SDK_Lobby_PlayerList_HPP

class ULobby_PlayerList_C : public UUserWidget
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x0270 (size: 0x8)
    class UTextBlock* PlayerCount_Text;                                               // 0x0278 (size: 0x8)
    class UScrollBox* PlayerList;                                                     // 0x0280 (size: 0x8)
    TArray<FS_ConnectedPlayer> ConnectedPlayers;                                      // 0x0288 (size: 0x10)

    void Update_PlayerCount();
    void Update_PlayerList();
    void CanClose();
    void Update_Widget(const TArray<FS_ConnectedPlayer>& ConnectedPlayers);
    void ExecuteUbergraph_Lobby_PlayerList(int32 EntryPoint);
}; // Size: 0x298

#endif
