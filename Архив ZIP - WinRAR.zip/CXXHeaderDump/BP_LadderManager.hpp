#ifndef UE4SS_SDK_BP_LadderManager_HPP
#define UE4SS_SDK_BP_LadderManager_HPP

class ABP_LadderManager_C : public AActor
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x0220 (size: 0x8)
    class USceneComponent* DefaultSceneRoot;                                          // 0x0228 (size: 0x8)
    int32 LaddersNeeded;                                                              // 0x0230 (size: 0x4)

    void FoundLadder();
    void SetLadders(int32 Count);
    void ReceiveBeginPlay();
    void ExecuteUbergraph_BP_LadderManager(int32 EntryPoint);
}; // Size: 0x234

#endif
