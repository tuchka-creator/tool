#ifndef UE4SS_SDK_FoliageToSpawnInArea_HPP
#define UE4SS_SDK_FoliageToSpawnInArea_HPP

struct FFoliageToSpawnInArea
{
    class UStaticMesh* FoliageToSpawn_Mesh_17_3C8F886546FA9128E267F1AF8A2DD0EF;       // 0x0000 (size: 0x8)
    TSubclassOf<class UINTERACTIVE_FoliageComp_BP_C> FoliageToSpawn_Component_18_1AD846B341447BD3BAE13DA58707FE6E; // 0x0008 (size: 0x8)
    float Density_5_54B823914D1C9E42333A53A256B62F6D;                                 // 0x0010 (size: 0x4)
    float Irregularity_7_23B801EB40FD74953D64AAA7EE571B92;                            // 0x0014 (size: 0x4)
    FVector minScale_10_AA532E8B44CC1FE88FD4EB8A0421516E;                             // 0x0018 (size: 0xC)
    FVector maxScale_12_D9B9070A4F83AF086F1B1A9DD537D137;                             // 0x0024 (size: 0xC)

}; // Size: 0x30

#endif
