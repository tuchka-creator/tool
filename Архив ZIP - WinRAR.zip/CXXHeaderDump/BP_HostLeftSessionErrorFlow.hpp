#ifndef UE4SS_SDK_BP_HostLeftSessionErrorFlow_HPP
#define UE4SS_SDK_BP_HostLeftSessionErrorFlow_HPP

class UBP_HostLeftSessionErrorFlow_C : public UFancyUserFlow
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x00A8 (size: 0x8)

    void Run();
    void ExecuteUbergraph_BP_HostLeftSessionErrorFlow(int32 EntryPoint);
}; // Size: 0xB0

#endif
