namespace GrassInteractionType {
    enum Type {
        NewEnumerator0 = 0,
        NewEnumerator1 = 1,
        NewEnumerator3 = 2,
        GrassInteractionType_MAX = 3,
    };
}

