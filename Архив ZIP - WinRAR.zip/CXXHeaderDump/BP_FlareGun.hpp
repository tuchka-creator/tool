#ifndef UE4SS_SDK_BP_FlareGun_HPP
#define UE4SS_SDK_BP_FlareGun_HPP

class ABP_FlareGun_C : public ABP_Item_C
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x0258 (size: 0x8)
    class USceneComponent* Muzzle;                                                    // 0x0260 (size: 0x8)
    bool CanUse;                                                                      // 0x0268 (size: 0x1)

    void OnNotifyEnd_2B9968E342C281F2784D3CA1FF59D3F5(FName NotifyName);
    void OnNotifyBegin_2B9968E342C281F2784D3CA1FF59D3F5(FName NotifyName);
    void OnInterrupted_2B9968E342C281F2784D3CA1FF59D3F5(FName NotifyName);
    void OnBlendOut_2B9968E342C281F2784D3CA1FF59D3F5(FName NotifyName);
    void OnCompleted_2B9968E342C281F2784D3CA1FF59D3F5(FName NotifyName);
    void UseItem();
    void MC_Fire();
    void ReceiveBeginPlay();
    void ReceiveDestroyed();
    void ExecuteUbergraph_BP_FlareGun(int32 EntryPoint);
}; // Size: 0x269

#endif
