#ifndef UE4SS_SDK_HE_SubtitleSeq_HPP
#define UE4SS_SDK_HE_SubtitleSeq_HPP

struct FHE_SubtitleSeq
{
    TArray<FHE_Subtitle> AddSubtitle_55_08FC403D464A20C6CBF55A82BF774C1F;             // 0x0000 (size: 0x10)
    float -DelayBeforeStartSequenceSec_51_81E5F8174699CC734A4E6C803D4C9618;           // 0x0010 (size: 0x4)

}; // Size: 0x14

#endif
