#ifndef UE4SS_SDK_BP_ServerConnectionErrorFlow_HPP
#define UE4SS_SDK_BP_ServerConnectionErrorFlow_HPP

class UBP_ServerConnectionErrorFlow_C : public UFancyUserFlow
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x00A8 (size: 0x8)
    bool bOnline;                                                                     // 0x00B0 (size: 0x1)
    class UWidget* PreviousFocus;                                                     // 0x00B8 (size: 0x8)

    void Run();
    void ExecuteUbergraph_BP_ServerConnectionErrorFlow(int32 EntryPoint);
}; // Size: 0xC0

#endif
