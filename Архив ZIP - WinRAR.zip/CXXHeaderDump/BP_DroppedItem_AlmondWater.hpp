#ifndef UE4SS_SDK_BP_DroppedItem_AlmondWater_HPP
#define UE4SS_SDK_BP_DroppedItem_AlmondWater_HPP

class ABP_DroppedItem_AlmondWater_C : public ABP_DroppedItem_C
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x0270 (size: 0x8)

    void OnEventLoaded(uint8 EventType);
    void ToggleEvent(bool Enable);
    void ExecuteUbergraph_BP_DroppedItem_AlmondWater(int32 EntryPoint);
}; // Size: 0x278

#endif
