#ifndef UE4SS_SDK_BPFL_ChatUtilities_HPP
#define UE4SS_SDK_BPFL_ChatUtilities_HPP

class UBPFL_ChatUtilities_C : public UBlueprintFunctionLibrary
{

    void GetCensoredPlayerName(class APlayerState* PlayerState, class UObject* __WorldContext, FString& CleanPlayerName);
    void CensorProfanity(FString Text, class UObject* __WorldContext, FString& CleanMessageText, bool& ContainsProfanity);
}; // Size: 0x28

#endif
