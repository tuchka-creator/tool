#ifndef UE4SS_SDK_BTDecorator_CanMove_HPP
#define UE4SS_SDK_BTDecorator_CanMove_HPP

class UBTDecorator_CanMove_C : public UBTDecorator_BlueprintBase
{

    bool PerformConditionCheckAI(class AAIController* OwnerController, class APawn* ControlledPawn);
}; // Size: 0xA0

#endif
