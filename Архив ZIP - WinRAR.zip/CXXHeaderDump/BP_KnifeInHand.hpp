#ifndef UE4SS_SDK_BP_KnifeInHand_HPP
#define UE4SS_SDK_BP_KnifeInHand_HPP

class ABP_KnifeInHand_C : public AActor
{
    class UStaticMeshComponent* Mesh;                                                 // 0x0220 (size: 0x8)
    class USceneComponent* DefaultSceneRoot;                                          // 0x0228 (size: 0x8)

}; // Size: 0x230

#endif
