#ifndef UE4SS_SDK_BP_DroppedItem_Camera_HPP
#define UE4SS_SDK_BP_DroppedItem_Camera_HPP

class ABP_DroppedItem_Camera_C : public ABP_DroppedItem_C
{
    class UStaticMeshComponent* Tube_Panel_low_Plates_low49;                          // 0x0270 (size: 0x8)
    class UStaticMeshComponent* Tube_Panel_low_Plates_low48;                          // 0x0278 (size: 0x8)
    class UStaticMeshComponent* Tube_Panel_low_Plates_low47;                          // 0x0280 (size: 0x8)
    class UStaticMeshComponent* Tube_Panel_low_Plates_low46;                          // 0x0288 (size: 0x8)
    class UStaticMeshComponent* Tube_Panel_low_Plates_low45;                          // 0x0290 (size: 0x8)
    class UStaticMeshComponent* Tube_Panel_low_Plates_low44;                          // 0x0298 (size: 0x8)
    class UStaticMeshComponent* Tube_Panel_low_Plates_low43;                          // 0x02A0 (size: 0x8)
    class UStaticMeshComponent* Tube_Panel_low_Plates_low42;                          // 0x02A8 (size: 0x8)
    class UStaticMeshComponent* Tube_Panel_low_Plates_low41;                          // 0x02B0 (size: 0x8)
    class UStaticMeshComponent* Tube_Panel_low_Plates_low40;                          // 0x02B8 (size: 0x8)
    class UStaticMeshComponent* Tube_Panel_low_Plates_low39;                          // 0x02C0 (size: 0x8)
    class UStaticMeshComponent* Tube_Panel_low_Plates_low38;                          // 0x02C8 (size: 0x8)
    class UStaticMeshComponent* Tube_Panel_low_Plates_low37;                          // 0x02D0 (size: 0x8)
    class UStaticMeshComponent* Tube_Panel_low_Plates_low36;                          // 0x02D8 (size: 0x8)
    class UStaticMeshComponent* Tube_Panel_low_Plates_low35;                          // 0x02E0 (size: 0x8)
    class UStaticMeshComponent* Tube_Panel_low_Plates_low34;                          // 0x02E8 (size: 0x8)
    class UStaticMeshComponent* Tube_Panel_low_Plates_low33;                          // 0x02F0 (size: 0x8)
    class UStaticMeshComponent* Tube_Panel_low_Plates_low32;                          // 0x02F8 (size: 0x8)
    class UStaticMeshComponent* Tube_Panel_low_Plates_low31;                          // 0x0300 (size: 0x8)
    class UStaticMeshComponent* Tube_Panel_low_Plates_low30;                          // 0x0308 (size: 0x8)
    class UStaticMeshComponent* Tube_Panel_low_Plates_low29;                          // 0x0310 (size: 0x8)
    class UStaticMeshComponent* Tube_Panel_low_Plates_low28;                          // 0x0318 (size: 0x8)
    class UStaticMeshComponent* Tube_Panel_low_Plates_low27;                          // 0x0320 (size: 0x8)
    class UStaticMeshComponent* Tube_Panel_low_Plates_low26;                          // 0x0328 (size: 0x8)
    class UStaticMeshComponent* Tube_Panel_low_Plates_low25;                          // 0x0330 (size: 0x8)
    class UStaticMeshComponent* Tube_Panel_low_Plates_low24;                          // 0x0338 (size: 0x8)
    class UStaticMeshComponent* Tube_Panel_low_Plates_low23;                          // 0x0340 (size: 0x8)
    class UStaticMeshComponent* Tube_Panel_low_Plates_low22;                          // 0x0348 (size: 0x8)
    class UStaticMeshComponent* Tube_Panel_low_Plates_low21;                          // 0x0350 (size: 0x8)
    class UStaticMeshComponent* Tube_Panel_low_Plates_low20;                          // 0x0358 (size: 0x8)
    class UStaticMeshComponent* Tube_Panel_low_Plates_low19;                          // 0x0360 (size: 0x8)
    class UStaticMeshComponent* Tube_Panel_low_Plates_low18;                          // 0x0368 (size: 0x8)
    class UStaticMeshComponent* Tube_Panel_low_Plates_low17;                          // 0x0370 (size: 0x8)
    class UStaticMeshComponent* Tube_Panel_low_Plates_low16;                          // 0x0378 (size: 0x8)
    class UStaticMeshComponent* Tube_Panel_low_Plates_low15;                          // 0x0380 (size: 0x8)
    class UStaticMeshComponent* Tube_Panel_low_Plates_low14;                          // 0x0388 (size: 0x8)
    class UStaticMeshComponent* Tube_Panel_low_Plates_low13;                          // 0x0390 (size: 0x8)
    class UStaticMeshComponent* Tube_Panel_low_Plates_low12;                          // 0x0398 (size: 0x8)
    class UStaticMeshComponent* Tube_Panel_low_Plates_low11;                          // 0x03A0 (size: 0x8)

}; // Size: 0x3A8

#endif
