#ifndef UE4SS_SDK_BP_Connector_3_HPP
#define UE4SS_SDK_BP_Connector_3_HPP

class ABP_Connector_3_C : public AActor
{
    class UStaticMeshComponent* StaticMesh3;                                          // 0x0220 (size: 0x8)
    class UStaticMeshComponent* StaticMesh2;                                          // 0x0228 (size: 0x8)
    class UStaticMeshComponent* StaticMesh1;                                          // 0x0230 (size: 0x8)
    class UStaticMeshComponent* StaticMesh;                                           // 0x0238 (size: 0x8)
    class USceneComponent* SharedRoot;                                                // 0x0240 (size: 0x8)

}; // Size: 0x248

#endif
