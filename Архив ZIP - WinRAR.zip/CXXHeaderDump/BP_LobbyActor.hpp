#ifndef UE4SS_SDK_BP_LobbyActor_HPP
#define UE4SS_SDK_BP_LobbyActor_HPP

class ABP_LobbyActor_C : public APawn
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x0280 (size: 0x8)
    class UWidgetComponent* Widget;                                                   // 0x0288 (size: 0x8)
    class UWidgetComponent* Keyboard;                                                 // 0x0290 (size: 0x8)
    class UMotionControllerComponent* MotionController;                               // 0x0298 (size: 0x8)
    class UMotionControllerComponent* MotionController1;                              // 0x02A0 (size: 0x8)
    class UCameraComponent* Camera;                                                   // 0x02A8 (size: 0x8)
    class USceneComponent* Scene;                                                     // 0x02B0 (size: 0x8)
    class UWidgetInteractionComponent* WidgetInteraction1;                            // 0x02B8 (size: 0x8)
    class UWidgetInteractionComponent* WidgetInteraction;                             // 0x02C0 (size: 0x8)
    class UWBP_Keyboard_Basic_C* WBP_Keyboard_Basic;                                  // 0x02C8 (size: 0x8)
    class UNiagaraComponent* LeftBeam;                                                // 0x02D0 (size: 0x8)
    class UNiagaraComponent* RightBeam;                                               // 0x02D8 (size: 0x8)

    void Update Beam();
    void ToggleWidgetInteraction();
    void RefreshFocus();
    void InpActEvt_Use_K2Node_InputActionEvent_4(FKey Key);
    void InpActEvt_Use_K2Node_InputActionEvent_3(FKey Key);
    void InpActEvt_Interact_K2Node_InputActionEvent_2(FKey Key);
    void InpActEvt_Secondary_K2Node_InputActionEvent_1(FKey Key);
    void InpActEvt_Secondary_K2Node_InputActionEvent_0(FKey Key);
    void OpenSettings();
    void CloseSettings();
    void ToggleKeyboard(bool Hide);
    void ReceiveBeginPlay();
    void ExecuteUbergraph_BP_LobbyActor(int32 EntryPoint);
}; // Size: 0x2E0

#endif
