#ifndef UE4SS_SDK_BP_LadderDoor_HPP
#define UE4SS_SDK_BP_LadderDoor_HPP

class ABP_LadderDoor_C : public AInteractableActor
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x0248 (size: 0x8)
    class UStaticMeshComponent* StaticMesh1;                                          // 0x0250 (size: 0x8)
    float Timeline_0_Open_C18602FD496D06C0331F5A926BAF0D59;                           // 0x0258 (size: 0x4)
    TEnumAsByte<ETimelineDirection::Type> Timeline_0__Direction_C18602FD496D06C0331F5A926BAF0D59; // 0x025C (size: 0x1)
    class UTimelineComponent* Timeline_0;                                             // 0x0260 (size: 0x8)
    bool Opened;                                                                      // 0x0268 (size: 0x1)

    void OnRep_Opened();
    void Timeline_0__FinishedFunc();
    void Timeline_0__UpdateFunc();
    void OnActorUsed(class ACharacter* Character);
    void OpenDoor();
    void ReceiveBeginPlay();
    void MC_Sound(class USoundBase* Sound);
    void ExecuteUbergraph_BP_LadderDoor(int32 EntryPoint);
}; // Size: 0x269

#endif
