#ifndef UE4SS_SDK_Level0_HPP
#define UE4SS_SDK_Level0_HPP

class ALevel0_C : public ALevelScriptActor
{
}; // Size: 0x228

#endif
