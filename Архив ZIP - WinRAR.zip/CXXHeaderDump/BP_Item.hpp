#ifndef UE4SS_SDK_BP_Item_HPP
#define UE4SS_SDK_BP_Item_HPP

class ABP_Item_C : public AActor
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x0220 (size: 0x8)
    class UStaticMeshComponent* BaseMesh;                                             // 0x0228 (size: 0x8)
    class USceneComponent* DefaultSceneRoot;                                          // 0x0230 (size: 0x8)
    FName ID;                                                                         // 0x0238 (size: 0x8)
    bool IsConsumable;                                                                // 0x0240 (size: 0x1)
    class UMaterialInterface* Material;                                               // 0x0248 (size: 0x8)
    class UMaterialInterface* FOVMaterial;                                            // 0x0250 (size: 0x8)

    void SetMaterial(bool EnabledFOV);
    void UseItem();
    void UnHide();
    void OnFinishConsume(class AFancyCharacter* Player);
    void ReceiveBeginPlay();
    void OnEventLoaded(uint8 EventType);
    void ToggleEvent(bool Enable);
    void ExecuteUbergraph_BP_Item(int32 EntryPoint);
}; // Size: 0x258

#endif
