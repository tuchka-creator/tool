#ifndef UE4SS_SDK_EasyVoiceChat_HPP
#define UE4SS_SDK_EasyVoiceChat_HPP

class UVoiceFunctionLibrary : public UBlueprintFunctionLibrary
{

    TArray<class APawn*> GetAllPawnsFromState(class UObject* WorldContextObject, class APawn* CurrentPlayer, float Distance);
}; // Size: 0x28

class UVoipAudioComponent : public UVoipListenerSynthComponent
{

    void PlayVoiceData(const TArray<uint8>& CompressedVoiceData);
}; // Size: 0x740

class UVoipManagerComponent : public UActorComponent
{
    FVoipManagerComponentVoiceGenerated VoiceGenerated;                               // 0x00B0 (size: 0x10)
    void VoiceGenerated(const TArray<uint8>& VoiceData, const float MicLevel);
    FVoipManagerComponentPlayerTalking PlayerTalking;                                 // 0x00C0 (size: 0x10)
    void PlayerStartTalking();
    FVoipManagerComponentPlayerStopTalking PlayerStopTalking;                         // 0x00D0 (size: 0x10)
    void PlayerStopTalking();
    float StopTalkingThreshold;                                                       // 0x016C (size: 0x4)
    bool bAutoSetConsoleVariables;                                                    // 0x0170 (size: 0x1)
    float SilenceDetectionThreshold;                                                  // 0x0174 (size: 0x4)
    float NoiseGateThreshold;                                                         // 0x0178 (size: 0x4)
    float VoiceBufferDelay;                                                           // 0x017C (size: 0x4)

    void OnVoiceGeneratedBP(const TArray<uint8>& VoiceBuffer, const float MicLevel);
    void OnPlayerStopTalking();
    void OnPlayerStartTalking();
    bool InitVoice(class AController* Controller);
    TArray<FString> GetCaptureDevices();
    bool ChangeAudioCaptureDevice(FString NewDeviceName);
}; // Size: 0x188

#endif
