#ifndef UE4SS_SDK_HorrorEngine_Footstep_HPP
#define UE4SS_SDK_HorrorEngine_Footstep_HPP

struct FHorrorEngine_Footstep
{
    class USoundBase* Default_15_C48DDE994EBD7B22407EBF9A51552E64;                    // 0x0000 (size: 0x8)
    class USoundBase* Carpet_16_D9AC94294AA09F365B10CF970FB8A673;                     // 0x0008 (size: 0x8)
    class USoundBase* Dirt_17_DFB1BDA64BA89ACCD4EEA18B2C933EFB;                       // 0x0010 (size: 0x8)
    class USoundBase* Grass_18_28D6EE9B46295A0B35A766B0A4BC8F7E;                      // 0x0018 (size: 0x8)
    class USoundBase* Metal_19_91429E6C449EDFB3C456BAB949AB81F5;                      // 0x0020 (size: 0x8)
    class USoundBase* Rock_20_BB5E7F0146806923ED47EA8B488A9F5F;                       // 0x0028 (size: 0x8)
    class USoundBase* Tile_21_AFC98EFE43E389202217B4BD5A8C1E10;                       // 0x0030 (size: 0x8)
    class USoundBase* Water_37_B06FBDBB448E67AEF3FECDA5CA6D9453;                      // 0x0038 (size: 0x8)
    class USoundBase* Pool_46_9E9CC55B4EABB94EFD8E92BE1337089F;                       // 0x0040 (size: 0x8)
    class USoundBase* Wood_56_89FC1AE84E44EAB817860E8C9B8D28DF;                       // 0x0048 (size: 0x8)
    class USoundBase* DefaultJump_24_53767A594F254CCA0A19F39349E47AE2;                // 0x0050 (size: 0x8)
    class USoundBase* CarpetJump_25_0B851FF84FDF6EF0299B518EFB91C6FB;                 // 0x0058 (size: 0x8)
    class USoundBase* DirtJump_26_4A65275F452CAA9F2AD8FEB1A9F05F54;                   // 0x0060 (size: 0x8)
    class USoundBase* GrassJump_27_8CEF696A467AAA9B640F06A587148008;                  // 0x0068 (size: 0x8)
    class USoundBase* MetalJump_28_6FCBF39340AC825002E0CDA691174E11;                  // 0x0070 (size: 0x8)
    class USoundBase* RockJump_33_DE3D75F04E59E209137BACBA489617AA;                   // 0x0078 (size: 0x8)
    class USoundBase* TileJump_34_3190DA5E4652277987C8B1A9D07D8B82;                   // 0x0080 (size: 0x8)
    class USoundBase* WaterJump_41_5C865EAF41C078701291F59FAA91BCC1;                  // 0x0088 (size: 0x8)
    class USoundBase* PoolJump_48_ACE1D73C46978045A4DB3E958D139FD2;                   // 0x0090 (size: 0x8)
    class USoundBase* WoodJump_57_0B49DDCD4CC5856B17D524BF9E28121B;                   // 0x0098 (size: 0x8)

}; // Size: 0xA0

#endif
