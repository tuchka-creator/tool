#ifndef UE4SS_SDK_BP_CrossplayWarningFlow_HPP
#define UE4SS_SDK_BP_CrossplayWarningFlow_HPP

class UBP_CrossplayWarningFlow_C : public UFancyUserFlow
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x00A8 (size: 0x8)
    bool bUseNonModalMessage;                                                         // 0x00B0 (size: 0x1)

    void Run();
    void ExecuteUbergraph_BP_CrossplayWarningFlow(int32 EntryPoint);
}; // Size: 0xB1

#endif
