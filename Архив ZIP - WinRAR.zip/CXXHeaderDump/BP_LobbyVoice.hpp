#ifndef UE4SS_SDK_BP_LobbyVoice_HPP
#define UE4SS_SDK_BP_LobbyVoice_HPP

class ABP_LobbyVoice_C : public AActor
{
    class UVoipAudioComponent* VoipAudio;                                             // 0x0220 (size: 0x8)
    class USceneComponent* DefaultSceneRoot;                                          // 0x0228 (size: 0x8)

}; // Size: 0x230

#endif
