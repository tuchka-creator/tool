#ifndef UE4SS_SDK_AnimBP_Smiler_HPP
#define UE4SS_SDK_AnimBP_Smiler_HPP

class UAnimBP_Smiler_C : public UAnimInstance
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x02C0 (size: 0x8)
    FAnimNode_Root AnimGraphNode_Root;                                                // 0x02C8 (size: 0x30)
    FAnimNode_Slot AnimGraphNode_Slot;                                                // 0x02F8 (size: 0x48)
    FAnimNode_TransitionResult AnimGraphNode_TransitionResult_1;                      // 0x0340 (size: 0x28)
    FAnimNode_TransitionResult AnimGraphNode_TransitionResult;                        // 0x0368 (size: 0x28)
    FAnimNode_BlendSpacePlayer AnimGraphNode_BlendSpacePlayer;                        // 0x0390 (size: 0xE8)
    FAnimNode_StateResult AnimGraphNode_StateResult_1;                                // 0x0478 (size: 0x30)
    FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer;                            // 0x04A8 (size: 0x80)
    FAnimNode_StateResult AnimGraphNode_StateResult;                                  // 0x0528 (size: 0x30)
    FAnimNode_StateMachine AnimGraphNode_StateMachine;                                // 0x0558 (size: 0xB0)
    float Speed;                                                                      // 0x0608 (size: 0x4)

    void AnimGraph(FPoseLink& AnimGraph);
    void EvaluateGraphExposedInputs_ExecuteUbergraph_AnimBP_Smiler_AnimGraphNode_TransitionResult_99D058004D9CA2B9BBC01D917DB582C3();
    void EvaluateGraphExposedInputs_ExecuteUbergraph_AnimBP_Smiler_AnimGraphNode_TransitionResult_3A2998A74CABA1A1750B2FB90F27C93B();
    void BlueprintUpdateAnimation(float DeltaTimeX);
    void ExecuteUbergraph_AnimBP_Smiler(int32 EntryPoint);
}; // Size: 0x60C

#endif
