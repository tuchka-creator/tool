#ifndef UE4SS_SDK_BP_LightFade_Box_HPP
#define UE4SS_SDK_BP_LightFade_Box_HPP

class ABP_LightFade_Box_C : public ATriggerBox
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x0228 (size: 0x8)

    void ReceiveActorBeginOverlap(class AActor* OtherActor);
    void ReceiveActorEndOverlap(class AActor* OtherActor);
    void ExecuteUbergraph_BP_LightFade_Box(int32 EntryPoint);
}; // Size: 0x230

#endif
