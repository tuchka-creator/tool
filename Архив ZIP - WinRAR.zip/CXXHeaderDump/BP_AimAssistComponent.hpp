#ifndef UE4SS_SDK_BP_AimAssistComponent_HPP
#define UE4SS_SDK_BP_AimAssistComponent_HPP

class UBP_AimAssistComponent_C : public UAimAssistComponent
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x01B8 (size: 0x8)

    bool CheckCanMove();
    void ReceiveBeginPlay();
    void OnAimAssistDeviceEnabled(bool IsGamepad);
    void ExecuteUbergraph_BP_AimAssistComponent(int32 EntryPoint);
}; // Size: 0x1C0

#endif
