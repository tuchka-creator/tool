#ifndef UE4SS_SDK_BPFL_TelemetryUtilities_HPP
#define UE4SS_SDK_BPFL_TelemetryUtilities_HPP

class UBPFL_TelemetryUtilities_C : public UBlueprintFunctionLibrary
{

    void RefreshGameplayActivityTelemetryData(class APlayerState* NewPlayerState, class UObject* __WorldContext);
    void SendQuitGameTelemetryEvent(class UObject* __WorldContext);
    void SendDisconnectTelemetryEvent(EFancyPlayerDisconnectReason DisconnectReason, class UObject* __WorldContext);
}; // Size: 0x28

#endif
