#ifndef UE4SS_SDK_FluidForceImpulse_HPP
#define UE4SS_SDK_FluidForceImpulse_HPP

struct FFluidForceImpulse
{
    FVector WorldPosition_32_C9A94C02422D8BF40DF6B1BB2A0D8CBC;                        // 0x0000 (size: 0xC)
    float ForceRadius_31_C31B527C4C367A5CA5E1DF8E49E76234;                            // 0x000C (size: 0x4)
    float ForceStrength_30_2CAA30794D1EFF60AE1C3491D011CECF;                          // 0x0010 (size: 0x4)
    class UMaterialInterface* MaterialOverride_24_5A792CE8489A59E5D9B24F9E4DCFE94A;   // 0x0018 (size: 0x8)
    float Lifetime_34_C2749C1449C41D4F236BCBAF6ED34113;                               // 0x0020 (size: 0x4)
    float StrengthoverLifePower_41_85B52C994A7ED323A34BF4BBCB0DFA0F;                  // 0x0024 (size: 0x4)
    FFluidForceImpulseTimedEffects TimedWaterDropSplashes_38_2CB1456B483AEF3A52677AAF4152E31E; // 0x0028 (size: 0x28)

}; // Size: 0x50

#endif
