#ifndef UE4SS_SDK_BP_MainMenu_Shake_HPP
#define UE4SS_SDK_BP_MainMenu_Shake_HPP

class UBP_MainMenu_Shake_C : public UCameraShakeBase
{
}; // Size: 0xB0

#endif
