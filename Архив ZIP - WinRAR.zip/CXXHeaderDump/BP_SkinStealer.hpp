#ifndef UE4SS_SDK_BP_SkinStealer_HPP
#define UE4SS_SDK_BP_SkinStealer_HPP

class ABP_SkinStealer_C : public ACharacter
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x04C0 (size: 0x8)
    class UFancyEntitySightingComponent* FancyEntitySighting;                         // 0x04C8 (size: 0x8)
    class USceneComponent* EyeSight;                                                  // 0x04D0 (size: 0x8)
    class UCapsuleComponent* KillPlayer;                                              // 0x04D8 (size: 0x8)
    class UBoxComponent* DisguiseBox;                                                 // 0x04E0 (size: 0x8)
    class UAudioComponent* Audio;                                                     // 0x04E8 (size: 0x8)
    float SprintSpeed_Speed_4EF7DDFF417BE1DA0DDFEA957BD5EBD1;                         // 0x04F0 (size: 0x4)
    TEnumAsByte<ETimelineDirection::Type> SprintSpeed__Direction_4EF7DDFF417BE1DA0DDFEA957BD5EBD1; // 0x04F4 (size: 0x1)
    class UTimelineComponent* SprintSpeed;                                            // 0x04F8 (size: 0x8)
    float DissolvePlayer_Dissolve_1FCDCCB74BDEEB8C17C6B4A99E6DD277;                   // 0x0500 (size: 0x4)
    TEnumAsByte<ETimelineDirection::Type> DissolvePlayer__Direction_1FCDCCB74BDEEB8C17C6B4A99E6DD277; // 0x0504 (size: 0x1)
    class UTimelineComponent* DissolvePlayer;                                         // 0x0508 (size: 0x8)
    bool ShouldMove;                                                                  // 0x0510 (size: 0x1)
    class UBehaviorTree* Behavior Tree;                                               // 0x0518 (size: 0x8)
    bool CanAttack;                                                                   // 0x0520 (size: 0x1)
    bool IsDisguised;                                                                 // 0x0521 (size: 0x1)
    TSubclassOf<class UAnimInstance> SkinStealerAnimBP;                               // 0x0528 (size: 0x8)
    TSubclassOf<class UAnimInstance> PlayerAnimBP;                                    // 0x0530 (size: 0x8)
    class UMaterialInstanceDynamic* Material;                                         // 0x0538 (size: 0x8)
    float SpeedAddition;                                                              // 0x0540 (size: 0x4)
    float WalkSpeed;                                                                  // 0x0544 (size: 0x4)
    float SprintingSpeed;                                                             // 0x0548 (size: 0x4)
    bool SetExtraHearing;                                                             // 0x054C (size: 0x1)
    class UCostume* Player Costume;                                                   // 0x0550 (size: 0x8)

    void OnRep_Player Costume();
    void SetPlayerMaterials(class ABPCharacter_Demo_C* Player Character);
    void CanSeePlayer(class ABPCharacter_Demo_C* Target, bool& CanSee);
    void OnRep_IsDisguised();
    void StopMovement();
    void LookAtEntity(class ABPCharacter_Demo_C* Target);
    void DissolvePlayer__FinishedFunc();
    void DissolvePlayer__UpdateFunc();
    void SprintSpeed__FinishedFunc();
    void SprintSpeed__UpdateFunc();
    void ReceiveBeginPlay();
    void StartSound();
    void StopSound();
    void AttackPlayer(class ABPCharacter_Demo_C* Player);
    void MC_Jumpscare();
    void BndEvt__BP_SkinStealer_DisguiseBox_K2Node_ComponentBoundEvent_0_ComponentBeginOverlapSignature__DelegateSignature(class UPrimitiveComponent* OverlappedComponent, class AActor* OtherActor, class UPrimitiveComponent* OtherComp, int32 OtherBodyIndex, bool bFromSweep, const FHitResult& SweepResult);
    void BndEvt__BP_SkinStealer_KillPlayer_K2Node_ComponentBoundEvent_1_ComponentBeginOverlapSignature__DelegateSignature(class UPrimitiveComponent* OverlappedComponent, class AActor* OtherActor, class UPrimitiveComponent* OtherComp, int32 OtherBodyIndex, bool bFromSweep, const FHitResult& SweepResult);
    void BndEvt__BP_SkinStealer_KillPlayer_K2Node_ComponentBoundEvent_2_ComponentEndOverlapSignature__DelegateSignature(class UPrimitiveComponent* OverlappedComponent, class AActor* OtherActor, class UPrimitiveComponent* OtherComp, int32 OtherBodyIndex);
    void Jumpscare(class ABPCharacter_Demo_C* Player);
    void MC_KillAnimation(class ABPCharacter_Demo_C* Target);
    void UpdateEvent();
    void Dissolve();
    void ToggleSprint(bool IsSprinting);
    void MC_Material();
    void ExecuteUbergraph_BP_SkinStealer(int32 EntryPoint);
}; // Size: 0x558

#endif
