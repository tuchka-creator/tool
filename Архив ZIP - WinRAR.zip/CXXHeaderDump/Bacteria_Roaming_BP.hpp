#ifndef UE4SS_SDK_Bacteria_Roaming_BP_HPP
#define UE4SS_SDK_Bacteria_Roaming_BP_HPP

class ABacteria_Roaming_BP_C : public ACharacter
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x04C0 (size: 0x8)
    class USceneComponent* EyeSight;                                                  // 0x04C8 (size: 0x8)
    class USphereComponent* KillPlayer;                                               // 0x04D0 (size: 0x8)
    class UAudioComponent* Audio;                                                     // 0x04D8 (size: 0x8)
    bool ShouldMove;                                                                  // 0x04E0 (size: 0x1)
    int32 MinutesElapsed;                                                             // 0x04E4 (size: 0x4)
    bool CanAttack;                                                                   // 0x04E8 (size: 0x1)
    bool ShouldReset;                                                                 // 0x04E9 (size: 0x1)
    FVector StartingLocation;                                                         // 0x04EC (size: 0xC)
    FTimerHandle ShakeTimer;                                                          // 0x04F8 (size: 0x8)
    float CurrentSoundTime;                                                           // 0x0500 (size: 0x4)
    TArray<float> ShakeTimes;                                                         // 0x0508 (size: 0x10)
    FTimerHandle RotateTimer;                                                         // 0x0518 (size: 0x8)
    TArray<class ABP_Bacteria_RoomPoint_C*> RoamingPoints;                            // 0x0520 (size: 0x10)
    class ABP_Bacteria_RoomPoint_C* CurrentPoint;                                     // 0x0530 (size: 0x8)
    FVector RoamingTeleport;                                                          // 0x0538 (size: 0xC)
    FTimerHandle TeleportTimer;                                                       // 0x0548 (size: 0x8)
    FTimerHandle TimerHandle;                                                         // 0x0550 (size: 0x8)
    bool ReduceVision;                                                                // 0x0558 (size: 0x1)
    bool AutoPatrol;                                                                  // 0x0559 (size: 0x1)
    bool RandomPatrolLocation;                                                        // 0x055A (size: 0x1)

    void CheckPlayersTimer();
    void CanSeePlayer(class ABPCharacter_Demo_C* Target, bool& CanSee);
    void TeleportToRoam();
    void GetRoamLocation(class ABP_Bacteria_RoomPoint_C*& RoamPoint);
    void CheckShakeTime();
    void StopMovement();
    void LookAtEntity(class ABPCharacter_Demo_C* Target);
    void GetClosestPlayer(class ABPCharacter_Demo_C*& Closest);
    void UpdateSpeed();
    void ReceiveBeginPlay();
    void StartSound();
    void StopSound();
    void FaceClosestPlayer();
    void AttackPlayer(class ABPCharacter_Demo_C* Player);
    void MC_KillSound();
    void MC_KillAnimation();
    void HasSeenPlayer();
    void SetShouldPatrol();
    void SetSpeed(float Speed);
    void UpdateToPatrol();
    void BndEvt__Bacteria_Roaming_BP_KillPlayer_K2Node_ComponentBoundEvent_0_ComponentBeginOverlapSignature__DelegateSignature(class UPrimitiveComponent* OverlappedComponent, class AActor* OtherActor, class UPrimitiveComponent* OtherComp, int32 OtherBodyIndex, bool bFromSweep, const FHitResult& SweepResult);
    void Activate();
    void ExecuteUbergraph_Bacteria_Roaming_BP(int32 EntryPoint);
}; // Size: 0x55B

#endif
