#ifndef UE4SS_SDK_BP_Firework_Shake_HPP
#define UE4SS_SDK_BP_Firework_Shake_HPP

class UBP_Firework_Shake_C : public UMatineeCameraShake
{
}; // Size: 0x1B0

#endif
