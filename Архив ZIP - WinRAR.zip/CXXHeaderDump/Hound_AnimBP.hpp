#ifndef UE4SS_SDK_Hound_AnimBP_HPP
#define UE4SS_SDK_Hound_AnimBP_HPP

class UHound_AnimBP_C : public UAnimInstance
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x02C0 (size: 0x8)
    FAnimNode_Root AnimGraphNode_Root;                                                // 0x02C8 (size: 0x30)
    FAnimNode_BlendSpacePlayer AnimGraphNode_BlendSpacePlayer;                        // 0x02F8 (size: 0xE8)
    FAnimNode_StateResult AnimGraphNode_StateResult;                                  // 0x03E0 (size: 0x30)
    FAnimNode_StateMachine AnimGraphNode_StateMachine;                                // 0x0410 (size: 0xB0)
    FAnimNode_Slot AnimGraphNode_Slot;                                                // 0x04C0 (size: 0x48)
    float Speed;                                                                      // 0x0508 (size: 0x4)

    void AnimGraph(FPoseLink& AnimGraph);
    void BlueprintUpdateAnimation(float DeltaTimeX);
    void ExecuteUbergraph_Hound_AnimBP(int32 EntryPoint);
}; // Size: 0x50C

#endif
