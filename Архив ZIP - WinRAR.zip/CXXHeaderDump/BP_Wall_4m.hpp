#ifndef UE4SS_SDK_BP_Wall_4m_HPP
#define UE4SS_SDK_BP_Wall_4m_HPP

class ABP_Wall_4m_C : public AActor
{
    class UStaticMeshComponent* StaticMesh1;                                          // 0x0220 (size: 0x8)
    class UStaticMeshComponent* StaticMesh;                                           // 0x0228 (size: 0x8)
    class USceneComponent* DefaultSceneRoot;                                          // 0x0230 (size: 0x8)

}; // Size: 0x238

#endif
