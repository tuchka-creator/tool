#ifndef UE4SS_SDK_BP_FL_GameSettings_HPP
#define UE4SS_SDK_BP_FL_GameSettings_HPP

class UBP_FL_GameSettings_C : public UBlueprintFunctionLibrary
{

    void LoadSettings(class UObject* __WorldContext, class UBP_SG_GameSettings_C*& SaveGame);
    void SetHasSeenVHS(class UObject* __WorldContext);
    void Load_ControlSettings(class UObject* __WorldContext, float& Sensitivity, bool& InvertMouse, TEnumAsByte<E_CameraSetting::Type>& CameraSetting, bool& ShowBody, bool& UsingPushToTalk, int32& FOV, bool& SmoothRotation, bool& HideGore, float& Gamma, bool& CameraShake, bool& ShowEventContent, bool& AimAssist, bool& ControllerFeedback, bool& ShowChat);
    void Load/Set_AudioSettings(class UObject* __WorldContext);
}; // Size: 0x28

#endif
