#ifndef UE4SS_SDK_LobbyPS_HPP
#define UE4SS_SDK_LobbyPS_HPP

class ALobbyPS_C : public ABasePS_C
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x0398 (size: 0x8)
    bool CanHostForceLaunchGame?;                                                     // 0x03A0 (size: 0x1)
    int32 Level;                                                                      // 0x03A4 (size: 0x4)
    FLobbyPS_COnLevelChanged OnLevelChanged;                                          // 0x03A8 (size: 0x10)
    void OnLevelChanged(int32 NewLevel);

    void OnRep_Level();
    void Load_Player_ConnectionInfo(bool Client_ReadyStatus);
    void OnRep_Player_ConnectionInfo_OR();
    void OnRep_Player_UserProfile_OR();
    void ToggleReadyStatus();
    void Get_ReadyStatus(bool& ReadyStatus);
    void Set_ReadyStatus(bool ReadyStatus);
    void ReceiveBeginPlay();
    void SR_Toggle_Ready_Status();
    void OC_Init();
    void UpdateLevel(int32 Level);
    void ExecuteUbergraph_LobbyPS(int32 EntryPoint);
    void OnLevelChanged__DelegateSignature(int32 NewLevel);
}; // Size: 0x3B8

#endif
