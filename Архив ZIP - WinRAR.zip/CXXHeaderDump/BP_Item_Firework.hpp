#ifndef UE4SS_SDK_BP_Item_Firework_HPP
#define UE4SS_SDK_BP_Item_Firework_HPP

class ABP_Item_Firework_C : public ABP_Item_C
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x0258 (size: 0x8)
    class UNiagaraComponent* Niagara;                                                 // 0x0260 (size: 0x8)
    class USceneComponent* Sparks;                                                    // 0x0268 (size: 0x8)
    float ExplodeTimer_Explode_CECADC134CDE7D0DEEC0259583FAD28E;                      // 0x0270 (size: 0x4)
    TEnumAsByte<ETimelineDirection::Type> ExplodeTimer__Direction_CECADC134CDE7D0DEEC0259583FAD28E; // 0x0274 (size: 0x1)
    class UTimelineComponent* ExplodeTimer;                                           // 0x0278 (size: 0x8)
    bool CanUse;                                                                      // 0x0280 (size: 0x1)
    float ThrowTime;                                                                  // 0x0284 (size: 0x4)
    class UAudioComponent* SparkSound;                                                // 0x0288 (size: 0x8)

    void ExplodeTimer__FinishedFunc();
    void ExplodeTimer__UpdateFunc();
    void OnNotifyEnd_2A0F3273455CB03AB9B90EA95723A9CF(FName NotifyName);
    void OnNotifyBegin_2A0F3273455CB03AB9B90EA95723A9CF(FName NotifyName);
    void OnInterrupted_2A0F3273455CB03AB9B90EA95723A9CF(FName NotifyName);
    void OnBlendOut_2A0F3273455CB03AB9B90EA95723A9CF(FName NotifyName);
    void OnCompleted_2A0F3273455CB03AB9B90EA95723A9CF(FName NotifyName);
    void OnNotifyEnd_3A4A9B52408959A077D530BA011BC1FC(FName NotifyName);
    void OnNotifyBegin_3A4A9B52408959A077D530BA011BC1FC(FName NotifyName);
    void OnInterrupted_3A4A9B52408959A077D530BA011BC1FC(FName NotifyName);
    void OnBlendOut_3A4A9B52408959A077D530BA011BC1FC(FName NotifyName);
    void OnCompleted_3A4A9B52408959A077D530BA011BC1FC(FName NotifyName);
    void OnNotifyEnd_75A74F3E49D0A9605DCB0DAA1C18ED64(FName NotifyName);
    void OnNotifyBegin_75A74F3E49D0A9605DCB0DAA1C18ED64(FName NotifyName);
    void OnInterrupted_75A74F3E49D0A9605DCB0DAA1C18ED64(FName NotifyName);
    void OnBlendOut_75A74F3E49D0A9605DCB0DAA1C18ED64(FName NotifyName);
    void OnCompleted_75A74F3E49D0A9605DCB0DAA1C18ED64(FName NotifyName);
    void MC_Prime();
    void MC_Throw();
    void UseItem();
    void StartTimer();
    void ExecuteUbergraph_BP_Item_Firework(int32 EntryPoint);
}; // Size: 0x290

#endif
