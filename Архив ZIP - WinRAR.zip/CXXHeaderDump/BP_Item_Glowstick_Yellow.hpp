#ifndef UE4SS_SDK_BP_Item_Glowstick_Yellow_HPP
#define UE4SS_SDK_BP_Item_Glowstick_Yellow_HPP

class ABP_Item_Glowstick_Yellow_C : public ABP_Item_Glowstick_C
{
}; // Size: 0x291

#endif
