#ifndef UE4SS_SDK_BP_Item_Glowstick_HPP
#define UE4SS_SDK_BP_Item_Glowstick_HPP

class ABP_Item_Glowstick_C : public ABP_Item_C
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x0258 (size: 0x8)
    class USpotLightComponent* SpotLight;                                             // 0x0260 (size: 0x8)
    class UBP_Glowstick_Component_C* BP_Glowstick_Component;                          // 0x0268 (size: 0x8)
    class UPointLightComponent* PointLight;                                           // 0x0270 (size: 0x8)
    FRotator DropRotation;                                                            // 0x0278 (size: 0xC)
    TSubclassOf<class ABP_DroppedItem_Glowstick_C> DropClass;                         // 0x0288 (size: 0x8)
    TEnumAsByte<E_GlowstickColor::Type> GlowstickColor;                               // 0x0290 (size: 0x1)

    void GetAdjustedRadius(float Radius, float& Adjusted);
    void GetAdjustedIntensity(float Intensity, float& Adjusted);
    void OnNotifyEnd_AE195271461F08CE34117A8A70C47D64(FName NotifyName);
    void OnNotifyBegin_AE195271461F08CE34117A8A70C47D64(FName NotifyName);
    void OnInterrupted_AE195271461F08CE34117A8A70C47D64(FName NotifyName);
    void OnBlendOut_AE195271461F08CE34117A8A70C47D64(FName NotifyName);
    void OnCompleted_AE195271461F08CE34117A8A70C47D64(FName NotifyName);
    void UseItem();
    void MC_Fire();
    void ReceiveBeginPlay();
    void PlaySubtitle();
    void ReceiveTick(float DeltaSeconds);
    void ReceiveDestroyed();
    void ExecuteUbergraph_BP_Item_Glowstick(int32 EntryPoint);
}; // Size: 0x291

#endif
