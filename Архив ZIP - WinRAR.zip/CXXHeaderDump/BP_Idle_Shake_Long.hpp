#ifndef UE4SS_SDK_BP_Idle_Shake_Long_HPP
#define UE4SS_SDK_BP_Idle_Shake_Long_HPP

class UBP_Idle_Shake_Long_C : public UMatineeCameraShake
{
}; // Size: 0x1B0

#endif
