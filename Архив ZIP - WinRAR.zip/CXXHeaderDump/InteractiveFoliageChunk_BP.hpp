#ifndef UE4SS_SDK_InteractiveFoliageChunk_BP_HPP
#define UE4SS_SDK_InteractiveFoliageChunk_BP_HPP

class AInteractiveFoliageChunk_BP_C : public AActor
{
    class UINTERACTIVE_FoliageComp_BP_C* FoliageComponent;                            // 0x0220 (size: 0x8)
    class UCapsuleComponent* Capsule;                                                 // 0x0228 (size: 0x8)
    class USceneComponent* Scene;                                                     // 0x0230 (size: 0x8)
    class UINTERACTIVE_FoliageComp_BP_C* sourceFoliageComp;                           // 0x0238 (size: 0x8)
    class AInteractiveGrassManager_BP_C* Manager;                                     // 0x0240 (size: 0x8)
    bool replaceWithSourceComponent;                                                  // 0x0248 (size: 0x1)
    bool leaveDefaultComponent;                                                       // 0x0249 (size: 0x1)

    void UserConstructionScript();
}; // Size: 0x24A

#endif
