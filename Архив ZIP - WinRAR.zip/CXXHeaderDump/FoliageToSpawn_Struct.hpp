#ifndef UE4SS_SDK_FoliageToSpawn_Struct_HPP
#define UE4SS_SDK_FoliageToSpawn_Struct_HPP

struct FFoliageToSpawn_Struct
{
    class UStaticMesh* Mesh_2_4B85E981464F940A424618BC4CCAE1F3;                       // 0x0000 (size: 0x8)
    TSubclassOf<class UINTERACTIVE_FoliageComp_BP_C> Component_7_FAE6A52C44B14E4E7DDCD7A18BC43E30; // 0x0008 (size: 0x8)

}; // Size: 0x10

#endif
