#ifndef UE4SS_SDK_BPFL_EntitySighting_HPP
#define UE4SS_SDK_BPFL_EntitySighting_HPP

class UBPFL_EntitySighting_C : public UBlueprintFunctionLibrary
{

    void CallOnEntitySighted_Actor(class AActor* OwningActor, class UObject* __WorldContext);
    void CallOnEntitySighted_Controller(class AController* OwningController, class UObject* __WorldContext);
}; // Size: 0x28

#endif
