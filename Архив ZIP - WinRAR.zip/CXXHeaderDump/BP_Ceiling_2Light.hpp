#ifndef UE4SS_SDK_BP_Ceiling_2Light_HPP
#define UE4SS_SDK_BP_Ceiling_2Light_HPP

class ABP_Ceiling_2Light_C : public AActor
{
    class USpotLightComponent* SpotLight1;                                            // 0x0220 (size: 0x8)
    class USpotLightComponent* SpotLight;                                             // 0x0228 (size: 0x8)
    class UStaticMeshComponent* SM_Ceiling_Light1;                                    // 0x0230 (size: 0x8)
    class UStaticMeshComponent* SM_Ceiling_Light;                                     // 0x0238 (size: 0x8)
    class USceneComponent* DefaultSceneRoot;                                          // 0x0240 (size: 0x8)

}; // Size: 0x248

#endif
