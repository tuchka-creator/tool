#ifndef UE4SS_SDK_BP_Item_BugSpray_HPP
#define UE4SS_SDK_BP_Item_BugSpray_HPP

class ABP_Item_BugSpray_C : public ABP_Item_C
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x0258 (size: 0x8)
    class UNiagaraComponent* Niagara;                                                 // 0x0260 (size: 0x8)

    void OnNotifyEnd_0696912D47A3DC8FA5836F835E2CF98A(FName NotifyName);
    void OnNotifyBegin_0696912D47A3DC8FA5836F835E2CF98A(FName NotifyName);
    void OnInterrupted_0696912D47A3DC8FA5836F835E2CF98A(FName NotifyName);
    void OnBlendOut_0696912D47A3DC8FA5836F835E2CF98A(FName NotifyName);
    void OnCompleted_0696912D47A3DC8FA5836F835E2CF98A(FName NotifyName);
    void UseItem();
    void MC_Spray();
    void Damage_SERVER(class UObject* Target, class AFancyCharacter* Character);
    void ResetCounter();
    void ExecuteUbergraph_BP_Item_BugSpray(int32 EntryPoint);
}; // Size: 0x268

#endif
