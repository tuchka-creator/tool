#ifndef UE4SS_SDK_InGame_UI_HPP
#define UE4SS_SDK_InGame_UI_HPP

class UInGame_UI_C : public UCrosshairWidget
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x0270 (size: 0x8)
    class UWidgetAnimation* Blur;                                                     // 0x0278 (size: 0x8)
    class UBackgroundBlur* BackgroundBlur_103;                                        // 0x0280 (size: 0x8)
    class UImage* BlueprintImage;                                                     // 0x0288 (size: 0x8)
    class UImage* CrosshairImage;                                                     // 0x0290 (size: 0x8)
    class UImage* CrosshairImage_1;                                                   // 0x0298 (size: 0x8)
    class UTextBlock* InteractText;                                                   // 0x02A0 (size: 0x8)
    class UImage* NoteImage;                                                          // 0x02A8 (size: 0x8)
    class UImage* SanityIcon;                                                         // 0x02B0 (size: 0x8)
    class UImage* SanityProgress;                                                     // 0x02B8 (size: 0x8)
    float LastSanity;                                                                 // 0x02C0 (size: 0x4)
    class UCurveLinearColor* ColorCurve;                                              // 0x02C8 (size: 0x8)
    FVector2D LastNoteLocation;                                                       // 0x02D0 (size: 0x8)
    FVector2D LastNoteSize;                                                           // 0x02D8 (size: 0x8)

    void HideMap();
    void ShowMap(class UTexture* NoteTexture);
    void HideNote();
    void ShowNote(class UTexture* NoteTexture);
    void CanClose();
    void PopInMap(class UTexture* Texture, class UStaticMeshComponent* Mesh);
    void ScaleMap(bool Reverse);
    void NoteListener();
    void OnInteract();
    void OnUpdateSanity(float Sanity);
    void PopInNote(class UTexture* Texture, class UStaticMeshComponent* Mesh);
    void ScaleNote(bool Reverse);
    void Construct();
    void ExecuteUbergraph_InGame_UI(int32 EntryPoint);
}; // Size: 0x2E0

#endif
