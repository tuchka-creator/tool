#ifndef UE4SS_SDK_BP_FindSessionFlow_HPP
#define UE4SS_SDK_BP_FindSessionFlow_HPP

class UBP_FindSessionFlow_C : public UFancyUserFlow
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x00A8 (size: 0x8)
    TArray<FSessionsSearchSetting> Filters;                                           // 0x00B0 (size: 0x10)
    TArray<FBlueprintSessionResult> Results;                                          // 0x00C0 (size: 0x10)
    bool bSuccess;                                                                    // 0x00D0 (size: 0x1)
    bool bCancelled;                                                                  // 0x00D1 (size: 0x1)

    void Cancel();
    void OnFailure_C619554E4A736403075EDF9C053CCDC1(const TArray<FBlueprintSessionResult>& Results);
    void OnSuccess_C619554E4A736403075EDF9C053CCDC1(const TArray<FBlueprintSessionResult>& Results);
    void Run();
    void ExecuteUbergraph_BP_FindSessionFlow(int32 EntryPoint);
}; // Size: 0xD2

#endif
