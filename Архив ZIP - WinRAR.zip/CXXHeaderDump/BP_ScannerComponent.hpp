#ifndef UE4SS_SDK_BP_ScannerComponent_HPP
#define UE4SS_SDK_BP_ScannerComponent_HPP

class UBP_ScannerComponent_C : public UMotionScannerComponent
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x0160 (size: 0x8)
    class UMaterialInstanceDynamic* DMI_Scanner;                                      // 0x0168 (size: 0x8)
    bool bWaveScannerEnabled;                                                         // 0x0170 (size: 0x1)

    void SetWavePosition();
    void EndWaveEvent();
    void StartWaveEvent();
    void ReceiveBeginPlay();
    void ReceiveTick(float DeltaSeconds);
    void UpdateMaterial(bool UseFOV);
    void ExecuteUbergraph_BP_ScannerComponent(int32 EntryPoint);
}; // Size: 0x171

#endif
