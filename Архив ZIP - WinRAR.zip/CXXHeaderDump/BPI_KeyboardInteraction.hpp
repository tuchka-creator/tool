#ifndef UE4SS_SDK_BPI_KeyboardInteraction_HPP
#define UE4SS_SDK_BPI_KeyboardInteraction_HPP

class IBPI_KeyboardInteraction_C : public IInterface
{

    void SetComponentReference(class UWidgetInteractionComponent* WidgetInteractionComponent);
    void SymbolLock();
    void Space();
    void Shift();
    void SendKeyboardText();
    void CapsLock();
}; // Size: 0x28

#endif
