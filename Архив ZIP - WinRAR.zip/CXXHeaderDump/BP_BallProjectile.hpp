#ifndef UE4SS_SDK_BP_BallProjectile_HPP
#define UE4SS_SDK_BP_BallProjectile_HPP

class ABP_BallProjectile_C : public AActor
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x0220 (size: 0x8)
    class UProjectileMovementComponent* ProjectileMovement;                           // 0x0228 (size: 0x8)
    class UStaticMeshComponent* ball;                                                 // 0x0230 (size: 0x8)
    float LastBounceTime;                                                             // 0x0238 (size: 0x4)
    FVector LastBounceLocation;                                                       // 0x023C (size: 0xC)

    void ReceiveDestroyed();
    void BndEvt__BP_BallProjectile_ProjectileMovement_K2Node_ComponentBoundEvent_0_OnProjectileBounceDelegate__DelegateSignature(const FHitResult& ImpactResult, const FVector& ImpactVelocity);
    void BndEvt__BP_BallProjectile_ProjectileMovement_K2Node_ComponentBoundEvent_1_OnProjectileStopDelegate__DelegateSignature(const FHitResult& ImpactResult);
    void SpawnGrabableBall();
    void ExecuteUbergraph_BP_BallProjectile(int32 EntryPoint);
}; // Size: 0x248

#endif
