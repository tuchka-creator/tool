#ifndef UE4SS_SDK_Backrooms_HPP
#define UE4SS_SDK_Backrooms_HPP

#include "Backrooms_enums.hpp"

struct FAimAssistSettings
{
    float HorizontalSmoothnessAwayFromTarget;                                         // 0x0000 (size: 0x4)
    float HorizontalSmoothnessTowardsTarget;                                          // 0x0004 (size: 0x4)
    float HorizontalSmoothnessGranularity;                                            // 0x0008 (size: 0x4)
    bool bVerticalCompensation;                                                       // 0x000C (size: 0x1)
    float VerticalSmoothness;                                                         // 0x0010 (size: 0x4)

}; // Size: 0x14

struct FAimAssistTarget
{
    class AActor* HitActor;                                                           // 0x0000 (size: 0x8)
    float ComponentExtent;                                                            // 0x0008 (size: 0x4)
    FVector Location;                                                                 // 0x000C (size: 0xC)
    FVector ActorLocation;                                                            // 0x0018 (size: 0xC)
    FVector Velocity;                                                                 // 0x0024 (size: 0xC)
    FName Tag;                                                                        // 0x0030 (size: 0x8)

}; // Size: 0x38

struct FBPEuroLowPassFilterTrans
{
    float MinCutoff;                                                                  // 0x0000 (size: 0x4)
    float DeltaCutoff;                                                                // 0x0004 (size: 0x4)
    float CutoffSlope;                                                                // 0x0008 (size: 0x4)

}; // Size: 0x150

struct FBPFancyReportingPlayerRecord
{
    FBPUniqueNetId NetId;                                                             // 0x0000 (size: 0x28)
    FString Name;                                                                     // 0x0028 (size: 0x10)
    EFancyPlatform Platform;                                                          // 0x0038 (size: 0x1)

}; // Size: 0x40

struct FBPLowPassPeakFilter
{
    int32 VelocitySamples;                                                            // 0x0000 (size: 0x4)
    TArray<FVector> VelocitySampleLog;                                                // 0x0008 (size: 0x10)

}; // Size: 0x20

struct FBPVRComponentPosRep
{
    FVector Position;                                                                 // 0x0000 (size: 0xC)
    FRotator Rotation;                                                                // 0x000C (size: 0xC)
    EVRVectorQuantization QuantizationLevel;                                          // 0x0018 (size: 0x1)
    EVRRotationQuantization RotationQuantizationLevel;                                // 0x0019 (size: 0x1)

}; // Size: 0x1C

struct FCollectible : public FTableRowBase
{
    FName ID;                                                                         // 0x0008 (size: 0x8)
    FText Name;                                                                       // 0x0010 (size: 0x18)
    FName Description;                                                                // 0x0028 (size: 0x8)
    int32 Quantity;                                                                   // 0x0030 (size: 0x4)
    class UTexture2D* Icon;                                                           // 0x0038 (size: 0x8)

}; // Size: 0x40

struct FCostumeDismembermentSet
{
    TMap<int32, TSoftObjectPtr<UMaterialInterface>> HandMaterialSwaps;                // 0x0000 (size: 0x50)
    TSoftObjectPtr<UStaticMesh> HandMeshOverride;                                     // 0x0050 (size: 0x28)
    TMap<int32, TSoftObjectPtr<UMaterialInterface>> ArmsMaterialSwaps;                // 0x0078 (size: 0x50)
    TSoftObjectPtr<UStaticMesh> ArmsMeshOverride;                                     // 0x00C8 (size: 0x28)
    TMap<int32, TSoftObjectPtr<UMaterialInterface>> LegsMaterialSwaps;                // 0x00F0 (size: 0x50)
    TSoftObjectPtr<UStaticMesh> LegsMeshOverride;                                     // 0x0140 (size: 0x28)
    TMap<int32, TSoftObjectPtr<UMaterialInterface>> HeadMaterialSwaps;                // 0x0168 (size: 0x50)
    TSoftObjectPtr<UStaticMesh> HeadMeshOverride;                                     // 0x01B8 (size: 0x28)

}; // Size: 0x1E0

struct FCostumeVariant
{
    TSoftObjectPtr<UTexture2D> IconActive;                                            // 0x0000 (size: 0x28)
    TSoftObjectPtr<UTexture2D> IconInactive;                                          // 0x0028 (size: 0x28)
    TSoftObjectPtr<USkeletalMesh> ThirdPersonSkeletalMesh;                            // 0x0050 (size: 0x28)
    TMap<int32, TSoftObjectPtr<UMaterialInterface>> ThirdPersonMaterialSwaps;         // 0x0078 (size: 0x50)
    TSoftClassPtr<UAnimInstance> ThirdPersonAnimationBP;                              // 0x00C8 (size: 0x28)
    TSoftObjectPtr<USkeletalMesh> FirstPersonArmsSkeletalMesh;                        // 0x00F0 (size: 0x28)
    TMap<int32, TSoftObjectPtr<UMaterialInterface>> FirstPersonArmsMaterialSwap;      // 0x0118 (size: 0x50)
    TSoftClassPtr<UAnimInstance> FirstPersonArmsAnimBP;                               // 0x0168 (size: 0x28)
    TSoftObjectPtr<USkeletalMesh> FirstPersonLegsSkeletalMesh;                        // 0x0190 (size: 0x28)
    TMap<int32, TSoftObjectPtr<UMaterialInterface>> FirstPersonLegsMaterialSwap;      // 0x01B8 (size: 0x50)
    TSoftClassPtr<UAnimInstance> FirstPersonLegsAnimBP;                               // 0x0208 (size: 0x28)
    FCostumeDismembermentSet DismembermentSet;                                        // 0x0230 (size: 0x1E0)

}; // Size: 0x410

struct FCostumeWidgetData
{
    class UCostume* Costume;                                                          // 0x0000 (size: 0x8)

}; // Size: 0x8

struct FFancyAudioInputBuffer
{
}; // Size: 0x10

struct FFancyBlockedPlayerMap
{
    TMap<class FUniqueNetIdRepl, class FFancyReportingPlayerRecord> MapInternal;      // 0x0000 (size: 0x50)

}; // Size: 0x50

struct FFancyDLCConfigRow
{
    FString SteamEntitlementId;                                                       // 0x0000 (size: 0x10)

}; // Size: 0x10

struct FFancyGDKCalcCannotCommunicateResult
{
    TArray<class APlayerState*> Result;                                               // 0x0000 (size: 0x10)

}; // Size: 0x10

struct FFancyPlayerNamePlatformDecoratorStyle
{
    TSoftObjectPtr<UTexture2D> Texture;                                               // 0x0000 (size: 0x28)
    int32 MinWidth;                                                                   // 0x0028 (size: 0x4)
    int32 MinHeight;                                                                  // 0x002C (size: 0x4)
    FColor Tint;                                                                      // 0x0030 (size: 0x4)

}; // Size: 0x38

struct FFancyReportedPlayers
{
    TMap<FUniqueNetIdRepl, double> ReportedPlayersAndTime;                            // 0x0000 (size: 0x50)

}; // Size: 0x50

struct FFancyReportingPlayerRecord
{
    FString Name;                                                                     // 0x0000 (size: 0x10)
    EFancyPlatform Platform;                                                          // 0x0010 (size: 0x1)

}; // Size: 0x18

struct FFancySaveGameSlotCacheData
{
    FString Slot;                                                                     // 0x0000 (size: 0x10)
    class USaveGame* SaveGame;                                                        // 0x0010 (size: 0x8)

}; // Size: 0x18

struct FFancyUserFlowLatentFlowResumeData
{
}; // Size: 0x60

struct FItemQuality
{
}; // Size: 0x1

struct FItemStructure : public FTableRowBase
{
    FName ID;                                                                         // 0x0008 (size: 0x8)
    class UTexture2D* Icon;                                                           // 0x0010 (size: 0x8)
    FText Name;                                                                       // 0x0018 (size: 0x18)
    FName Description;                                                                // 0x0030 (size: 0x8)
    EItemType ItemType;                                                               // 0x0038 (size: 0x1)
    EItemRarity Quality;                                                              // 0x0039 (size: 0x1)
    uint8 PriceValue;                                                                 // 0x003A (size: 0x1)
    bool IsStackable;                                                                 // 0x003B (size: 0x1)
    uint8 MaxStackSize;                                                               // 0x003C (size: 0x1)
    UClass* Class;                                                                    // 0x0040 (size: 0x8)
    TSubclassOf<class AInspectableActor> InspectableClass;                            // 0x0048 (size: 0x8)
    bool IsDroppable;                                                                 // 0x0050 (size: 0x1)
    class UStaticMesh* ItemMesh;                                                      // 0x0058 (size: 0x8)
    class UStaticMesh* DroppedMesh;                                                   // 0x0060 (size: 0x8)

}; // Size: 0x68

struct FLIDARDotStruct
{
    class UTextureRenderTarget2D* RenderTarget;                                       // 0x0000 (size: 0x8)
    float timestamp;                                                                  // 0x0008 (size: 0x4)

}; // Size: 0x10

struct FMapEditorItem
{
    TSubclassOf<class AActor> ActorToSpawn;                                           // 0x0000 (size: 0x8)
    FTransform ItemTransform;                                                         // 0x0010 (size: 0x30)
    TArray<class UMaterialInterface*> Materials;                                      // 0x0040 (size: 0x10)

}; // Size: 0x50

struct FMapEditorItemMaterial
{
    TArray<class UMeshComponent*> MeshComponents;                                     // 0x0000 (size: 0x10)
    TArray<class UMaterialInterface*> Materials;                                      // 0x0010 (size: 0x10)

}; // Size: 0x20

struct FMapEditorItems
{
    TArray<FMapEditorItem> Items;                                                     // 0x0000 (size: 0x10)

}; // Size: 0x10

struct FMapEditorSnapping
{
    float Location;                                                                   // 0x0000 (size: 0x4)
    float Rotation;                                                                   // 0x0004 (size: 0x4)
    float Scale;                                                                      // 0x0008 (size: 0x4)

}; // Size: 0xC

struct FMapEditorSteps
{
}; // Size: 0x18

struct FMissionStructure : public FTableRowBase
{
    FName Name;                                                                       // 0x0008 (size: 0x8)
    FText Description;                                                                // 0x0010 (size: 0x18)
    class UTexture2D* Image;                                                          // 0x0028 (size: 0x8)
    int32 DangerClass;                                                                // 0x0030 (size: 0x4)
    float XPEarned;                                                                   // 0x0034 (size: 0x4)
    float XPPenalty;                                                                  // 0x0038 (size: 0x4)
    float TimeCompleted;                                                              // 0x003C (size: 0x4)
    bool CompletedInTime;                                                             // 0x0040 (size: 0x1)
    int32 PlayerDeaths;                                                               // 0x0044 (size: 0x4)
    int32 EntitySightings;                                                            // 0x0048 (size: 0x4)
    int32 LowSanityMoments;                                                           // 0x004C (size: 0x4)
    FString ExtraDataRowName;                                                         // 0x0050 (size: 0x10)

}; // Size: 0x60

struct FProfaneWord : public FTableRowBase
{
    FName Language;                                                                   // 0x0008 (size: 0x8)
    uint8 Severity;                                                                   // 0x0010 (size: 0x1)
    FString Word;                                                                     // 0x0018 (size: 0x10)

}; // Size: 0x28

struct FRadarTargetStruct
{
    class URadarPlayerComponent* Target;                                              // 0x0000 (size: 0x8)
    float Distance;                                                                   // 0x0008 (size: 0x4)
    float Velocity;                                                                   // 0x000C (size: 0x4)
    bool IsTeammate;                                                                  // 0x0010 (size: 0x1)

}; // Size: 0x18

struct FScannerStruct
{
    float ScanRate;                                                                   // 0x0000 (size: 0x4)
    float ScanDistance;                                                               // 0x0004 (size: 0x4)
    float MinSpeedDetected;                                                           // 0x0008 (size: 0x4)
    float TargetDetectOffset;                                                         // 0x000C (size: 0x4)
    float MaxWavePosition;                                                            // 0x0010 (size: 0x4)
    float WaveMultiply;                                                               // 0x0014 (size: 0x4)
    float WavePositionUI;                                                             // 0x0018 (size: 0x4)
    float WaveDistance;                                                               // 0x001C (size: 0x4)

}; // Size: 0x20

struct FTargetStruct
{
    class UStaticMesh* TargetStaticMesh;                                              // 0x0000 (size: 0x8)
    class UMaterialInterface* TargetMaterial;                                         // 0x0008 (size: 0x8)
    float SizeScale;                                                                  // 0x0010 (size: 0x4)

}; // Size: 0x18

struct FTargetsStruct
{
    class UMotionScannerComponent* Target;                                            // 0x0000 (size: 0x8)
    float Distance;                                                                   // 0x0008 (size: 0x4)
    float Velocity;                                                                   // 0x000C (size: 0x4)
    bool IsTeammate;                                                                  // 0x0010 (size: 0x1)

}; // Size: 0x18

struct FTelemetryStruct
{
    float MinDistance;                                                                // 0x0000 (size: 0x4)
    int32 TargetsCount;                                                               // 0x0004 (size: 0x4)

}; // Size: 0x8

struct FVoteData
{
    int32 VotingPlayers;                                                              // 0x0000 (size: 0x4)
    bool bIsUnanimousVote;                                                            // 0x0004 (size: 0x1)
    TMap<class APlayerState*, class bool> PlayerVotingMap;                            // 0x0008 (size: 0x50)
    float Duration;                                                                   // 0x0058 (size: 0x4)
    float CurrentTime;                                                                // 0x005C (size: 0x4)
    bool IsActive;                                                                    // 0x0060 (size: 0x1)

}; // Size: 0x68

struct FVoteParameters
{
    int32 VotingPlayers;                                                              // 0x0000 (size: 0x4)
    float Duration;                                                                   // 0x0004 (size: 0x4)
    bool bIsUnanimousVote;                                                            // 0x0008 (size: 0x1)

}; // Size: 0xC

class ABoatPawn : public AInteractablePawn
{
    class UBoxComponent* RootBoxComponent;                                            // 0x0308 (size: 0x8)
    class UArrowComponent* ArrowComponent;                                            // 0x0310 (size: 0x8)
    class UBoatComponent* BoatComponent;                                              // 0x0318 (size: 0x8)
    class UStaticMeshComponent* BoatMaskMesh;                                         // 0x0320 (size: 0x8)

    class UBoatComponent* GetXShipComponent();
    float GetWaterWorldZ(FVector2D InLocation);
    FVector GetWaterNormal(FVector2D InLocation);
    float GetWaterDensity(FVector2D InLocation);
    void AddRotationInput(float ScaleValue);
}; // Size: 0x328

class AClientInteractableActor : public AInteractableActor
{

    void OnUsed();
}; // Size: 0x248

class AClientInteractablePawn : public AInteractablePawn
{

    void OnUsed();
}; // Size: 0x308

class ACostumeSelector : public AActor
{
    class UCameraComponent* CameraComponent;                                          // 0x0220 (size: 0x8)
    class USceneComponent* ActorOnStageLocation;                                      // 0x0228 (size: 0x8)
    TSubclassOf<class AActor> PlayerCostumeActorClass;                                // 0x0230 (size: 0x8)
    class USceneComponent* ActorLoadingLocation;                                      // 0x0238 (size: 0x8)
    class ACharacter* PlayerCostumeActor;                                             // 0x0240 (size: 0x8)
    ECostumeSelectorFeedbackState FeedbackState;                                      // 0x0248 (size: 0x4)
    ECostumeSelectorFeedbackState TargetFeedbackState;                                // 0x024C (size: 0x4)
    class UUserWidget* Widget;                                                        // 0x0250 (size: 0x8)
    class AActor* PreviousViewTarget;                                                 // 0x0258 (size: 0x8)
    class UCostume* SelectedCostume;                                                  // 0x0260 (size: 0x8)
    TArray<class UCostume*> LoadedCostumeDataAssets;                                  // 0x0268 (size: 0x10)
    TArray<FCostumeWidgetData> CostumeWidgetData;                                     // 0x0278 (size: 0x10)
    class ACharacter* PlayerCostumeActorLoading;                                      // 0x0288 (size: 0x8)

    void TryFireSafeLoadingStateCallback();
    void TransitionToCostumeSelector();
    void TransitionFromCostumeSelector(class AActor* TransitionToViewTarget, const FTransitionFromCostumeSelectorFeedbackCompleteCallback& FeedbackCompleteCallback);
    void StartCostumeSelect(class UUserWidget* CostumeSelectorWidget);
    void ShowLoadingFeedback(const FShowLoadingFeedbackFeedbackCompleteCallback& FeedbackCompleteCallback);
    void ShowLoadedFeedback(const FShowLoadedFeedbackFeedbackCompleteCallback& FeedbackCompleteCallback);
    void SelectCostume(class UCostume* Costume);
    void OnStartedCostumeSelect();
    void OnExitCostumeSelect();
    void HandleTransitionFromCostumeSelectorComplete();
    void HandleFinishedLoadingFeedback();
    void HandleFinishedLoadedFeedback();
    void EndCostumeSelect();
    void ApplySelectedCostume();
}; // Size: 0x320

class ADroppedItem : public AActor
{
    class UStaticMeshComponent* ItemMesh;                                             // 0x0228 (size: 0x8)
    FName ID;                                                                         // 0x0230 (size: 0x8)
    bool StartWithPhysicsEnabled;                                                     // 0x0238 (size: 0x1)
    bool CanPickup;                                                                   // 0x0239 (size: 0x1)
    class USceneComponent* SceneComponent;                                            // 0x0240 (size: 0x8)
    FTimerHandle TimerHandle;                                                         // 0x0248 (size: 0x8)
    FTimerHandle EvaluatePhysicsTimerHandle;                                          // 0x0250 (size: 0x8)

    void UpdatePhysicsLocation();
    void StopPhysics();
    void OnEndFocus();
    void OnBeginFocus();
    void EvaluatePhysics();
}; // Size: 0x258

class ADryLandVolume : public AVolume
{
}; // Size: 0x258

class AFancyCharacter : public ACharacter
{
    bool CanMove;                                                                     // 0x04B8 (size: 0x1)
    float TraceLength;                                                                // 0x04BC (size: 0x4)
    bool bIsDead;                                                                     // 0x04C0 (size: 0x1)
    bool IsUsingItem;                                                                 // 0x04C1 (size: 0x1)
    bool IsLeaning;                                                                   // 0x04C2 (size: 0x1)
    bool CanCollide;                                                                  // 0x04C3 (size: 0x1)
    bool IsOverlapOnly;                                                               // 0x04C4 (size: 0x1)
    bool bEnableCameraShake;                                                          // 0x04C5 (size: 0x1)
    bool bEnableAimAssist;                                                            // 0x04C6 (size: 0x1)
    class ADroppedItem* CurrentFocusedItem;                                           // 0x04C8 (size: 0x8)
    class AInteractablePawn* CurrentInteractingPawn;                                  // 0x04D0 (size: 0x8)
    class APushableActor* CurrentPushableActor;                                       // 0x04D8 (size: 0x8)
    class UFancyCameraComponent* CameraComponent;                                     // 0x04E0 (size: 0x8)
    class UFancySpringArmComponent* SpringArm;                                        // 0x04E8 (size: 0x8)
    class USkeletalMeshComponent* Arms;                                               // 0x04F0 (size: 0x8)
    class UFancyCarrySystemCarrier* CarrySystem;                                      // 0x04F8 (size: 0x8)
    class AActor* CurrentInteractableActor;                                           // 0x0500 (size: 0x8)

    void TryPickup();
    void TogglePlayerVisibility(bool IsHidden);
    void TogglePlayerLegs(bool IsHidden);
    void ToggleBlur(bool ShouldBlur);
    void StopPushing();
    void SetIsOverlapOnly(bool ShouldOverlapOnly);
    void SetCanCollide(bool ShouldCollide);
    void OnSanityUpdate(float Sanity);
    void OnRep_IsOverlapOnly();
    void OnRep_CanCollide();
    void KillPlayer(bool bResetInteractable);
    void InteractCallBackVR(class AActor* Actor);
    void Interact(class AActor* Actor);
    void HideItem(bool IsVisible);
    class AActor* GetCurrentInteractableActor();
    void CheckSpawnedItems();
    void CheckPawn();
    void ChangeCrosshairVisibility(bool IsVisible);
}; // Size: 0x520

class AFancyGameMode : public AGameMode
{
    float SanityDecrementAmount;                                                      // 0x0308 (size: 0x4)
    bool bShouldLowerSanity;                                                          // 0x030C (size: 0x1)

    void OnDecreaseSanity();
}; // Size: 0x318

class AFancyMovablePlayerStart : public APlayerStart
{
}; // Size: 0x250

class AFancyPlayerController : public APlayerController
{

    void PrintLevelTimesToLog();
    void PrintLevelTimes();
    void OnPlayerTravel();
    void HandleKickedBP();
    float GetObjectScreenRadius(class UStaticMeshComponent* MeshComponent);
    EInputMode GetInputMode();
    void ClientHUDInit();
}; // Size: 0x5F0

class AFancyPlayerState : public APlayerState
{
    FFancyPlayerStateOnPlayerStateUpdated OnPlayerStateUpdated;                       // 0x0320 (size: 0x10)
    void OnFancyPlayerStateUpdated();
    class UInventoryComponent* InventoryComponent;                                    // 0x0330 (size: 0x8)
    float Sanity;                                                                     // 0x0338 (size: 0x4)
    float MaxSanity;                                                                  // 0x033C (size: 0x4)
    bool ShouldLowerSanity;                                                           // 0x0340 (size: 0x1)
    EFancyPlatform Platform;                                                          // 0x0341 (size: 0x1)
    bool bHasReceivedBlockedPlayersList;                                              // 0x0342 (size: 0x1)
    TArray<FBPUniqueNetId> BlockedPlayers;                                            // 0x0348 (size: 0x10)

    void UnsubscribeFromPlayerArrayChanged(class UObject* Subscriber);
    void SubscribeToPlayerArrayChanged(class UObject* Subscriber, FSubscribeToPlayerArrayChangedPlayerStateUpdated PlayerStateUpdated);
    void SetPlatform(EFancyPlatform InPlatform);
    void SetBlockedPlayersList(const TArray<FBPUniqueNetId>& InBlockedPlayers);
    void RemoveSanity(float Amount);
    void OnRep_Sanity();
    void OnKillPlayer();
    void InvokePlayerStateUpdatedEvent();
    void HandleUserReportingStatusChanged(const FBPUniqueNetId& NetId);
    void AddSanity(float Amount);
}; // Size: 0x358

class AFancyVideoPlayer : public AActor
{
    class USceneComponent* SceneComponent;                                            // 0x0220 (size: 0x8)
    class UFancyVotingComponent* VotingComponent;                                     // 0x0228 (size: 0x8)
    FFancyVideoPlayerOnVideoStartedDelegate OnVideoStartedDelegate;                   // 0x0230 (size: 0x10)
    void OnVideoStarted();
    FFancyVideoPlayerOnVideoEndedDelegate OnVideoEndedDelegate;                       // 0x0240 (size: 0x10)
    void OnVideoReachedEnd();
    FFancyVideoPlayerOnVideoSuspendedDelegate OnVideoSuspendedDelegate;               // 0x0250 (size: 0x10)
    void OnVideoSuspended();
    FFancyVideoPlayerOnVideoSkippedDelegate OnVideoSkippedDelegate;                   // 0x0260 (size: 0x10)
    void OnVideoSkipped();
    class UBinkMediaPlayer* MediaPlayer;                                              // 0x0270 (size: 0x8)
    class UBinkMediaPlayer* MediaPlayerReference;                                     // 0x0278 (size: 0x8)
    TSubclassOf<class UUserWidget> VideoWidget;                                       // 0x0280 (size: 0x8)
    class UUserWidget* VideoWidgetReference;                                          // 0x0288 (size: 0x8)
    FString CurrentVideo;                                                             // 0x0290 (size: 0x10)
    bool bCanSkip;                                                                    // 0x02B0 (size: 0x1)

    void StopVideoServer();
    void StopVideoClients();
    void SkipVideoServer();
    void SkipVideoClients();
    void SetCanSkip(bool CanSkip);
    void PlayVideoServer(FString MediaFileName, bool AddToQueue);
    void PlayVideoClients(FString MediaFileName, bool AddToQueue);
    void PauseVideoServer();
    void PauseVideoClients();
    void OnVideoStarted();
    void OnVideoEnded();
    void OnSkipVoteFinished(bool Result);
    void OnPlaybackSuspended();
    void OnMediaReachedEnd();
    void OnMediaClosed();
    bool IsPlaying();
    bool CanSkip();
}; // Size: 0x2C0

class AInspectableActor : public AActor
{
    FText Name;                                                                       // 0x0220 (size: 0x18)
    FName Description;                                                                // 0x0238 (size: 0x8)
    int32 Quantity;                                                                   // 0x0240 (size: 0x4)
    class ACharacter* PlayerReference;                                                // 0x0248 (size: 0x8)
    float CameraDistance;                                                             // 0x0250 (size: 0x4)
    FTimerHandle BlurTimerHandle;                                                     // 0x0260 (size: 0x8)
    class USceneComponent* SceneComponent;                                            // 0x0278 (size: 0x8)
    class USceneComponent* FocusTarget;                                               // 0x0280 (size: 0x8)
    class UStaticMeshComponent* Mesh2;                                                // 0x0288 (size: 0x8)
    class UCameraComponent* InspectionCamera;                                         // 0x0290 (size: 0x8)

    void SetViewing();
    void SetPlayerRef(class ACharacter* Ref);
    void SetCameraLocation(class UCameraComponent* CameraComponent);
    class UStaticMeshComponent* GetMesh();
}; // Size: 0x298

class AInteractableActor : public AActor
{
    class USceneComponent* SceneComponent;                                            // 0x0228 (size: 0x8)
    class UStaticMeshComponent* StaticMesh;                                           // 0x0230 (size: 0x8)
    class USoundBase* UsedSound;                                                      // 0x0238 (size: 0x8)
    bool IsUsable;                                                                    // 0x0240 (size: 0x1)
    bool WasUsed;                                                                     // 0x0241 (size: 0x1)
    bool bShouldAimAssist;                                                            // 0x0242 (size: 0x1)

    void ResetUsage();
    void OnUsedServer();
    void OnUsedNotify();
    void OnUsedMulticast();
    void OnUsedAll();
    void OnRep_WasUsed();
    void OnRep_IsUsable();
    void OnInteractStartedLocal();
    void OnEndHighlight();
    void OnBeginHighlight();
    void BlockUsage();
}; // Size: 0x248

class AInteractablePawn : public APawn
{
    class USceneComponent* SceneComponent;                                            // 0x0288 (size: 0x8)
    class UStaticMeshComponent* StaticMesh;                                           // 0x0290 (size: 0x8)
    bool IsUsable;                                                                    // 0x0298 (size: 0x1)
    bool WasUsed;                                                                     // 0x0299 (size: 0x1)
    bool IsPermanentlyDisabled;                                                       // 0x029A (size: 0x1)
    FRotator CachedRotation;                                                          // 0x029C (size: 0xC)
    bool bShouldCameraShake;                                                          // 0x02A8 (size: 0x1)
    float InteractDelay;                                                              // 0x02AC (size: 0x4)
    FVector VROffset;                                                                 // 0x02B0 (size: 0xC)
    bool ShouldCheck;                                                                 // 0x02BC (size: 0x1)
    bool HideCursor;                                                                  // 0x02BD (size: 0x1)
    bool ShouldHidePlayer;                                                            // 0x02BE (size: 0x1)
    bool ShouldStopMovement;                                                          // 0x02BF (size: 0x1)
    class ACharacter* InteractingPlayer;                                              // 0x02C0 (size: 0x8)
    class APlayerController* InteractingController;                                   // 0x02C8 (size: 0x8)
    TSubclassOf<class UCameraShakeBase> IdleShake;                                    // 0x02D0 (size: 0x8)
    bool bShouldAimAssist;                                                            // 0x02D8 (size: 0x1)
    bool bUseInteractableLocationForVoip;                                             // 0x02D9 (size: 0x1)
    class UInteractableCameraComponent* InteractableCameraComponent;                  // 0x02E8 (size: 0x8)
    class UMotionControllerComponent* LeftGrip;                                       // 0x02F0 (size: 0x8)
    class UMotionControllerComponent* RightGrip;                                      // 0x02F8 (size: 0x8)
    class UVoipAudioComponent* InteractableVoipComponent;                             // 0x0300 (size: 0x8)

    void ToggleMouse(bool bHide);
    void SetUsingVR(class ACharacter* Character, bool bPossess);
    void SetCameraPostProcessing(class ACharacter* Character);
    void ResetUsage();
    void OnVRPossess(bool bPossess);
    void OnUsedServer(class ACharacter* Character);
    void OnUsedNotify();
    void OnUsedMulticast();
    void OnUsedAll();
    void OnUnPossess();
    void OnStopInteracting();
    void OnStartInteracting(class ACharacter* Character);
    void OnRep_WasUsed();
    void OnRep_IsUsable();
    void OnPossess();
    void OnPermanentlyDisabled();
    void OnHiddenPossess(class ACharacter* Character);
    void OnAttemptUse(bool CanUse);
    void BlockUsage();
}; // Size: 0x308

class AItemActor : public AActor
{
    FItemStructure Structure;                                                         // 0x0220 (size: 0x68)
    int32 Quantity;                                                                   // 0x0288 (size: 0x4)
    bool IsUseable;                                                                   // 0x028C (size: 0x1)
    bool bPlayUseAnimation;                                                           // 0x028D (size: 0x1)
    class USceneComponent* SceneComponent;                                            // 0x0290 (size: 0x8)
    class UStaticMeshComponent* Mesh2;                                                // 0x0298 (size: 0x8)
    class UAnimationAsset* IdleAnimation;                                             // 0x02A0 (size: 0x8)
    class UAnimationAsset* UseAnimation;                                              // 0x02A8 (size: 0x8)
    class UAnimationAsset* EquipMontage;                                              // 0x02B0 (size: 0x8)
    class UAnimationAsset* UnEquipMontage;                                            // 0x02B8 (size: 0x8)

    void Use();
    void CustomInventoryUse();
}; // Size: 0x2C0

class ALevel0Generator : public AActor
{
    class UStaticMesh* FloorMesh;                                                     // 0x0220 (size: 0x8)
    class UStaticMesh* WallMesh;                                                      // 0x0228 (size: 0x8)
    class UStaticMesh* CeilingMesh;                                                   // 0x0230 (size: 0x8)

    void Generate();
}; // Size: 0x238

class AMapEditorCharacter : public ACharacter
{
    class UCameraComponent* CameraComponent;                                          // 0x04B8 (size: 0x8)

}; // Size: 0x4C0

class AMapEditorGizmo : public AActor
{
    class UStaticMeshComponent* Origin;                                               // 0x0220 (size: 0x8)
    class UStaticMeshComponent* ZAxis;                                                // 0x0228 (size: 0x8)
    class UStaticMeshComponent* XAxis;                                                // 0x0230 (size: 0x8)
    class UStaticMeshComponent* YAxis;                                                // 0x0238 (size: 0x8)
    class UStaticMeshComponent* Yaw;                                                  // 0x0240 (size: 0x8)
    class UStaticMeshComponent* Roll;                                                 // 0x0248 (size: 0x8)
    class UStaticMeshComponent* Pitch;                                                // 0x0250 (size: 0x8)
    class UStaticMeshComponent* ScaleZ;                                               // 0x0258 (size: 0x8)
    class UStaticMeshComponent* ScaleX;                                               // 0x0260 (size: 0x8)
    class UStaticMeshComponent* ScaleY;                                               // 0x0268 (size: 0x8)
    float MovementSlowdown;                                                           // 0x0270 (size: 0x4)

}; // Size: 0x2C0

class AMotionScannerDirector : public AActor
{
    float CheckMotionRate;                                                            // 0x0220 (size: 0x4)
    TArray<class AActor*> IgnoredActorsArr;                                           // 0x0228 (size: 0x10)
    TMap<class FString, class FLIDARDotStruct> NameToRTMap;                           // 0x0238 (size: 0x50)
    TArray<class UMotionScannerComponent*> allMotionComponentsArr;                    // 0x0288 (size: 0x10)
    FTimerHandle checkMotion_Handle;                                                  // 0x0298 (size: 0x8)
    bool bIsLocalController;                                                          // 0x02A0 (size: 0x1)

    void CheckLIDARDots();
}; // Size: 0x2A8

class ANoClipVolume : public AVolume
{
}; // Size: 0x258

class APushableActor : public AInteractableActor
{
    float Density;                                                                    // 0x0248 (size: 0x4)

    TArray<FVector> GetRightBoundingPoints(bool InInvert);
    TArray<FVector> GetForwardBoundingPoints(bool InInvert);
    FVector GetClosesPoint(class AActor* InActor);
}; // Size: 0x250

class ARadarMap : public AInteractablePawn
{
    float CheckMotionRate;                                                            // 0x0308 (size: 0x4)
    TArray<class AActor*> IgnoredActorsArr;                                           // 0x0310 (size: 0x10)
    TArray<class URadarPlayerComponent*> allRadarComponentsArr;                       // 0x0320 (size: 0x10)
    FTimerHandle checkMotion_Handle;                                                  // 0x0330 (size: 0x8)
    bool bIsLocalController;                                                          // 0x0338 (size: 0x1)
    FTimerHandle RegisterComponent_Handle;                                            // 0x0340 (size: 0x8)
    int32 TryRegister;                                                                // 0x0348 (size: 0x4)
    class AMotionScannerDirector* ScannerDirector;                                    // 0x0350 (size: 0x8)
    TArray<FRadarTargetStruct> TargetsArr;                                            // 0x0358 (size: 0x10)
    float CheckTargetsRate;                                                           // 0x0368 (size: 0x4)
    TArray<FRadarTargetStruct> VisibleTargetsArr;                                     // 0x0370 (size: 0x10)
    TArray<FRadarTargetStruct> LastTargetsArr;                                        // 0x0380 (size: 0x10)
    FTelemetryStruct TelemetryScanner;                                                // 0x0390 (size: 0x8)
    bool bResetValue;                                                                 // 0x0398 (size: 0x1)
    float WaveMultiply;                                                               // 0x039C (size: 0x4)

}; // Size: 0x3A0

class AWalkingVolume : public AVolume
{
}; // Size: 0x258

class ICostumeCharacter : public IInterface
{

    void ApplyCostume(class UCostume* Costume);
}; // Size: 0x28

class ICostumeSelectorWidget : public IInterface
{

    void ShowLoadingWheel();
    void SetUp(class ACostumeSelector* CostumeSelectorActor, const TArray<FCostumeWidgetData>& CostumeList);
    void HideLoadingWheel();
}; // Size: 0x28

class IFancyCustomModal : public IInterface
{

    void BindCustomModalCompleteCallback(const FBindCustomModalCompleteCallbackCompleteCallback& CompleteCallback);
}; // Size: 0x28

class IFancyModal : public IInterface
{

    void SetUpMessage(const FText& Message, const FText& Title, const FText& Header, const FText& Button1Label, const FSetUpMessageOnButtonPressed& OnButtonPressed);
    void SetUpChoice(const FText& Message, const FText& Title, const FText& Header, const FText& Button1Label, const FText& Button2Label, const FSetUpChoiceOnButtonPressed& OnButtonPressed);
}; // Size: 0x28

class IFancyUserFlowDelegate : public IInterface
{

    void ShowNonModalMessage(const FText& Message);
    void ResetInputModeToDefault(class UWidget* PreviousFocusedWidget);
}; // Size: 0x28

class IInteractableInterface : public IInterface
{

    void OnActorUsed(class ACharacter* Character);
}; // Size: 0x28

class IMapEditorInterface : public IInterface
{

    void OnUndo();
    void OnScaleChanged(FVector NewScale);
    void OnRelease();
    void OnMaterialLoaded(FMapEditorItemMaterial MapEditorItemMaterial);
    void OnGrabbed();
    void OnDeleted();
}; // Size: 0x28

class UAI_ObjectWC : public UObject
{

    void StartExecute();
    void OnUpdate();
    bool GetWeight();
    void FinishExecute();
}; // Size: 0x28

class UAimAssistComponent : public UActorComponent
{
    TMap<class FName, class FAimAssistSettings> Configuration;                        // 0x00B0 (size: 0x50)
    ECollisionSelectionMethod CollisionMethod;                                        // 0x0100 (size: 0x1)
    TEnumAsByte<ECollisionChannel> CollisionChannel;                                  // 0x0101 (size: 0x1)
    FCollisionProfileName CollisionProfile;                                           // 0x0104 (size: 0x8)
    EAimAssistCastType TargetSeekerCastType;                                          // 0x010C (size: 0x1)
    int32 MaxSphereCastCount;                                                         // 0x0110 (size: 0x4)
    float AimAssistRadius;                                                            // 0x0114 (size: 0x4)
    float ConeAngle;                                                                  // 0x0118 (size: 0x4)
    int32 ConeTraceSubdivision;                                                       // 0x011C (size: 0x4)
    float NearClipDistance;                                                           // 0x0120 (size: 0x4)
    float FarClipDistance;                                                            // 0x0124 (size: 0x4)
    FName PreferredBone;                                                              // 0x0128 (size: 0x8)
    FAimAssistComponentTargetFound TargetFound;                                       // 0x0130 (size: 0x10)
    void AimAssistTargetFound(const class UAimAssistComponent* Sender, FAimAssistTarget AimAssistTarget);
    FAimAssistComponentTargetLost TargetLost;                                         // 0x0140 (size: 0x10)
    void AimAssistTargetLost(const class UAimAssistComponent* Sender, FAimAssistTarget AimAssistTarget);
    bool bCreateReticle;                                                              // 0x0150 (size: 0x1)
    class APlayerController* PlayerController;                                        // 0x0158 (size: 0x8)
    class AFancyCharacter* Character;                                                 // 0x0160 (size: 0x8)
    class UCharacterMovementComponent* CharacterMovement;                             // 0x0168 (size: 0x8)

    FRotator ProcessAimAssist(const float DeltaTime);
    void OnAimAssistDeviceEnabled(bool IsGamepad);
    FAimAssistTarget GetCurrentTargetOrDefault();
    bool CheckCanMove();
}; // Size: 0x1B8

class UBackroomsBPFunctionLibrary : public UBlueprintFunctionLibrary
{

    void SetLogValue(FString Key, FString Value);
    void SetCurrentLevelLogs(FString LevelName);
    void SaveToClipboard(FString ToClipboard);
    void ResetWorldTime(const class AGameMode* GameMode);
    void ResetInputSettings();
    void ReloadBindings();
    class UTimelineComponent* PlayRate(class UTimelineComponent* Timeline, float Sec);
    void PatchMissingInputActions(TArray<FInputActionKeyMapping> NewActions);
    void LogStringWithPlayerId(const class UObject* PawnOrComponent, FString Text);
    float LoadXP();
    void K2_IsTearingDown(class UObject* caller, bool& isTearingDown);
    bool IsSteamDeckActive();
    bool IsNoHMDMode();
    float GetViewDistanceScale();
    int32 GetSystemTimeSeconds(FDateTime DateTime);
    TArray<FVector> GetSplinePoints(class USplineComponent* SplineComponent);
    TArray<FString> GetSaveGameSlotsByType(FString Prefix);
    TArray<class APlayerState*> GetPlayerStateArray(class AGameStateBase* GameState);
    int32 GetIndexOfClosestSplinePoint(class USplineComponent* SplineComponent, FVector WorldLocation);
    FDateTime GetDateFromSeconds(int32 Seconds);
    TArray<FString> GetAllSaveGameSlotNames();
    void DeleteInputSettings();
    void ClearVoice();
    void ClearCharacterFloor(class ACharacter* Character);
    bool CanNavigationReachPoint(class APawn* Pawn, FVector StartLocation, FVector EndLocation);
    float AddXP(float xpToAdd);
}; // Size: 0x28

class UBoatComponent : public UActorComponent
{
    TArray<FXShipFloater> XShipFloaters;                                              // 0x00B0 (size: 0x10)
    TArray<FXShipEngine> XShipEngines;                                                // 0x00C0 (size: 0x10)
    float WaterDensity;                                                               // 0x00D0 (size: 0x4)
    float AirDensity;                                                                 // 0x00D4 (size: 0x4)
    float WaterWorldZ;                                                                // 0x00D8 (size: 0x4)
    bool bCustomShipBoundsRadius;                                                     // 0x00DC (size: 0x1)
    float ShipBoundsRadius;                                                           // 0x00E0 (size: 0x4)
    float InWaterLinearDamping;                                                       // 0x00E4 (size: 0x4)
    float OutWaterLinearDamping;                                                      // 0x00E8 (size: 0x4)
    float InWaterAngularDamping;                                                      // 0x00EC (size: 0x4)
    float OutWaterAngularDamping;                                                     // 0x00F0 (size: 0x4)
    float MovementAccelerationSpeed;                                                  // 0x00F4 (size: 0x4)
    float MovementBrakingSpeed;                                                       // 0x00F8 (size: 0x4)
    float MovementSideDampingSpeed;                                                   // 0x00FC (size: 0x4)
    bool bOrientRotationToMovement;                                                   // 0x0100 (size: 0x1)
    bool bCanMoveBackwardWithOrientRotation;                                          // 0x0101 (size: 0x1)
    float ToleranceForMoveBackwardWithOrientRotation;                                 // 0x0104 (size: 0x4)
    float MaxRotationSpeed;                                                           // 0x0108 (size: 0x4)
    float RotationAccelerationSpeed;                                                  // 0x010C (size: 0x4)
    float RotationBrakingSpeed;                                                       // 0x0110 (size: 0x4)
    bool bMultiplyRotationBySpeed;                                                    // 0x0114 (size: 0x1)
    float SpeedForMaxRotation;                                                        // 0x0118 (size: 0x4)
    bool bEnableStabilization;                                                        // 0x011C (size: 0x1)
    bool bEnableStabilizationInAir;                                                   // 0x011D (size: 0x1)
    float InAirAngularStabilizationSpeed;                                             // 0x0120 (size: 0x4)
    float InAirAngularStabilizationDamping;                                           // 0x0124 (size: 0x4)
    float AngularStabilizationSpeed;                                                  // 0x0128 (size: 0x4)
    float AngularStabilizationDamping;                                                // 0x012C (size: 0x4)
    float LinearStabilizationDamping;                                                 // 0x0130 (size: 0x4)
    bool bSyncMovement;                                                               // 0x0134 (size: 0x1)
    float SendPacketInterval;                                                         // 0x0138 (size: 0x4)
    float ClientSyncSpeed;                                                            // 0x013C (size: 0x4)
    bool bForceReplication;                                                           // 0x0140 (size: 0x1)
    FRepXShipMovement RepXShipMovement;                                               // 0x0144 (size: 0x30)
    float SendPacketIntervalLocal;                                                    // 0x0174 (size: 0x4)
    FVector MovementInput;                                                            // 0x0178 (size: 0xC)
    float RotationInput;                                                              // 0x0184 (size: 0x4)

    void Server_PassMovementInfo(const FRepXShipMovement& NewRepXShipMovement);
    bool IsEngineInWater();
    class ABoatPawn* GetXShipPawn();
    float GetShipBoundsRadius();
    void EnableAllFloaters();
    void EnableAllEngines();
    void DisableAllFloaters();
    void DisableAllEngines();
}; // Size: 0x188

class UCostume : public UPrimaryDataAsset
{
    FText CostumeDisplayName;                                                         // 0x0030 (size: 0x18)
    FName CostumeCategory;                                                            // 0x0048 (size: 0x8)
    TArray<FCostumeVariant> Variants;                                                 // 0x0050 (size: 0x10)

    FString GetCostumeSourceDisplayName(const class UCostume* Costume);
}; // Size: 0x60

class UCostumeCharacterFunctionLibrary : public UBlueprintFunctionLibrary
{

    void GetDismembermentPartMeshAndMaterialSet(const class UCostume* Costume, ECostumeDismembermentPart DismembermentPart, TSoftObjectPtr<UStaticMesh>& Mesh, TMap<int32, TSoftObjectPtr<UMaterialInterface>>& MaterialSet);
    void ApplyCostumeToThirdPersonSkeletalMeshViaLevelSequenceBinding(class UMovieSceneSequencePlayer* Player, FMovieSceneObjectBindingID BindingID, class UCostume* Costume);
    void ApplyCostumeToThirdPersonSkeletalMesh(class USkeletalMeshComponent* SkeletalMesh, class UCostume* Costume, bool bApplyAnimBP);
    void ApplyCostumeToFirstPersonLegsSkeletalMeshViaLevelSequenceBinding(class UMovieSceneSequencePlayer* Player, FMovieSceneObjectBindingID BindingID, class UCostume* Costume);
    void ApplyCostumeToFirstPersonLegsSkeletalMesh(class USkeletalMeshComponent* SkeletalMesh, class UCostume* Costume, bool bApplyAnimBP);
    void ApplyCostumeToFirstPersonArmsSkeletalMeshViaLevelSequenceBinding(class UMovieSceneSequencePlayer* Player, FMovieSceneObjectBindingID BindingID, class UCostume* Costume);
    void ApplyCostumeToFirstPersonArmsSkeletalMesh(class USkeletalMeshComponent* SkeletalMesh, class UCostume* Costume, bool bApplyAnimBP);
    void ApplyCostumeToDismembermentMesh(class UStaticMeshComponent* MeshComponent, const class UCostume* Costume, ECostumeDismembermentPart DismembermentPart);
}; // Size: 0x28

class UCostumeLoaderSubsystem : public UWorldSubsystem
{
    TArray<class UObject*> ReferencedAssets;                                          // 0x0030 (size: 0x10)

    void LoadAndApplyCostumeBPWithCallback(class UCostume* Costume, class AActor* Actor, FLoadAndApplyCostumeBPWithCallbackOnAppliedCostume OnAppliedCostume);
    void LoadAndApplyCostumeBP(class UCostume* Costume, class AActor* Actor);
}; // Size: 0x90

class UCostumeSaveGame : public USaveGame
{
    FString CostumeName;                                                              // 0x0028 (size: 0x10)

}; // Size: 0x38

class UCostumeSubsystem : public UGameInstanceSubsystem
{
    FCostumeSubsystemOnLocalArmedCostumeChanged OnLocalArmedCostumeChanged;           // 0x0030 (size: 0x10)
    void OnLocalArmedCostumeChanged(class UCostume* Costume);
    class UCostumeSaveGame* CostumeSaveGame;                                          // 0x0040 (size: 0x8)
    class UCostume* ArmedCostume;                                                     // 0x0048 (size: 0x8)
    TMap<class FName, class UCostume*> AllCostumes;                                   // 0x0060 (size: 0x50)
    FString DefaultCostumeName;                                                       // 0x00B0 (size: 0x10)

    void SetLocalArmedCostumeByName(const FName& CostumeName);
    void SetLocalArmedCostume(class UCostume* Costume);
    class UCostume* GetLocalArmedCostume();
}; // Size: 0xC0

class UCrosshairWidget : public UUserWidget
{
}; // Size: 0x270

class UCustomUserWidget : public UUserWidget
{
    class UCanvasPanel* InventoryPanel;                                               // 0x0270 (size: 0x8)

    void ToggleInventory(bool IsVisible);
    void SetHotbarSlot(int32 ItemSlot);
    bool RefreshInventory();
}; // Size: 0x278

class UEnvQueryTest_CheckVisibility : public UEnvQueryTest
{
    EEnvTestDot TestMode;                                                             // 0x01F8 (size: 0x1)

}; // Size: 0x200

class UFancyAsyncUtilsLibrary : public UBlueprintFunctionLibrary
{
}; // Size: 0x28

class UFancyBlockedPlayerData : public USaveGame
{
    TMap<class FUniqueNetIdRepl, class FFancyBlockedPlayerMap> LocalUserToBlockedPlayer; // 0x0028 (size: 0x50)

}; // Size: 0x78

class UFancyCameraComponent : public UCameraComponent
{
    uint8 bLockRotToHmd;                                                              // 0x07D0 (size: 0x1)
    uint8 bUseLateUpdate;                                                             // 0x07D0 (size: 0x1)

}; // Size: 0x7E0

class UFancyCarrySystemCarrier : public USceneComponent
{
    class UFancyCarrySystemCarryable* CurrentCarryable;                               // 0x01F8 (size: 0x8)
    class UFancyCarrySystemCarryable* CurrentFocusedCarryable;                        // 0x0200 (size: 0x8)
    FFancyCarrySystemCarrierOnCarryStarted OnCarryStarted;                            // 0x0208 (size: 0x10)
    void OnCarryEvent(class UFancyCarrySystemCarryable* Carryable);
    FFancyCarrySystemCarrierOnCarryStopped OnCarryStopped;                            // 0x0218 (size: 0x10)
    void OnCarryEvent(class UFancyCarrySystemCarryable* Carryable);

    void StopCarry();
    void StartCarry(class UFancyCarrySystemCarryable* Carryable);
    void OnRep_CurrentCarryable(class UFancyCarrySystemCarryable* PreviousCarryable);
    bool IsCarrying();
    class UFancyCarrySystemCarryable* GetCurrentFocusedCarryable();
    class UFancyCarrySystemCarryable* GetCurrentCarryable();
    void ForceDropCarry();
}; // Size: 0x230

class UFancyCarrySystemCarryable : public USceneComponent
{
    class UFancyCarrySystemCarrier* CurrentCarrier;                                   // 0x01F8 (size: 0x8)
    bool bCanBeCarried;                                                               // 0x0200 (size: 0x1)
    class USoundBase* CarrySound;                                                     // 0x0208 (size: 0x8)
    class USoundBase* DropSound;                                                      // 0x0210 (size: 0x8)
    FFancyCarrySystemCarryableOnCarry OnCarry;                                        // 0x0218 (size: 0x10)
    void OnCarriedEvent();
    FFancyCarrySystemCarryableOnDrop OnDrop;                                          // 0x0228 (size: 0x10)
    void OnCarriedEvent();

    void SetCanBeCarried(bool CanBeCarried);
    void OnRep_CurrentCarrier();
    bool IsBeingCarried();
    bool CanBeCarried();
}; // Size: 0x240

class UFancyCheckPrivilegeProxy : public UOnlineBlueprintCallProxyBase
{
    FFancyCheckPrivilegeProxyOnSuccess onSuccess;                                     // 0x0030 (size: 0x10)
    void CheckPrivilegeCallbackProxyDelegate(const bool SessionInfo);
    FFancyCheckPrivilegeProxyOnFailure onFailure;                                     // 0x0040 (size: 0x10)
    void CheckPrivilegeCallbackProxyDelegate(const bool SessionInfo);

    class UFancyCheckPrivilegeProxy* CheckPrivilege(class UObject* WorldContextObject, EFancyUserPrivileges PrivilegeToCheck, bool bForceAttemptToResolve);
}; // Size: 0x60

class UFancyConfigOverrideSubsystem : public UGameInstanceSubsystem
{

    void SetSecondaryScreenPercentageOverride(uint8 Priority, float Value);
    void ClearSecondaryScreenPercentageOverride(uint8 Priority);
}; // Size: 0x38

class UFancyDLCConfig : public UDeveloperSettings
{
    TMap<class FGameplayTag, class FFancyDLCConfigRow> DLCToEntitlement;              // 0x0038 (size: 0x50)

}; // Size: 0x88

class UFancyDLCSubsystem : public UGameInstanceSubsystem
{
    FFancyDLCSubsystemDLCChangedDelegate DLCChangedDelegate;                          // 0x0030 (size: 0x10)
    void FancyDLCChangedDelegate();
    FGameplayTagContainer GrantedDLC;                                                 // 0x0040 (size: 0x20)

    bool InvokeStoreForDLC(const FGameplayTag& DLCTag);
    bool DoesUserHaveDLC(const FGameplayTag& DLCTag);
}; // Size: 0x60

class UFancyDestroySessionCallbackProxy : public UOnlineBlueprintCallProxyBase
{
    FFancyDestroySessionCallbackProxyOnSuccess onSuccess;                             // 0x0030 (size: 0x10)
    void EmptyOnlineDelegate();
    FFancyDestroySessionCallbackProxyOnFailure onFailure;                             // 0x0040 (size: 0x10)
    void EmptyOnlineDelegate();

    class UFancyDestroySessionCallbackProxy* FancyDestroySession(class UObject* WorldContextObject, class APlayerController* PlayerController);
}; // Size: 0x88

class UFancyEntitySightingComponent : public UActorComponent
{
    FFancyEntitySightingComponentOnEntitySighted OnEntitySighted;                     // 0x00B0 (size: 0x10)
    void OnEntityEvent(class UFancyEntitySightingComponent* Entity);

}; // Size: 0xC0

class UFancyEntitySightingManager : public UActorComponent
{
    TMap<class UFancyEntitySightingComponent*, class bool> RegisteredEntities;        // 0x00B0 (size: 0x50)
    FFancyEntitySightingManagerOnEntitySightedEvent OnEntitySightedEvent;             // 0x0100 (size: 0x10)
    void OnEntitySightedEvent();

    void OnEntitySighting(class UFancyEntitySightingComponent* Entity);
    int32 GetNumEntitySightings();
}; // Size: 0x110

class UFancyGDKCalcCannotCommunicateWithProxy : public UOnlineBlueprintCallProxyBase
{
    FFancyGDKCalcCannotCommunicateWithProxyOnSuccess onSuccess;                       // 0x0030 (size: 0x10)
    void FancyGDKCalcCannotCommunicateWithProxyDelegate(FFancyGDKCalcCannotCommunicateResult CannotCommunicateWith);
    FFancyGDKCalcCannotCommunicateWithProxyOnFailure onFailure;                       // 0x0040 (size: 0x10)
    void FancyGDKCalcCannotCommunicateWithProxyDelegate(FFancyGDKCalcCannotCommunicateResult CannotCommunicateWith);
    TArray<class APlayerState*> PlayerStates;                                         // 0x0058 (size: 0x10)

    class UFancyGDKCalcCannotCommunicateWithProxy* GDKCalcCannotCommunicate(class UObject* WorldContextObject, TArray<class APlayerState*> PlayerStates);
}; // Size: 0x80

class UFancyGameInstance : public UAdvancedFriendsGameInstance
{
    EFancyEventType CurrentEvent;                                                     // 0x0228 (size: 0x1)
    class USteamManager* SteamManager;                                                // 0x0230 (size: 0x8)
    bool IsSteamOverlayActive;                                                        // 0x0238 (size: 0x1)
    FString CurrentSlotName;                                                          // 0x0240 (size: 0x10)
    bool bHasShownSplashScreens;                                                      // 0x0250 (size: 0x1)
    class UMissionData* MissionData;                                                  // 0x0258 (size: 0x8)
    FFancyGameInstanceOnInputDeviceChanged OnInputDeviceChanged;                      // 0x0268 (size: 0x10)
    void OnInputDeviceChange(TEnumAsByte<EFancyInputDevice> NewInputDevice);

    void UpdateCurrentGameLanguage();
    void SageGameChatActive(bool bActive);
    void ResolveGameplayActivityEndStatusEvent(FString PendingMapOptions);
    void ResetAchievements();
    void OnSteamOverlayIsActive(bool isOverlayActive);
    void OnPreLoadMap(FString String);
    void OnInputDeviceChangedEvent(const TEnumAsByte<EFancyInputDevice> NewInputDevice);
    void OnInputDeviceChange(const EInputDevices NewInputDevice);
    void InitializeStats();
    bool InitializeCPPElements();
    void HandleSeamlessTravelStart(class UWorld* World, FString String);
    void HandleSageGameChatActive(const bool bActive);
    void CreateMission(FString TargetEscapeLevel, float LevelBaseXP, float LevelTimeLimit, FString MissionStructRowName);
    FMissionStructure CompleteMission(float TimeCompleted);
    void CheckCurrentEvent();
}; // Size: 0x278

class UFancyInputIconWidget : public UUserWidget
{

    void OnInputDeviceChanged(TEnumAsByte<EFancyInputDevice> NewInputDevice);
}; // Size: 0x278

class UFancyInputUIUtils : public UBlueprintFunctionLibrary
{

    bool IsMatchingKeyInputType(const FKey& KeyA, const FKey& KeyB);
    FText GetEnglishInputActionKeyName(const FName& ActionName);
    class UUserWidget* FindNextVisibleWidget(const TArray<class UUserWidget*>& OrderedWidgets, class UUserWidget* CurrentWidget, bool bForward);
}; // Size: 0x28

class UFancyJoinSessionCallbackProxy : public UOnlineBlueprintCallProxyBase
{
    FFancyJoinSessionCallbackProxyOnSuccess onSuccess;                                // 0x0030 (size: 0x10)
    void OnJoinSessionFailureFancyOnlineDelegate(EOnJoinSessionCompleteFancyResult Result);
    FFancyJoinSessionCallbackProxyOnFailure onFailure;                                // 0x0040 (size: 0x10)
    void OnJoinSessionFailureFancyOnlineDelegate(EOnJoinSessionCompleteFancyResult Result);

    class UFancyJoinSessionCallbackProxy* FancyJoinSession(class UObject* WorldContextObject, class APlayerController* PlayerController, const FBlueprintSessionResult& SearchResult, const FName SessionName, const FName OptionalBoolParamToCheck);
}; // Size: 0x190

class UFancyModalSubsystem : public UGameInstanceSubsystem
{
    TSoftClassPtr<UUserWidget> ModalClass;                                            // 0x0030 (size: 0x28)
    int32 ModalZOrder;                                                                // 0x0058 (size: 0x4)
    class UUserWidget* ModalInstance;                                                 // 0x0060 (size: 0x8)
    class UUserWidget* CurrentCustomModalInstance;                                    // 0x0068 (size: 0x8)
    FLatentActionInfo CurrentModalLatentInfo;                                         // 0x0070 (size: 0x18)
    class UObject* CurrentCustomModalOwner;                                           // 0x0088 (size: 0x8)

    void ShowMessageModalBP(class UObject* WorldContext, const FText Message, const FText Title, const FText Header, const FText Button, FLatentActionInfo LatentInfo);
    bool ShowCustomModalBP(class UObject* WorldContext, const TSoftClassPtr<UUserWidget> CustomModalClass, const FShowCustomModalBPOnPrepareModal& OnPrepareModal, const FShowCustomModalBPOnCompleteModal& OnCompleteModal);
    void ShowChoiceModalBP(class UObject* WorldContext, const FText Message, const FText Title, const FText Header, const FText Button1, const FText Button2, FLatentActionInfo LatentInfo, EFancyModalButton& Result);
    bool IsFancyModalVisible(const class UObject* WorldContext);
    void HandleCustomModalComplete();
    void HandleButtonPressForCurrentModal(EFancyModalButton PressedButton);
    void CloseAllModalsCreatedByObject(const class UObject* Object);
}; // Size: 0x110

class UFancyMovementComponent : public UCharacterMovementComponent
{
    float MaxSprintSpeed;                                                             // 0x0AF4 (size: 0x4)
    bool bIsSprinting;                                                                // 0x0AF8 (size: 0x1)

    void SetSprinting(bool Sprint);
}; // Size: 0xB00

class UFancyOnlineInteractionsSubsystem : public UGameInstanceSubsystem
{
    float PlayerReportCooldownSeconds;                                                // 0x0030 (size: 0x4)
    float PlayerSpeakingCooldownSeconds;                                              // 0x0034 (size: 0x4)
    TArray<FBPUniqueNetId> ChatMutedPlayers;                                          // 0x0038 (size: 0x10)
    TArray<FBPUniqueNetId> VoiceMutedPlayers;                                         // 0x0048 (size: 0x10)
    TMap<FUniqueNetIdRepl, float> LastSpokeTime;                                      // 0x0058 (size: 0x50)
    TArray<TWeakObjectPtr<UFancyOnlinePlayerStatusHelper>> CreatedHelpers;            // 0x00A8 (size: 0x10)

    void SetIsPlayerVoiceMuted(const FBPUniqueNetId& NetId, bool Value);
    void SetIsPlayerChatMuted(const FBPUniqueNetId& NetId, bool Value);
    void NotifyDidChange(const FBPUniqueNetId& NetId);
    void MarkPlayerTalking(const FBPUniqueNetId& NetId);
    bool GetIsVoiceMuted(const FBPUniqueNetId& NetId);
    bool GetIsReportedThisSession(const FBPUniqueNetId& NetId);
    bool GetIsReportCooldownActive(const FBPUniqueNetId& NetId);
    bool GetIsPlayerTalking(const FBPUniqueNetId& NetId);
    bool GetIsChatMuted(const FBPUniqueNetId& NetId);
    bool GetIsBlocked(const FBPUniqueNetId& NetId);
    class UFancyOnlinePlayerStatusHelper* CreateStaticStatusHelper(const FBPUniqueNetId& NetId, FString PlayerName, const EFancyPlatform& Platform);
    class UFancyOnlinePlayerStatusHelper* CreatePlayerStateBoundStatusHelper(const FBPUniqueNetId& NetId);
}; // Size: 0xB8

class UFancyOnlinePlayerStatusHelper : public UObject
{
    FFancyOnlinePlayerStatusHelperOnStatusChanged OnStatusChanged;                    // 0x0028 (size: 0x10)
    void OnFancyOnlineInteractionsPlayerStatusChanged(class UFancyOnlinePlayerStatusHelper* StatusAccessor);
    FBPUniqueNetId NetId;                                                             // 0x0040 (size: 0x28)
    FString StaticPlayerName;                                                         // 0x0068 (size: 0x10)
    EFancyPlatform StaticPlatform;                                                    // 0x0078 (size: 0x1)
    TWeakObjectPtr<class AFancyPlayerState> SubscribedPlayerState;                    // 0x007C (size: 0x8)
    class UFancyOnlineInteractionsSubsystem* OwnerSubsystem;                          // 0x0088 (size: 0x8)

    void SubscribeToPlayerState(class AFancyPlayerState* PlayerState);
    void OnPlayerStateArrayChanged();
    class AFancyPlayerState* GetPlayerState();
    FString GetPlayerRichTextPlatform();
    FString GetPlayerRichTextNameAndPlatform(FString TextStyle);
    EFancyPlatform GetPlayerPlatform();
    FBPUniqueNetId GetPlayerNetID();
    FString GetPlayerName();
    bool GetIsPlayerVoiceMuted();
    bool GetIsPlayerTalking();
    bool GetIsPlayerReportedThisSession();
    bool GetIsPlayerReportCooldownActive();
    bool GetIsPlayerChatMuted();
    bool GetIsPlayerBlocked();
    bool GetIsLocalPlayer();
    void BroadcastUpdate();
}; // Size: 0x90

class UFancyPlatformActivities : public UBlueprintFunctionLibrary
{

    void StartActivity(FString ActivityName);
    void SetActivityAvailability(FString ActivityName, bool Enabled);
    void ResumeActivity(FString ActivityName);
    void ResetAllActiveActivities();
    FString GetCurrentActivityName();
    void EndActivity(FString ActivityName, TEnumAsByte<ActivityCompletionStatus> Status);
}; // Size: 0x28

class UFancyPlatformUtilsLibrary : public UBlueprintFunctionLibrary
{

    bool TryParseNetId(FString IDstr, FString& OutEOSComponent, FString& OutPlatformComponent, EFancyNetIDFormat& DetectedFormat);
    bool TryBeginFreeCommunication();
    FString ToBase64(FString inString);
    bool ShowCommunicationRestrictedMessage(const class APlayerController* PlayerController);
    bool SetUsingMultiplayerFeatures(const class APlayerController* PlayerController, bool bUsingMP);
    void PrintScriptCallstack();
    bool IsShippingBuild();
    bool IsOnXboxSeriesS();
    bool IsOnXboxSeriesPlatform();
    bool IsOnWinGDK();
    bool IsOnSwitch2Platform();
    bool IsOnSteam();
    bool IsOnPS5Platform();
    bool IsOnline(class UObject* WorldContext);
    bool IsOnAnyXboxPlatform();
    bool IsOnAnySonyPlatform();
    bool IsOnAnyNintendoPlatform();
    bool IsEditor();
    bool IsCorrespondingPlatformId(FString EOSFormattedID, FString PlatformFormattedID);
    bool IsConsoleBuild();
    bool IsConnectedToNetwork();
    bool IsCompatiblePlatform(EFancyPlatform OtherPlatform);
    EFancyPlatform GetPlatformFromString(FString PlatformString);
    EFancyPlatform GetPlatform();
    class APlayerController* GetLocalPlayerController(class UObject* WorldContext);
    FString GetGameVersion();
    TEnumAsByte<EFancyInputDevice> GetCurrentInputDevice();
    FString FromBase64(FString inString);
    void EndFreeCommunication();
    FString CreatePlatformIconRichText(EFancyPlatform PlayerPlatform);
    FBPUniqueNetId BPTryGetPlatformNetIDFromCachedID(const FBPUniqueNetId& BPNetID);
    bool AreEOSIDsEqual(FString EOSFormattedIDA, FString EOSFormattedIDB);
}; // Size: 0x28

class UFancyPlayerCostumeComponent : public UActorComponent
{
    class UCostume* AssignedCostume;                                                  // 0x00B0 (size: 0x8)

    void OnRep_AssignedCostume();
    void HandleLocalCostumeChanged(class UCostume* Costume);
    void AssignCostumeRPC(class UCostume* Costume);
}; // Size: 0xB8

class UFancyPlayerNamePlatformDecorator : public URichTextBlockDecorator
{
    TMap<class FName, class FSlateBrush> CurrentPlatformCachedBrushes;                // 0x0028 (size: 0x50)
    TMap<class FName, class FSlateBrush> CrossPlatformCachedBrushes;                  // 0x0078 (size: 0x50)
    TMap<class FName, class FFancyPlayerNamePlatformDecoratorStyle> CurrentPlatformIcons; // 0x00C8 (size: 0x50)
    TMap<class FName, class FFancyPlayerNamePlatformDecoratorStyle> CrossPlayPlatformIcons; // 0x0118 (size: 0x50)

}; // Size: 0x168

class UFancySaveIndicatorSubsystem : public UGameInstanceSubsystem
{
    TSoftClassPtr<UUserWidget> SaveIndicatorWidgetType;                               // 0x0038 (size: 0x28)
    int32 SaveIndicatorZOrder;                                                        // 0x0060 (size: 0x4)
    class UUserWidget* SaveIndicatorWidget;                                           // 0x0068 (size: 0x8)
    class UFancySaveSubsystem* FancySaveSubsystem;                                    // 0x0070 (size: 0x8)

    void HandleDiskWritingStateChanged(bool bIsWritingToDisk);
}; // Size: 0x78

class UFancySaveSubsystem : public UGameInstanceSubsystem
{
    class UFancySaveIndicatorSubsystem* SaveIndicatorSubsystem;                       // 0x0030 (size: 0x8)
    float PreDiskWriteDelaySeconds;                                                   // 0x0038 (size: 0x4)
    TMap<class FString, class FFancySaveGameSlotCacheData> SlotInfoAndCache;          // 0x0040 (size: 0x50)
    EFancySaveSubsystemFlushingState FlushingState;                                   // 0x0090 (size: 0x1)

    bool SaveGameToDisk(FString SlotName, class USaveGame* SaveGame);
    void SaveGameToCache(FString SlotName, class USaveGame* SaveGame);
    class USaveGame* LoadGameFromSlot(FString SlotName);
    bool DoesSaveGameExist(FString SlotName);
    bool DeleteGameInSlot(FString SlotName);
}; // Size: 0xF0

class UFancySessionUtilsLibrary : public UBlueprintFunctionLibrary
{

    int32 GetMaxPlayersForGameMode(class AGameModeBase* GameMode);
    int32 GetBuildVersionId();
    FString GenerateLobbyCode(int32 NumCharacters);
    FSessionsSearchSetting CreateSessionsSearchSetting(EOnlineComparisonOpRedux CompareOp, const FSessionPropertyKeyPair& Val);
    FSessionPropertyKeyPair CreateSessionPropertyKeyPair_StringVal(const FName& Name, FString Val);
    FSessionPropertyKeyPair CreateSessionPropertyKeyPair_IntVal(const FName& Name, int32 Val);
    FSessionPropertyKeyPair CreateSessionPropertyKeyPair_BoolVal(const FName& Name, bool Val);
}; // Size: 0x28

class UFancySlateInputPreprocessorSubsystem : public UGameInstanceSubsystem
{
}; // Size: 0x40

class UFancySpringArmComponent : public USpringArmComponent
{
    float WalkCameraLagSpeed;                                                         // 0x0280 (size: 0x4)
    float WalkCameraLagMaxDistance;                                                   // 0x0284 (size: 0x4)
    float SprintCameraLagSpeed;                                                       // 0x0288 (size: 0x4)
    float SprintCameraLagMaxDistance;                                                 // 0x028C (size: 0x4)
    float RecoverCameraLagSpeed;                                                      // 0x0290 (size: 0x4)
    bool bIgnoreInterpolation;                                                        // 0x0294 (size: 0x1)

}; // Size: 0x2B0

class UFancyTelemetryConfig : public UDeveloperSettings
{
    FString PlayFabTelemetryKey;                                                      // 0x0038 (size: 0x10)
    bool bTelemetryEnabled;                                                           // 0x0048 (size: 0x1)

}; // Size: 0x50

class UFancyTelemetryEventBuilder : public UObject
{
    class UPlayFabJsonObject* Event;                                                  // 0x0028 (size: 0x8)
    class UPlayFabJsonObject* Payload;                                                // 0x0030 (size: 0x8)

    void SetStringField(FString Field, FString Value);
    void SetPlayerDisconnectReason(EFancyPlayerDisconnectReason PlayerDisconnectReason);
    void SetGameplayActivityEndStatus(EFancyGameplayActivityEndStatus GameplayActivityEndStatus);
    void SetActivitySessionType(EFancyActivitySessionType ActivitySessionType);
    EFancyTelemetryEventType GetEventType();
    void GenerateGuidField(FString Field);
    void FetchMultiplayerSessionId();
    void FetchLevelName();
    void FetchIsPrivateSession();
    void AddUniquePlayerIdAndCostume(const class APlayerState* NewPlayerState);
}; // Size: 0x40

class UFancyTelemetrySubsystem : public UGameInstanceSubsystem
{

    void SendTelemetryEvent(class UFancyTelemetryEventBuilder* EventBuilder);
    class UFancyTelemetryEventBuilder* RequestTelemetryEventBuilder(EFancyTelemetryEventType EventType, class UFancyTelemetryEventBuilder* MatchingEventBuilder);
    void OnTelemetrySuccess(FEventsWriteEventsResponse Result, class UObject* customData);
    void OnTelemetryFailure(FPlayFabError Error, class UObject* customData);
    void OnEOSLoginComplete(bool bSuccess);
}; // Size: 0x58

class UFancyUserControllerSystem : public UGameInstanceSubsystem
{
    FFancyUserControllerSystemOnShowUserReestablishMessage OnShowUserReestablishMessage; // 0x0038 (size: 0x10)
    void ShowUserReestablishMessageSignature();
    FFancyUserControllerSystemOnUserIconUpdated OnUserIconUpdated;                    // 0x0048 (size: 0x10)
    void ActiveUserIconUpdatedSignature(FSlateBrush Icon);
    FFancyUserControllerSystemOnConnectionStatusChanged OnConnectionStatusChanged;    // 0x0058 (size: 0x10)
    void OnConnectionStatusChanged(bool NewConnectionStatus);
    FFancyUserControllerSystemOnApplicationReactivate OnApplicationReactivate;        // 0x0068 (size: 0x10)
    void OnApplicationReactivate();
    FFancyUserControllerSystemOnApplicationDeactivate OnApplicationDeactivate;        // 0x0078 (size: 0x10)
    void OnApplicationDeactivate();
    FFancyUserControllerSystemOnEOSLoginComplete OnEOSLoginComplete;                  // 0x0088 (size: 0x10)
    void OnEOSLogin(bool bSuccess);

    void ShowUserReestablishMessageSignature__DelegateSignature();
    void OnEOSLogin__DelegateSignature(bool bSuccess);
    void OnConnectionStatusChanged__DelegateSignature(bool NewConnectionStatus);
    void OnApplicationReactivate__DelegateSignature();
    void OnApplicationDeactivate__DelegateSignature();
    bool IsConnectToInternet();
    void InitiateEOSLogin();
    FSlateBrush GetActiveUserIcon();
    void EOSLoginDoneDelegate__DelegateSignature(bool bSuccess);
    void ActiveUserIconUpdatedSignature__DelegateSignature(FSlateBrush Icon);
}; // Size: 0xF0

class UFancyUserFlow : public UObject
{
    class UFancyUserFlowSubsystem* OwnerSubsystem;                                    // 0x0028 (size: 0x8)
    class UFancyUserFlow* ParentFlow;                                                 // 0x0030 (size: 0x8)
    TMap<class UFancyUserFlow*, class FFancyUserFlowLatentFlowResumeData> RunningSubFlowLatentAction; // 0x0038 (size: 0x50)
    FLatentActionInfo ResumeLatentActionInfo;                                         // 0x0088 (size: 0x18)
    class UWidget* PreviouslyFocusedWidget;                                           // 0x00A0 (size: 0x8)

    void ShowNonModalMessage(const class UObject* WorldContext, const FText Message);
    void RunSubFlow(const class UObject* WorldContext, class UFancyUserFlow* FancyUserFlow, FLatentActionInfo LatentInfo, class UFancyUserFlow*& CompletedFlowOut);
    void Run();
    void ReturnToMainMenu(const class UObject* WorldContext, FLatentActionInfo LatentInfo);
    void Resume();
    void ResetInputModeToGameModeDefault(class UWidget* OverrideWidgetFocus);
    void HandleInterrupted();
    class UGameInstance* GetGameInstance(TSubclassOf<class UGameInstance> GameInstanceType);
    class UWidget* GetFocusedWidget();
    void Complete();
    void CancelAllRunningLatentActions();
}; // Size: 0xA8

class UFancyUserFlowSubsystem : public UGameInstanceSubsystem
{
    TArray<class UFancyUserFlow*> FlowQueue;                                          // 0x0030 (size: 0x10)
    class UFancyUserFlow* RunningQueueFlow;                                           // 0x0040 (size: 0x8)
    TMap<class UFancyUserFlow*, class FFancyUserFlowLatentFlowResumeData> RunningSingleFlows; // 0x0048 (size: 0x50)
    TSoftObjectPtr<UWorld> MainMenuLevel;                                             // 0x0098 (size: 0x28)
    TWeakObjectPtr<class UWorld> RunningWorld;                                        // 0x00C0 (size: 0x8)
    TArray<FLatentActionInfo> WaitingLatentActionInfos;                               // 0x00C8 (size: 0x10)

    void WaitForQueuedFancyFlows(const class UObject* WorldContext, FLatentActionInfo LatentActionInfo);
    void RunSingleFlowAndWait(const class UObject* WorldContext, class UFancyUserFlow* Flow, FLatentActionInfo LatentActionInfo, class UFancyUserFlow*& CompletedFlowOut);
    void RunNextQueuedFancyUserFlow();
    void ResumeFancyFlows(const class UObject* WorldContext);
    void QueueFancyUserFlow(class UObject* WorldContext, class UFancyUserFlow* Flow);
    bool IsFancyFlowInProgressOrQueued(const class UObject* WorldContext, TSoftClassPtr<UFancyUserFlow> SoftFlowType);
    bool IsAnyFancyFlowInProgress(const class UObject* WorldContext);
    void HandleFlowComplete(class UFancyUserFlow* Flow);
    void CompleteRunningSingleFlow(class UFancyUserFlow* Flow);
    void BudgeFlow(class UObject* WorldContext, class UFancyUserFlow* Flow);
}; // Size: 0xD8

class UFancyUserReportingSubsystem : public UGameInstanceSubsystem
{
    FFancyUserReportingSubsystemOnUserReportingStatusChanged OnUserReportingStatusChanged; // 0x0030 (size: 0x10)
    void FancyUserReportingStatusChanged(const FBPUniqueNetId& NetId);
    TSoftClassPtr<UFancyUserFlow> DebugShowReportPlayerFlow;                          // 0x0040 (size: 0x28)
    TMap<class FUniqueNetIdRepl, class FFancyReportedPlayers> LocalUserToReportedPlayers; // 0x00C0 (size: 0x50)
    class UFancyBlockedPlayerData* BlockedPlayerData;                                 // 0x0158 (size: 0x8)

    void UnblockPlayer(const FBPUniqueNetId& NetIdToUnblock, FUnblockPlayerDone Done);
    void SendPlayerReport(const FBPUniqueNetId& NetId, EFancyUserReportCategory BehaviorCategory, FString Explanation, FSendPlayerReportDone Done);
    void OnLoginComplete(bool bSuccess);
    void OnAppReactivate();
    bool IsPlayerReported(const FBPUniqueNetId& NetId, float SecondsAgoLimit);
    bool IsPlayerBlocked(const FBPUniqueNetId& NetId);
    int32 GetMaxReportExplanationLength();
    void GetInteractedWithPlayers(TArray<FBPUniqueNetId>& Ids, TArray<FString>& Names);
    bool GetAllBlockedPlayers(TArray<FBPFancyReportingPlayerRecord>& BlockedPlayers);
    void BlockPlayer(const FBPUniqueNetId& NetIdToBlock, FBlockPlayerDone Done);
}; // Size: 0x1F8

class UFancyVideoSubsystem : public UGameInstanceSubsystem
{
    class AFancyVideoPlayer* ActiveVideoPlayer;                                       // 0x0030 (size: 0x8)

    void StopVideo();
    void SkipVideo();
    void PlayVideo(FString MediaFileName, bool AddToQueue);
    void PauseVideo();
    bool IsPlaying();
    class AFancyVideoPlayer* GetActiveVideoPlayer();
}; // Size: 0x38

class UFancyVoipManagerComponent : public UVoipManagerComponent
{

    void TryMuteEOSVoip();
    bool FancyInitVoice(class AController* Controller);
}; // Size: 0x188

class UFancyVotingComponent : public UActorComponent
{
    FFancyVotingComponentOnVoteStarted OnVoteStarted;                                 // 0x00B0 (size: 0x10)
    void OnVoteStarted();
    FFancyVotingComponentOnVoteFinished OnVoteFinished;                               // 0x00C0 (size: 0x10)
    void OnVoteFinished(bool Result);
    FFancyVotingComponentOnVoteCanceled OnVoteCanceled;                               // 0x00D0 (size: 0x10)
    void OnVoteCanceled();
    FFancyVotingComponentOnVoteChanged OnVoteChanged;                                 // 0x00E0 (size: 0x10)
    void OnVoteChanged(FVoteData VoteData);
    FVoteData ActiveVote;                                                             // 0x00F0 (size: 0x68)

    void VoteUpdated(class APlayerState* PlayerState, bool NewVote);
    void StartVoteServer(FVoteParameters VoteParameters);
    void StartVoteMulticast(FVoteParameters VoteParameters);
    bool IsVotingActive();
    void FinishVoteServer();
    void FinishVoteMulticast(bool Result);
    bool CheckVoteFinishedCondition();
    void ChangeVoteServer(class APlayerState* PlayerState, bool NewVote);
}; // Size: 0x158

class UGripMotionControllerComponent : public UMotionControllerComponent
{
    bool bScaleTracking;                                                              // 0x0508 (size: 0x1)
    FVector TrackingScaler;                                                           // 0x050C (size: 0xC)
    bool bLimitMinHeight;                                                             // 0x0518 (size: 0x1)
    float MinimumHeight;                                                              // 0x051C (size: 0x4)
    bool bLimitMaxHeight;                                                             // 0x0520 (size: 0x1)
    float MaximumHeight;                                                              // 0x0524 (size: 0x4)
    bool bOffsetByHMD;                                                                // 0x0528 (size: 0x1)
    bool bLeashToHMD;                                                                 // 0x0529 (size: 0x1)
    float LeashRange;                                                                 // 0x052C (size: 0x4)
    bool bSmoothHandTracking;                                                         // 0x0570 (size: 0x1)
    bool bSmoothWithEuroLowPassFunction;                                              // 0x0572 (size: 0x1)
    float SmoothingSpeed;                                                             // 0x0574 (size: 0x4)
    FBPEuroLowPassFilterTrans EuroSmoothingParams;                                    // 0x0580 (size: 0x150)
    EVRVelocityType VelocityCalculationType;                                          // 0x0700 (size: 0x1)
    bool bSampleVelocityInWorldSpace;                                                 // 0x0701 (size: 0x1)
    int32 VelocitySamples;                                                            // 0x0704 (size: 0x4)
    bool bOffsetByControllerProfile;                                                  // 0x0728 (size: 0x1)
    FTransform ReplicatedControllerTransform;                                         // 0x0760 (size: 0x30)
    FTransform LastUpdatesTransform;                                                  // 0x0790 (size: 0x30)
    float ControllerNetUpdateRate;                                                    // 0x07DC (size: 0x4)
    bool bSmoothReplicatedMotion;                                                     // 0x07E4 (size: 0x1)
    bool bReplicateWithoutTracking;                                                   // 0x07E5 (size: 0x1)

    void Server_SendControllerTransform(FTransform NewTransform);
    void OnRep_ReplicatedControllerTransform();
    void GetPhysicsVelocity(FVector& AngularVelocity, FVector& LinearVelocity);
    bool BP_IsLocallyControlled();
}; // Size: 0x800

class UInteractableCameraComponent : public UCameraComponent
{
}; // Size: 0x7D0

class UInteractableComponent : public UStaticMeshComponent
{
    bool IsUsable;                                                                    // 0x04E8 (size: 0x1)
    bool WasUsed;                                                                     // 0x04E9 (size: 0x1)

    void ResetUsage();
    void OnUsedServer(class ACharacter* Character);
    void OnUsedNotify();
    void OnUsedMulticast();
    void OnUsedAll();
    void OnRep_WasUsed();
    void BlockUsage();
}; // Size: 0x4F0

class UInventoryComponent : public UActorComponent
{
    int32 InventorySize;                                                              // 0x00B0 (size: 0x4)
    TArray<class UInventoryItem*> Inventory2;                                         // 0x00B8 (size: 0x10)
    class AItemActor* EquippedItem;                                                   // 0x00C8 (size: 0x8)

    void SwapInventoryItems(int32 FirstIdx, int32 SecondIdx);
    void RemoveFromInventory(class UInventoryItem* Item);
    bool IsSlotEmpty(int32 SlotIndex);
    class UInventoryItem* GetItemAtSlot(int32 SlotIndex);
    void DropItem(uint8 Slot);
    bool AddToInventory(class UInventoryItem* Item);
}; // Size: 0xD0

class UInventoryItem : public UObject
{
    FItemStructure Structure;                                                         // 0x0028 (size: 0x68)
    int32 Quantity;                                                                   // 0x0090 (size: 0x4)

}; // Size: 0x98

class ULIDARBlueprintFunctionLibrary : public UBlueprintFunctionLibrary
{

    bool FindCollisionUVSkeletalMesh(const FHitResult& Hit, FVector2D& UV);
    FLIDARDotStruct CreateLiDarDot(class UObject* caller, class UTextureRenderTarget2D* RenderTarget);
}; // Size: 0x28

class ULIDARComponent : public UActorComponent
{
    FLIDARComponentBP_ScannerTrace BP_ScannerTrace;                                   // 0x00B0 (size: 0x10)
    void ScannerTraceSignature();
    FLIDARComponentBP_UpdateColors BP_UpdateColors;                                   // 0x00C0 (size: 0x10)
    void ScannerUpdateSignature();
    bool bInScannerMode;                                                              // 0x00E4 (size: 0x1)
    FName MuzzleSocketName;                                                           // 0x00E8 (size: 0x8)
    TMap<class FString, class FColor> AbbrevToColorMap;                               // 0x00F0 (size: 0x50)
    float ScannerSpread;                                                              // 0x0140 (size: 0x4)
    float ScannerRange;                                                               // 0x014C (size: 0x4)
    float RateOfScannerFire;                                                          // 0x0150 (size: 0x4)
    FString BeamColorAbbrv;                                                           // 0x0160 (size: 0x10)
    FColor BeamColor;                                                                 // 0x0170 (size: 0x4)
    FColor KillModeColor;                                                             // 0x0174 (size: 0x4)
    float BeamWidth;                                                                  // 0x0178 (size: 0x4)
    float BeamGlowAmount;                                                             // 0x0184 (size: 0x4)
    float DotGlowAmount;                                                              // 0x0188 (size: 0x4)
    float DotScaleFactor;                                                             // 0x018C (size: 0x4)

    void ShootReset();
    void ShootGun();
    void ShootAuto();
    FHitResult ScannerTrace(class UStaticMeshComponent* Mesh);
}; // Size: 0x190

class UMapEditorCharacterMovement : public UCharacterMovementComponent
{
    bool bCenterMouseOnStopMovementMode;                                              // 0x0AF0 (size: 0x1)
    float MaxSpeedMultiplier;                                                         // 0x0B04 (size: 0x4)
    float MinSpeedMultiplier;                                                         // 0x0B08 (size: 0x4)

    void Turn(float Value);
    void Server_SetSpeedMultiplier(float SpeedMultiplier);
    void MoveUp(float Value);
    void MoveRight(float Value);
    void MoveForward(float Value);
    void LookUp(float Value);
    bool InMovementMode();
    void Init();
    void IncreaseSpeedMultiplier(float IncreaseAmount);
    void EnterMovementMode(bool Enter);
    void DecreaseSpeedMultiplier(float DecreaseAmount);
}; // Size: 0xB10

class UMapEditorHandlerComponent : public UActorComponent
{
    TEnumAsByte<ECollisionChannel> TraceCollisionChannel;                             // 0x00B0 (size: 0x1)
    FString MapDirectory;                                                             // 0x00B8 (size: 0x10)
    TSubclassOf<class AMapEditorGizmo> GizmoClass;                                    // 0x00C8 (size: 0x8)
    float ReplicationRate;                                                            // 0x00D0 (size: 0x4)
    class AActor* CurrentActor;                                                       // 0x00D8 (size: 0x8)
    FMapEditorSnapping SnapAmount;                                                    // 0x0118 (size: 0xC)

    void UnpossessToReturnPawn();
    void Undo();
    void SpawnActor(TSubclassOf<class AActor> ActorClass);
    void ShowScale();
    void ShowRotation();
    void ShowMovement();
    void SetSnapAmount(FMapEditorSnapping SnappingAmounts);
    void SetReturnPawn(class APawn* Pawn);
    void SetActorTransform(const FTransform NewTransform);
    void SetActor(class AActor* Actor);
    void Server_UnpossessToReturnPawn();
    void Server_SpawnActor(TSubclassOf<class AActor> ActorClass);
    void Server_ReplicateTransform(class AActor* Actor, FTransform Transform);
    void Server_DeleteActor(class AActor* Actor);
    void Release();
    void OnRep_CurrentActor();
    FHitResult MouseTrace(float Distance, bool& bHitGizmo, bool bDrawDebugLine);
    void Init();
    bool HasValidReturnPawn();
    void Grab();
    FMapEditorSnapping GetSnapAmount();
    float GetReplicationRate();
    EGizmoType GetGizmoType();
    FTransform GetActorTransform();
    FString GetActorName();
    void DeselectActor();
    void DeleteActor();
}; // Size: 0x140

class UMapEditorStatics : public UBlueprintFunctionLibrary
{

    void SpawnMapItemsFromJson(class AActor* WorldActor, FString JsonString);
    void SpawnMapItems(class AActor* WorldActor, FMapEditorItems MapItems);
    void SetMaterials(const FMapEditorItemMaterial& MapEditorItemMaterial);
    FString SerializeLevel(class AActor* WorldActor, bool& Success);
    bool SaveMapToFile(class AActor* WorldActor, FString MapDirectory, FString MapName, FString StringToSave, FString& FullMapName);
    FString RemoveExtension(FString String);
    bool LoadMapFromFile(class AActor* WorldActor, FString MapDirectory, FString MapName, FString Extension, FString& OutString, FString& FullMapName);
    FString GetRealMapName(FString MapName);
    TArray<FString> GetMapList(class AActor* WorldActor, FString Directory, bool bCutLevelname, bool bShowAllMaps);
    bool DoesMapExist(class AActor* WorldActor, FString MapDirectory, FString MapName);
    FMapEditorItems DeSerializeLevel(FString JsonString, bool& Success);
    void ClearMap(class AActor* WorldActor);
}; // Size: 0x28

class UMissionData : public UObject
{
    FString TargetEscapeLevel;                                                        // 0x0028 (size: 0x10)
    float TimeCompleted;                                                              // 0x0038 (size: 0x4)
    int32 PlayerDeaths;                                                               // 0x003C (size: 0x4)
    int32 EntitySightings;                                                            // 0x0040 (size: 0x4)
    int32 LowSanityAmount;                                                            // 0x0044 (size: 0x4)
    float XPPenalty;                                                                  // 0x0048 (size: 0x4)
    float LevelBaseXP;                                                                // 0x004C (size: 0x4)
    float LevelTimeLimit;                                                             // 0x0050 (size: 0x4)
    FString MissionDataRowName;                                                       // 0x0058 (size: 0x10)

    void SetTimeCompleted(float Time);
    void AddPlayerDeath();
    void AddLowSanityAmount();
    void AddEntitySighting();
}; // Size: 0x68

class UMotionScannerComponent : public UActorComponent
{
    FMotionScannerComponentOnScannerWaveUpdate OnScannerWaveUpdate;                   // 0x00B0 (size: 0x10)
    void ScannerWaveUpdateDelegate(TArray<FTargetsStruct> OutTargets, FTelemetryStruct OutTelemetry);
    EMotionComponentType ComponentType;                                               // 0x00C0 (size: 0x1)
    FTargetStruct TargetParameters;                                                   // 0x00C8 (size: 0x18)
    FScannerStruct ScannerParameters;                                                 // 0x00E0 (size: 0x20)
    FTimerHandle RegisterComponent_Handle;                                            // 0x0100 (size: 0x8)
    int32 TryRegister;                                                                // 0x0108 (size: 0x4)
    class AMotionScannerDirector* ScannerDirector;                                    // 0x0110 (size: 0x8)
    TArray<FTargetsStruct> TargetsArr;                                                // 0x0118 (size: 0x10)
    float CheckTargetsRate;                                                           // 0x0128 (size: 0x4)
    bool bIsLocalController;                                                          // 0x012C (size: 0x1)
    TArray<FTargetsStruct> VisibleTargetsArr;                                         // 0x0130 (size: 0x10)
    TArray<FTargetsStruct> LastTargetsArr;                                            // 0x0140 (size: 0x10)
    FTelemetryStruct TelemetryScanner;                                                // 0x0150 (size: 0x8)
    bool bResetValue;                                                                 // 0x0158 (size: 0x1)

    void StartWaveEvent();
    void SetNewScanDistance(float setDistance);
    void ScannerWaveUpdateDelegate__DelegateSignature(TArray<FTargetsStruct> OutTargets, FTelemetryStruct OutTelemetry);
    void EndWaveEvent();
}; // Size: 0x160

class UPlayerStatsComponent : public UActorComponent
{
    TArray<FCollectible> Collectibles;                                                // 0x00B0 (size: 0x10)

}; // Size: 0xC0

class URadarPlayerComponent : public UActorComponent
{
    FRadarPlayerComponentOnScannerWaveUpdate OnScannerWaveUpdate;                     // 0x00B0 (size: 0x10)
    void ScannerWaveUpdateDelegate(TArray<FRadarTargetStruct> OutTargets, FTelemetryStruct OutTelemetry);
    EMotionComponentType ComponentType;                                               // 0x00C0 (size: 0x1)
    FTargetStruct TargetParameters;                                                   // 0x00C8 (size: 0x18)
    FScannerStruct ScannerParameters;                                                 // 0x00E0 (size: 0x20)
    FTimerHandle RegisterComponent_Handle;                                            // 0x0100 (size: 0x8)
    int32 TryRegister;                                                                // 0x0108 (size: 0x4)
    class ARadarMap* RadarMap;                                                        // 0x0110 (size: 0x8)
    TArray<FRadarTargetStruct> TargetsArr;                                            // 0x0118 (size: 0x10)
    float CheckTargetsRate;                                                           // 0x0128 (size: 0x4)
    bool bIsLocalController;                                                          // 0x012C (size: 0x1)
    TArray<FRadarTargetStruct> VisibleTargetsArr;                                     // 0x0130 (size: 0x10)
    TArray<FRadarTargetStruct> LastTargetsArr;                                        // 0x0140 (size: 0x10)
    FTelemetryStruct TelemetryScanner;                                                // 0x0150 (size: 0x8)
    bool bResetValue;                                                                 // 0x0158 (size: 0x1)

    void StartWaveEvent();
    void SetNewScanDistance(float setDistance);
    void ScannerWaveUpdateDelegate__DelegateSignature(TArray<FRadarTargetStruct> OutTargets, FTelemetryStruct OutTelemetry);
    void EndWaveEvent();
}; // Size: 0x160

class USteamManager : public UObject
{
    class UFancyGameInstance* FancyGameInstance;                                      // 0x0048 (size: 0x8)

}; // Size: 0x58

#endif
