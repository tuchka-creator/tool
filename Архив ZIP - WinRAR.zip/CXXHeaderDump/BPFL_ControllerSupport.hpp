#ifndef UE4SS_SDK_BPFL_ControllerSupport_HPP
#define UE4SS_SDK_BPFL_ControllerSupport_HPP

class UBPFL_ControllerSupport_C : public UBlueprintFunctionLibrary
{

    void GetGridNavigationNextIndex(int32 CurrentIndex, int32 ArrayLength, int32 Columns, EUINavigation Direction, class UObject* __WorldContext, int32& NewIndex);
}; // Size: 0x28

#endif
