#ifndef UE4SS_SDK_BTService_CheckVisiblePlayers_HPP
#define UE4SS_SDK_BTService_CheckVisiblePlayers_HPP

class UBTService_CheckVisiblePlayers_C : public UBTService_BlueprintBase
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x0098 (size: 0x8)

    void ReceiveTickAI(class AAIController* OwnerController, class APawn* ControlledPawn, float DeltaSeconds);
    void ExecuteUbergraph_BTService_CheckVisiblePlayers(int32 EntryPoint);
}; // Size: 0xA0

#endif
