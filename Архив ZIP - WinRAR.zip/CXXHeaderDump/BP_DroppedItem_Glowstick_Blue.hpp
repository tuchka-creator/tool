#ifndef UE4SS_SDK_BP_DroppedItem_Glowstick_Blue_HPP
#define UE4SS_SDK_BP_DroppedItem_Glowstick_Blue_HPP

class ABP_DroppedItem_Glowstick_Blue_C : public ABP_DroppedItem_Glowstick_C
{
}; // Size: 0x2B5

#endif
