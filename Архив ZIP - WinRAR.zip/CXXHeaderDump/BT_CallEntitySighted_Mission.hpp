#ifndef UE4SS_SDK_BT_CallEntitySighted_Mission_HPP
#define UE4SS_SDK_BT_CallEntitySighted_Mission_HPP

class UBT_CallEntitySighted_Mission_C : public UBTTask_BlueprintBase
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x00A8 (size: 0x8)

    void ReceiveExecuteAI(class AAIController* OwnerController, class APawn* ControlledPawn);
    void ExecuteUbergraph_BT_CallEntitySighted_Mission(int32 EntryPoint);
}; // Size: 0xB0

#endif
