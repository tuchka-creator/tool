#ifndef UE4SS_SDK_BP_Item_Glowstick_Red_HPP
#define UE4SS_SDK_BP_Item_Glowstick_Red_HPP

class ABP_Item_Glowstick_Red_C : public ABP_Item_Glowstick_C
{
}; // Size: 0x291

#endif
