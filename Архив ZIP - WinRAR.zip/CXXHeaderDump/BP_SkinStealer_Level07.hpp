#ifndef UE4SS_SDK_BP_SkinStealer_Level07_HPP
#define UE4SS_SDK_BP_SkinStealer_Level07_HPP

class ABP_SkinStealer_Level07_C : public ABP_SkinStealer_C
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x0558 (size: 0x8)
    float Timeline_0_Speed_D7C79FA14894E597DC9F8A98D999EEAE;                          // 0x0560 (size: 0x4)
    TEnumAsByte<ETimelineDirection::Type> Timeline_0__Direction_D7C79FA14894E597DC9F8A98D999EEAE; // 0x0564 (size: 0x1)
    class UTimelineComponent* Timeline_0;                                             // 0x0568 (size: 0x8)
    bool LessSight;                                                                   // 0x0570 (size: 0x1)
    bool LessSpeed;                                                                   // 0x0571 (size: 0x1)

    void Timeline_0__FinishedFunc();
    void Timeline_0__UpdateFunc();
    void UpdateEvent();
    void ReceiveBeginPlay();
    void JumpTimer();
    void ToggleSprint(bool IsSprinting);
    void ExecuteUbergraph_BP_SkinStealer_Level07(int32 EntryPoint);
}; // Size: 0x572

#endif
