namespace FootstepActionsEnum {
    enum Type {
        NewEnumerator0 = 0,
        NewEnumerator1 = 1,
        FootstepActionsEnum_MAX = 2,
    };
}

