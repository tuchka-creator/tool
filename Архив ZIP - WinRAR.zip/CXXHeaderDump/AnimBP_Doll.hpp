#ifndef UE4SS_SDK_AnimBP_Doll_HPP
#define UE4SS_SDK_AnimBP_Doll_HPP

class UAnimBP_Doll_C : public UAnimInstance
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x02C0 (size: 0x8)
    FAnimNode_Root AnimGraphNode_Root;                                                // 0x02C8 (size: 0x30)
    FAnimNode_BlendSpacePlayer AnimGraphNode_BlendSpacePlayer;                        // 0x02F8 (size: 0xE8)
    float Speed;                                                                      // 0x03E0 (size: 0x4)

    void AnimGraph(FPoseLink& AnimGraph);
    void BlueprintUpdateAnimation(float DeltaTimeX);
    void ExecuteUbergraph_AnimBP_Doll(int32 EntryPoint);
}; // Size: 0x3E4

#endif
