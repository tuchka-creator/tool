#ifndef UE4SS_SDK_BP_SG_GameSettings_HPP
#define UE4SS_SDK_BP_SG_GameSettings_HPP

class UBP_SG_GameSettings_C : public USaveGame
{
    FS_AudioSettings S_AudioSettings;                                                 // 0x0028 (size: 0x1C)
    float MouseSensitivity;                                                           // 0x0044 (size: 0x4)
    bool InvertMouse;                                                                 // 0x0048 (size: 0x1)
    bool HasMotionBlur;                                                               // 0x0049 (size: 0x1)
    float InputGain;                                                                  // 0x004C (size: 0x4)
    TEnumAsByte<E_CameraSetting::Type> CameraSetting;                                 // 0x0050 (size: 0x1)
    bool ShowBody;                                                                    // 0x0051 (size: 0x1)
    bool HasSeenVHS;                                                                  // 0x0052 (size: 0x1)
    bool UsingPushToTalk;                                                             // 0x0053 (size: 0x1)
    int32 FOV;                                                                        // 0x0054 (size: 0x4)
    bool SmoothRotation;                                                              // 0x0058 (size: 0x1)
    bool HideGore;                                                                    // 0x0059 (size: 0x1)
    float Gamma;                                                                      // 0x005C (size: 0x4)
    bool CameraShake;                                                                 // 0x0060 (size: 0x1)
    bool ShowEventContent;                                                            // 0x0061 (size: 0x1)
    bool AimAssist;                                                                   // 0x0062 (size: 0x1)
    bool ControllerFeedback;                                                          // 0x0063 (size: 0x1)
    bool ShowChat;                                                                    // 0x0064 (size: 0x1)
    bool HasAcceptedEULA;                                                             // 0x0065 (size: 0x1)
    bool EnableCrossplay;                                                             // 0x0066 (size: 0x1)

}; // Size: 0x67

#endif
