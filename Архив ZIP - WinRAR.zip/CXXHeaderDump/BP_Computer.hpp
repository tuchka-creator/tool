#ifndef UE4SS_SDK_BP_Computer_HPP
#define UE4SS_SDK_BP_Computer_HPP

class ABP_Computer_C : public AInteractablePawn
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x0308 (size: 0x8)
    class UWidgetInteractionComponent* WidgetInteraction2;                            // 0x0310 (size: 0x8)
    class UWidgetInteractionComponent* WidgetInteraction1;                            // 0x0318 (size: 0x8)
    class UWidgetInteractionComponent* WidgetInteraction;                             // 0x0320 (size: 0x8)
    class UWidgetComponent* Screen;                                                   // 0x0328 (size: 0x8)
    bool CanUse;                                                                      // 0x0330 (size: 0x1)
    bool UpdateLogin;                                                                 // 0x0331 (size: 0x1)
    class UNiagaraComponent* LeftBeam;                                                // 0x0338 (size: 0x8)
    class UNiagaraComponent* RightBeam;                                               // 0x0340 (size: 0x8)
    class ABPCharacter_Demo_C* As BPCharacter Demo;                                   // 0x0348 (size: 0x8)

    void Update Beam();
    void ToggleWidgetInteraction(bool Enable);
    void OnRep_UpdateLogin();
    void InpActEvt_AnyKey_K2Node_InputKeyEvent_1(FKey Key);
    void InpActEvt_AnyKey_K2Node_InputKeyEvent_0(FKey Key);
    void InpActEvt_Interact_K2Node_InputActionEvent_3(FKey Key);
    void InpActEvt_Use_K2Node_InputActionEvent_2(FKey Key);
    void InpActEvt_Use_K2Node_InputActionEvent_1(FKey Key);
    void InpActEvt_Back_K2Node_InputActionEvent_0(FKey Key);
    void ReceivePossessed(class AController* NewController);
    void OnPossess();
    void UnPossess();
    void InpAxisKeyEvt_MouseWheelAxis_K2Node_InputAxisKeyEvent_1(float AxisValue);
    void SetActivated();
    void ReceiveBeginPlay();
    void OnVRPossess(bool bPossess);
    void ToggleScreen(bool IsHidden, bool BypassPassword);
    void MulticastHUBUnlock();
    void ExecuteUbergraph_BP_Computer(int32 EntryPoint);
}; // Size: 0x350

#endif
