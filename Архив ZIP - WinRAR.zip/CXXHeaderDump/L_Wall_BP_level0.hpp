#ifndef UE4SS_SDK_L_Wall_BP_level0_HPP
#define UE4SS_SDK_L_Wall_BP_level0_HPP

class AL_Wall_BP_level0_C : public AActor
{
    class USceneComponent* SharedRoot;                                                // 0x0220 (size: 0x8)

}; // Size: 0x228

#endif
