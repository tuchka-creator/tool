#ifndef UE4SS_SDK_BP_Scanner_HPP
#define UE4SS_SDK_BP_Scanner_HPP

class ABP_Scanner_C : public ABP_Item_C
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x0258 (size: 0x8)
    class ULIDARComponent* LIDARComponent;                                            // 0x0260 (size: 0x8)
    class USkeletalMeshComponent* SkeletalMesh;                                       // 0x0268 (size: 0x8)
    class UStaticMeshComponent* Display;                                              // 0x0270 (size: 0x8)
    class UStaticMeshComponent* Plane1;                                               // 0x0278 (size: 0x8)
    class UTextRenderComponent* TextRenderScanDistancePercent;                        // 0x0280 (size: 0x8)
    class USceneComponent* SideScene;                                                 // 0x0288 (size: 0x8)
    class USceneComponent* CenterScene;                                               // 0x0290 (size: 0x8)
    class UInstancedStaticMeshComponent* InstancedStaticMesh;                         // 0x0298 (size: 0x8)
    class UTextRenderComponent* TextRenderScanPercent;                                // 0x02A0 (size: 0x8)
    class UTextRenderComponent* TextRenderTargets;                                    // 0x02A8 (size: 0x8)
    class UTextRenderComponent* TextRenderDistance;                                   // 0x02B0 (size: 0x8)
    class UStaticMeshComponent* Plane;                                                // 0x02B8 (size: 0x8)
    class UBP_ScannerComponent_C* MotionScannerComponent;                             // 0x02C0 (size: 0x8)
    class UAudioComponent* AudioTarget;                                               // 0x02C8 (size: 0x8)
    bool CanUse;                                                                      // 0x02D0 (size: 0x1)
    bool bIsLiDAREnable;                                                              // 0x02D1 (size: 0x1)
    bool bIsWaveScannerEnbale;                                                        // 0x02D2 (size: 0x1)
    bool bIsMotionScannerEnable;                                                      // 0x02D3 (size: 0x1)
    class UMaterialInstanceDynamic* DMI_MotionScanner;                                // 0x02D8 (size: 0x8)
    TArray<class UStaticMeshComponent*> NpcMeshArr;                                   // 0x02E0 (size: 0x10)
    float MinDetectWaveDistance;                                                      // 0x02F0 (size: 0x4)
    FTimerHandle TargetsSoundTimer;                                                   // 0x02F8 (size: 0x8)
    TArray<FVector> LidarLocation;                                                    // 0x0300 (size: 0x10)
    float DisplaySize;                                                                // 0x0310 (size: 0x4)
    float RotationRay;                                                                // 0x0314 (size: 0x4)
    float ChangeDistanceRot;                                                          // 0x0318 (size: 0x4)
    float TargetDecayRate;                                                            // 0x031C (size: 0x4)
    TArray<FTargetsStruct> NewTargets;                                                // 0x0320 (size: 0x10)
    TArray<FTargetsStruct> LastTargets;                                               // 0x0330 (size: 0x10)
    TArray<class UMotionScannerComponent*> Targets;                                   // 0x0340 (size: 0x10)
    float BeamSpawnPerSecond;                                                         // 0x0350 (size: 0x4)
    float DotScaleFactorSK;                                                           // 0x0354 (size: 0x4)
    int32 NumBeams;                                                                   // 0x0358 (size: 0x4)
    FVector2D UVData;                                                                 // 0x035C (size: 0x8)
    float SkelMeshCollisionUVROF;                                                     // 0x0364 (size: 0x4)
    bool CanRunSKCollisionUV;                                                         // 0x0368 (size: 0x1)
    class UMaterialInstanceDynamic* LIDARDotsMat;                                     // 0x0370 (size: 0x8)
    class UMaterialInstanceDynamic* LIDARGunMat;                                      // 0x0378 (size: 0x8)
    class ABP_ScannerDirector_C* ScanDirector;                                        // 0x0380 (size: 0x8)
    bool UsingFOV;                                                                    // 0x0388 (size: 0x1)

    void SetMaterial(bool EnabledFOV);
    void GetMaterial(class UMaterialInterface* Material, class UMaterialInterface*& Adjusted);
    void LiDAR(float& Delta);
    void InitializeColors();
    void InitializeMaterials();
    void FixUVStretching(FVector HitLocation, FVector HitNormal, class UPrimitiveComponent* HitComponent, int32 FaceIndex, FVector2D HitUVLocation, float& FixedSize, FVector& FixedStretch);
    void ScannerTraceCalc(FVector& TraceStart, FVector& TraceEnd);
    void SetTargetPosition(bool OneTarget, class UMotionScannerComponent* SetMotionScanner, class UStaticMeshComponent* SetNpcMesh);
    void UpdateScanPercent();
    float UpdateMinDistance();
    void UpdateTargetSound(float InFloat, bool bEnable);
    void AddTarget(const FTargetsStruct& TargetsStruct);
    void SetTargets();
    void SetNewPositionTarget(FVector SecondLocation, FVector& ReturnPosition);
    void OnRep_bIsLiDAREnable();
    void OnRep_bIsWaveScannerEnbale();
    void OnRep_bIsMotionScannerEnable();
    void SoundChangeDistance(float& NewDistance);
    void SetStartEnableMotionScanner(bool Activate);
    void ReceiveTick(float DeltaSeconds);
    void SetEnableLiDAR(bool Enable);
    void SetEnableWaveScan(bool bEnable);
    void SetEnableMotionScanner(bool bEnable);
    void BndEvt__BP_Scanner_BP_ScannerComponent_K2Node_ComponentBoundEvent_1_ScannerWaveUpdateDelegate__DelegateSignature(TArray<FTargetsStruct>& OutTargets, FTelemetryStruct OutTelemetry);
    void SetScanDistance(float NewDistance);
    void SpawnScannerBeam(FVector BeamStart, FVector BeamEnd);
    void ResetSKCollisionUVBool();
    void UseItem();
    void BndEvt__BP_Scanner_LIDARComponent_K2Node_ComponentBoundEvent_0_ScannerTraceSignature__DelegateSignature();
    void BndEvt__BP_Scanner_LIDARComponent_K2Node_ComponentBoundEvent_2_ScannerUpdateSignature__DelegateSignature();
    void MC_Fire();
    void Initialize();
    void ReceiveBeginPlay();
    void OC_Fire();
    void SRV_Lidar(FHitResult HitResult, FColor Color);
    void ReceiveDestroyed();
    void ExecuteUbergraph_BP_Scanner(int32 EntryPoint);
}; // Size: 0x389

#endif
