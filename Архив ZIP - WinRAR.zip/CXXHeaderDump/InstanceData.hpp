#ifndef UE4SS_SDK_InstanceData_HPP
#define UE4SS_SDK_InstanceData_HPP

struct FInstanceData
{
    FVector PreviousOffset_2_17DB03C44736BF68509630BB40E0DE33;                        // 0x0000 (size: 0xC)
    FVector GoalOffset_4_1A322E824556A9E8ADFE6788C324C64D;                            // 0x000C (size: 0xC)
    float StartTime_7_D831254640E581AF89DD7E8F8CE07141;                               // 0x0018 (size: 0x4)
    float Duration_9_7BC451984D5FCED9747FD08F7D650E4C;                                // 0x001C (size: 0x4)
    float UnDeformSpeed_11_A423CAED4F9FCF5BFA586A8569D30C4F;                          // 0x0020 (size: 0x4)

}; // Size: 0x24

#endif
