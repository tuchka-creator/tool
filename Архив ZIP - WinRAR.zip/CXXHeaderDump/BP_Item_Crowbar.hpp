#ifndef UE4SS_SDK_BP_Item_Crowbar_HPP
#define UE4SS_SDK_BP_Item_Crowbar_HPP

class ABP_Item_Crowbar_C : public ABP_Item_C
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x0258 (size: 0x8)
    bool CanUse;                                                                      // 0x0260 (size: 0x1)
    class ACrowbar_BP_C* Crowbar;                                                     // 0x0268 (size: 0x8)

    void OnNotifyEnd_751D76F146E38F09943798A236AB1CAA(FName NotifyName);
    void OnNotifyBegin_751D76F146E38F09943798A236AB1CAA(FName NotifyName);
    void OnInterrupted_751D76F146E38F09943798A236AB1CAA(FName NotifyName);
    void OnBlendOut_751D76F146E38F09943798A236AB1CAA(FName NotifyName);
    void OnCompleted_751D76F146E38F09943798A236AB1CAA(FName NotifyName);
    void OnNotifyEnd_BE8B199649F76BBA28D0A884255F0BFA(FName NotifyName);
    void OnNotifyBegin_BE8B199649F76BBA28D0A884255F0BFA(FName NotifyName);
    void OnInterrupted_BE8B199649F76BBA28D0A884255F0BFA(FName NotifyName);
    void OnBlendOut_BE8B199649F76BBA28D0A884255F0BFA(FName NotifyName);
    void OnCompleted_BE8B199649F76BBA28D0A884255F0BFA(FName NotifyName);
    void UseItem();
    void Damage_SERVER(class UObject* Target, class AFancyCharacter* Character);
    void PlayAnimation();
    void OC_Trace();
    void ExecuteUbergraph_BP_Item_Crowbar(int32 EntryPoint);
}; // Size: 0x270

#endif
