#ifndef UE4SS_SDK_BP_Item_AlmondBottle_HPP
#define UE4SS_SDK_BP_Item_AlmondBottle_HPP

class ABP_Item_AlmondBottle_C : public ABP_Item_C
{
    class UStaticMeshComponent* StaticMesh;                                           // 0x0258 (size: 0x8)

    void SetMaterial(bool EnabledFOV);
}; // Size: 0x260

#endif
