#ifndef UE4SS_SDK_Grass2_Component_BP_HPP
#define UE4SS_SDK_Grass2_Component_BP_HPP

class UGrass2_Component_BP_C : public UINTERACTIVE_FoliageComp_BP_C
{
}; // Size: 0x7F8

#endif
