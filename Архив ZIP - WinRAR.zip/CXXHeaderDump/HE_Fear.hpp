#ifndef UE4SS_SDK_HE_Fear_HPP
#define UE4SS_SDK_HE_Fear_HPP

struct FHE_Fear
{
    bool FearAnimation_9_0E486C1142B37F96E07FAE8158BEF0FA;                            // 0x0000 (size: 0x1)
    bool FearSound_2_49CB5D39413F6879091FAC8EC104A385;                                // 0x0001 (size: 0x1)
    class USoundBase* CustomFearSoundOptional_6_054E50E941988E832A422AB0377B6117;     // 0x0008 (size: 0x8)
    float -DelayBeforeFear_12_F3DB113843ED8BCE85522DB06035366A;                       // 0x0010 (size: 0x4)

}; // Size: 0x14

#endif
