#ifndef UE4SS_SDK_BP_Hound_HPP
#define UE4SS_SDK_BP_Hound_HPP

class ABP_Hound_C : public ACharacter
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x04C0 (size: 0x8)
    class UAudioComponent* Audio1;                                                    // 0x04C8 (size: 0x8)
    class USceneComponent* EyeSight;                                                  // 0x04D0 (size: 0x8)
    class UBoxComponent* Box;                                                         // 0x04D8 (size: 0x8)
    class USphereComponent* KillPlayer;                                               // 0x04E0 (size: 0x8)
    class UAudioComponent* Audio;                                                     // 0x04E8 (size: 0x8)
    bool ShouldMove;                                                                  // 0x04F0 (size: 0x1)
    bool CanAttack;                                                                   // 0x04F1 (size: 0x1)
    bool IsTargetting;                                                                // 0x04F2 (size: 0x1)
    class AActor* RetreatActor;                                                       // 0x04F8 (size: 0x8)
    bool DestroyOnRetreat;                                                            // 0x0500 (size: 0x1)
    bool ShouldRoam;                                                                  // 0x0501 (size: 0x1)
    FTransform RetreatTransform;                                                      // 0x0510 (size: 0x30)
    class UBehaviorTree* BTAsset;                                                     // 0x0540 (size: 0x8)
    bool CanChase;                                                                    // 0x0548 (size: 0x1)
    float SprintSpeed;                                                                // 0x054C (size: 0x4)
    bool ShouldCheckDelete;                                                           // 0x0550 (size: 0x1)
    bool ShouldRemoveInNormal;                                                        // 0x0551 (size: 0x1)
    bool CanStun;                                                                     // 0x0552 (size: 0x1)
    bool IsRetreating;                                                                // 0x0553 (size: 0x1)
    bool CanHowl;                                                                     // 0x0554 (size: 0x1)

    void OnRep_CanHowl();
    void GetStunDuration(float& Delay);
    void CanSeePlayer(class ABPCharacter_Demo_C* Target, bool& CanSee);
    void LookAtTarget(class ABPCharacter_Demo_C* Target);
    void OnRep_IsTargetting();
    void StopMovement();
    void LookAtEntity(class ABPCharacter_Demo_C* Target);
    void OnNotifyEnd_61765EC24FF4E248EA3B909C032488D4(FName NotifyName);
    void OnNotifyBegin_61765EC24FF4E248EA3B909C032488D4(FName NotifyName);
    void OnInterrupted_61765EC24FF4E248EA3B909C032488D4(FName NotifyName);
    void OnBlendOut_61765EC24FF4E248EA3B909C032488D4(FName NotifyName);
    void OnCompleted_61765EC24FF4E248EA3B909C032488D4(FName NotifyName);
    void OnNotifyEnd_8DA5DC9D4777A3A447018893354E8C0B(FName NotifyName);
    void OnNotifyBegin_8DA5DC9D4777A3A447018893354E8C0B(FName NotifyName);
    void OnInterrupted_8DA5DC9D4777A3A447018893354E8C0B(FName NotifyName);
    void OnBlendOut_8DA5DC9D4777A3A447018893354E8C0B(FName NotifyName);
    void OnCompleted_8DA5DC9D4777A3A447018893354E8C0B(FName NotifyName);
    void OnFail_D233563A4C47828202C239AEFB9124B7(TEnumAsByte<EPathFollowingResult::Type> MovementResult);
    void OnSuccess_D233563A4C47828202C239AEFB9124B7(TEnumAsByte<EPathFollowingResult::Type> MovementResult);
    void ReceiveBeginPlay();
    void StartSound();
    void StopSound();
    void AttackPlayer(class ABPCharacter_Demo_C* Player);
    void MC_KillSound();
    void Jumpscare(class ABPCharacter_Demo_C* Player);
    void PlayHowl();
    void PlayBlinded();
    void MC_KillAnimation(class ABPCharacter_Demo_C* Target);
    void Retreat();
    void ResetRetreat();
    void BlindHound();
    void ResetBlinded();
    void BndEvt__BP_Hound_KillPlayer_K2Node_ComponentBoundEvent_0_ComponentBeginOverlapSignature__DelegateSignature(class UPrimitiveComponent* OverlappedComponent, class AActor* OtherActor, class UPrimitiveComponent* OtherComp, int32 OtherBodyIndex, bool bFromSweep, const FHitResult& SweepResult);
    void BndEvt__BP_Hound_KillPlayer_K2Node_ComponentBoundEvent_1_ComponentEndOverlapSignature__DelegateSignature(class UPrimitiveComponent* OverlappedComponent, class AActor* OtherActor, class UPrimitiveComponent* OtherComp, int32 OtherBodyIndex);
    void MC_Stop(float Delay);
    void ResetHowl();
    void ExecuteUbergraph_BP_Hound(int32 EntryPoint);
}; // Size: 0x555

#endif
