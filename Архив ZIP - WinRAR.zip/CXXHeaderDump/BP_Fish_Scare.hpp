#ifndef UE4SS_SDK_BP_Fish_Scare_HPP
#define UE4SS_SDK_BP_Fish_Scare_HPP

class ABP_Fish_Scare_C : public ACharacter
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x04C0 (size: 0x8)
    class USceneComponent* GrabPoint;                                                 // 0x04C8 (size: 0x8)
    class UAudioComponent* Audio;                                                     // 0x04D0 (size: 0x8)
    class UCameraComponent* Camera;                                                   // 0x04D8 (size: 0x8)
    class UParticleSystemComponent* ParticleSystem;                                   // 0x04E0 (size: 0x8)
    class USkeletalMeshComponent* SkeletalMesh;                                       // 0x04E8 (size: 0x8)
    class USceneComponent* Scene;                                                     // 0x04F0 (size: 0x8)
    float MoveToPlayerTimeline_Alpha_696ABA8141B5CBEA312C85AC914ECC91;                // 0x04F8 (size: 0x4)
    TEnumAsByte<ETimelineDirection::Type> MoveToPlayerTimeline__Direction_696ABA8141B5CBEA312C85AC914ECC91; // 0x04FC (size: 0x1)
    class UTimelineComponent* MoveToPlayerTimeline;                                   // 0x0500 (size: 0x8)
    class ABPCharacter_Demo_C* TargetPlayer;                                          // 0x0508 (size: 0x8)
    FVector StartingLocation;                                                         // 0x0510 (size: 0xC)
    bool IsHidden;                                                                    // 0x051C (size: 0x1)
    class A8_FFT_H_Ocean_Sim_C* Ocean;                                                // 0x0520 (size: 0x8)

    void CheckIsTarget();
    void OnRep_IsHidden();
    void MoveToPlayerTimeline__FinishedFunc();
    void MoveToPlayerTimeline__UpdateFunc();
    void OnNotifyEnd_3C9788444D186AB30CD35E8E370CE027(FName NotifyName);
    void OnNotifyBegin_3C9788444D186AB30CD35E8E370CE027(FName NotifyName);
    void OnInterrupted_3C9788444D186AB30CD35E8E370CE027(FName NotifyName);
    void OnBlendOut_3C9788444D186AB30CD35E8E370CE027(FName NotifyName);
    void OnCompleted_3C9788444D186AB30CD35E8E370CE027(FName NotifyName);
    void ReceiveBeginPlay();
    void MC_Scream();
    void MC_Splash(FVector Location);
    void MoveToPlayer();
    void ReceiveTick(float DeltaSeconds);
    void ReceiveDestroyed();
    void MC_Eat();
    void ExecuteUbergraph_BP_Fish_Scare(int32 EntryPoint);
}; // Size: 0x528

#endif
