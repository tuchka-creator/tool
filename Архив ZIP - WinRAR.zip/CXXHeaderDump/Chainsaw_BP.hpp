#ifndef UE4SS_SDK_Chainsaw_BP_HPP
#define UE4SS_SDK_Chainsaw_BP_HPP

class AChainsaw_BP_C : public AActor
{
    class USkeletalMeshComponent* SkeletalMesh;                                       // 0x0220 (size: 0x8)
    class USceneComponent* DefaultSceneRoot;                                          // 0x0228 (size: 0x8)

}; // Size: 0x230

#endif
