#ifndef UE4SS_SDK_BP_ControllerDisconnectionFlow_HPP
#define UE4SS_SDK_BP_ControllerDisconnectionFlow_HPP

class UBP_ControllerDisconnectionFlow_C : public UFancyUserFlow
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x00A8 (size: 0x8)
    class UWidget* FocusedWidget;                                                     // 0x00B0 (size: 0x8)
    class UW_ControllerDisconnectNotification_C* ControllerWidgetRef;                 // 0x00B8 (size: 0x8)

    void Run();
    void Prepare(class UUserWidget* Modal);
    void HandleComplete(class UUserWidget* Modal);
    void ExecuteUbergraph_BP_ControllerDisconnectionFlow(int32 EntryPoint);
}; // Size: 0xC0

#endif
