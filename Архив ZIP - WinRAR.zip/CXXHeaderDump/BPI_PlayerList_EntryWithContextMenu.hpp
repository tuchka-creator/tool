#ifndef UE4SS_SDK_BPI_PlayerList_EntryWithContextMenu_HPP
#define UE4SS_SDK_BPI_PlayerList_EntryWithContextMenu_HPP

class IBPI_PlayerList_EntryWithContextMenu_C : public IInterface
{

    void CloseContextMenu(bool bShouldRegainFocus);
}; // Size: 0x28

#endif
