#ifndef UE4SS_SDK_BP_Stairs_Module_HPP
#define UE4SS_SDK_BP_Stairs_Module_HPP

class ABP_Stairs_Module_C : public AActor
{
    class UStaticMeshComponent* StairsModule;                                         // 0x0220 (size: 0x8)

}; // Size: 0x228

#endif
