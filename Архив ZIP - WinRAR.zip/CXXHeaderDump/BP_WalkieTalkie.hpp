#ifndef UE4SS_SDK_BP_WalkieTalkie_HPP
#define UE4SS_SDK_BP_WalkieTalkie_HPP

class ABP_WalkieTalkie_C : public ABP_Item_C
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x0258 (size: 0x8)
    class USceneComponent* Scene1;                                                    // 0x0260 (size: 0x8)
    class UAudioComponent* Audio;                                                     // 0x0268 (size: 0x8)
    class UStaticMeshComponent* Walkie_Talkie_low_RightButton_low;                    // 0x0270 (size: 0x8)
    class UStaticMeshComponent* Walkie_Talkie_low_MidButton_low;                      // 0x0278 (size: 0x8)
    class UStaticMeshComponent* Walkie_Talkie_low_LeftButton_low;                     // 0x0280 (size: 0x8)
    class UStaticMeshComponent* Walkie_Talkie_low_Antenna_low;                        // 0x0288 (size: 0x8)
    class ABP_WalkieTalkie_Display_C* Display;                                        // 0x0290 (size: 0x8)
    bool IsUsingFOV;                                                                  // 0x0298 (size: 0x1)
    int32 NumConnected;                                                               // 0x029C (size: 0x4)

    void ActivateRadio();
    void OnRep_NumConnected();
    void ResetAlarm();
    void SetMaterial(bool EnabledFOV);
    void OnNotifyEnd_0A19368B42B332B8561A4A9702E5897B(FName NotifyName);
    void OnNotifyBegin_0A19368B42B332B8561A4A9702E5897B(FName NotifyName);
    void OnInterrupted_0A19368B42B332B8561A4A9702E5897B(FName NotifyName);
    void OnBlendOut_0A19368B42B332B8561A4A9702E5897B(FName NotifyName);
    void OnCompleted_0A19368B42B332B8561A4A9702E5897B(FName NotifyName);
    void OnNotifyEnd_F5534A844701AD21AB1B749705B92259(FName NotifyName);
    void OnNotifyBegin_F5534A844701AD21AB1B749705B92259(FName NotifyName);
    void OnInterrupted_F5534A844701AD21AB1B749705B92259(FName NotifyName);
    void OnBlendOut_F5534A844701AD21AB1B749705B92259(FName NotifyName);
    void OnCompleted_F5534A844701AD21AB1B749705B92259(FName NotifyName);
    void ReceiveDestroyed();
    void MC_Alarm();
    void ReceiveBeginPlay();
    void MC_Connect();
    void PlaySubtitle();
    void UseItem();
    void ExecuteUbergraph_BP_WalkieTalkie(int32 EntryPoint);
}; // Size: 0x2A0

#endif
