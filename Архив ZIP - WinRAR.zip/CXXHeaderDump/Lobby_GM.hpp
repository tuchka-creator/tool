#ifndef UE4SS_SDK_Lobby_GM_HPP
#define UE4SS_SDK_Lobby_GM_HPP

class ALobby_GM_C : public ABase_GM_C
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x0328 (size: 0x8)
    bool CanHostForceLaunchGame?;                                                     // 0x0330 (size: 0x1)

    void Create_MapTravel_loadingScreens(FName& Current_Map);
    void OnFailure_F50D1CF648B7A4D4DBC83AAEA611330C();
    void OnSuccess_F50D1CF648B7A4D4DBC83AAEA611330C();
    void K2_PostLogin(class APlayerController* NewPlayer);
    void K2_OnLogout(class AController* ExitingController);
    void ServerTravel();
    void ReceiveBeginPlay();
    void UpdateCanJoin();
    void DisconnectAllPlayers();
    void ExecuteUbergraph_Lobby_GM(int32 EntryPoint);
}; // Size: 0x331

#endif
