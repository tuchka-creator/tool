#ifndef UE4SS_SDK_BP_Liquid_Pain_HPP
#define UE4SS_SDK_BP_Liquid_Pain_HPP

class ABP_Liquid_Pain_C : public ABP_Item_C
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x0258 (size: 0x8)
    class UStaticMeshComponent* StaticMesh1;                                          // 0x0260 (size: 0x8)
    class UStaticMeshComponent* StaticMesh;                                           // 0x0268 (size: 0x8)
    float Timeline_0_Alpha_00A56D914DB109813D34C892B224E8A0;                          // 0x0270 (size: 0x4)
    float Timeline_0_Drink_00A56D914DB109813D34C892B224E8A0;                          // 0x0274 (size: 0x4)
    TEnumAsByte<ETimelineDirection::Type> Timeline_0__Direction_00A56D914DB109813D34C892B224E8A0; // 0x0278 (size: 0x1)
    class UTimelineComponent* Timeline_0;                                             // 0x0280 (size: 0x8)
    class UMaterialInstanceDynamic* DynamicMaterial;                                  // 0x0288 (size: 0x8)

    void SetMaterial(bool EnabledFOV);
    void Timeline_0__FinishedFunc();
    void Timeline_0__UpdateFunc();
    void OnNotifyEnd_0F271FAE4B4291EFCF443CB4D7BCBFE5(FName NotifyName);
    void OnNotifyBegin_0F271FAE4B4291EFCF443CB4D7BCBFE5(FName NotifyName);
    void OnInterrupted_0F271FAE4B4291EFCF443CB4D7BCBFE5(FName NotifyName);
    void OnBlendOut_0F271FAE4B4291EFCF443CB4D7BCBFE5(FName NotifyName);
    void OnCompleted_0F271FAE4B4291EFCF443CB4D7BCBFE5(FName NotifyName);
    void UseItem();
    void PlayAnimation();
    void SRV_FinishDrink();
    void ReceiveBeginPlay();
    void ExecuteUbergraph_BP_Liquid_Pain(int32 EntryPoint);
}; // Size: 0x290

#endif
