#ifndef UE4SS_SDK_BP_Diving_Helmet_HPP
#define UE4SS_SDK_BP_Diving_Helmet_HPP

class ABP_Diving_Helmet_C : public ABP_Item_C
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x0258 (size: 0x8)
    float Shift_Alpha_02C40AF140D00309DDBC96B377376A90;                               // 0x0260 (size: 0x4)
    TEnumAsByte<ETimelineDirection::Type> Shift__Direction_02C40AF140D00309DDBC96B377376A90; // 0x0264 (size: 0x1)
    class UTimelineComponent* Shift;                                                  // 0x0268 (size: 0x8)
    FTransform StartTransform;                                                        // 0x0270 (size: 0x30)
    FTransform OffsetTransform;                                                       // 0x02A0 (size: 0x30)

    void Shift__FinishedFunc();
    void Shift__UpdateFunc();
    void OnNotifyEnd_3FE3233945D5FF790518F1ADBD2F23FC(FName NotifyName);
    void OnNotifyBegin_3FE3233945D5FF790518F1ADBD2F23FC(FName NotifyName);
    void OnInterrupted_3FE3233945D5FF790518F1ADBD2F23FC(FName NotifyName);
    void OnBlendOut_3FE3233945D5FF790518F1ADBD2F23FC(FName NotifyName);
    void OnCompleted_3FE3233945D5FF790518F1ADBD2F23FC(FName NotifyName);
    void UseItem();
    void PlayAnimation();
    void SRV_EquipHelmet();
    void ReceiveBeginPlay();
    void MC_BlockPickup();
    void ExecuteUbergraph_BP_Diving_Helmet(int32 EntryPoint);
}; // Size: 0x2D0

#endif
