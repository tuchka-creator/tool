#ifndef UE4SS_SDK_BP_DroppedItem_Knife_HPP
#define UE4SS_SDK_BP_DroppedItem_Knife_HPP

class ABP_DroppedItem_Knife_C : public ABP_DroppedItem_C
{
    class UStaticMeshComponent* StaticMesh;                                           // 0x0270 (size: 0x8)

}; // Size: 0x278

#endif
