#ifndef UE4SS_SDK_BP_LadderCamera_HPP
#define UE4SS_SDK_BP_LadderCamera_HPP

class ABP_LadderCamera_C : public AInteractablePawn
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x0308 (size: 0x8)

    void ReceiveBeginPlay();
    void ReceivePossessed(class AController* NewController);
    void UnPossess();
    void ExecuteUbergraph_BP_LadderCamera(int32 EntryPoint);
}; // Size: 0x310

#endif
