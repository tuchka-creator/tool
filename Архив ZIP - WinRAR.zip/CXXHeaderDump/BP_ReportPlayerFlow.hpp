#ifndef UE4SS_SDK_BP_ReportPlayerFlow_HPP
#define UE4SS_SDK_BP_ReportPlayerFlow_HPP

class UBP_ReportPlayerFlow_C : public UFancyUserFlow
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x00A8 (size: 0x8)
    bool Show Block Option;                                                           // 0x00B0 (size: 0x1)
    FString PlayerName;                                                               // 0x00B8 (size: 0x10)
    EFancyPlatform Platform;                                                          // 0x00C8 (size: 0x1)
    FBPUniqueNetId PlayerNetID;                                                       // 0x00D0 (size: 0x28)
    class UWidget* PrevFocusedWidget;                                                 // 0x00F8 (size: 0x8)
    bool bDidBlock;                                                                   // 0x0100 (size: 0x1)

    void MakeExplanation(TArray<class UW_ReportPlayer_ReasonButton_C*>& SelectedReasonButtons, FString& Explanation);
    void OnComplete(class UUserWidget* Modal);
    void SentPlayerReport();
    void ResetInputAndComplete();
    void OnPrepare(class UUserWidget* Modal);
    void Run();
    void OnBlockComplete(bool bSuccess, const FBPUniqueNetId& NetId, FString Name);
    void ExecuteUbergraph_BP_ReportPlayerFlow(int32 EntryPoint);
}; // Size: 0x101

#endif
