#ifndef UE4SS_SDK_HE_LookAtActor_HPP
#define UE4SS_SDK_HE_LookAtActor_HPP

struct FHE_LookAtActor
{
    TArray<FHE_LookAtActorSeq> LookatActorsSequence_23_08279B704682B57A7B58B18AAEEB7C94; // 0x0000 (size: 0x10)
    float -DelayBeforeLookingSequenceSec_21_46B29F5047553D83F96803B9CEE30F22;         // 0x0010 (size: 0x4)

}; // Size: 0x14

#endif
