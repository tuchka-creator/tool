#ifndef UE4SS_SDK_BP_Explorer_HPP
#define UE4SS_SDK_BP_Explorer_HPP

class ABP_Explorer_C : public ACharacter
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x04C0 (size: 0x8)
    class UAudioComponent* Audio;                                                     // 0x04C8 (size: 0x8)
    class UFancyCarrySystemCarryable* FancyCarrySystemCarryable;                      // 0x04D0 (size: 0x8)
    bool IsPassedOut;                                                                 // 0x04D8 (size: 0x1)
    int32 Index;                                                                      // 0x04DC (size: 0x4)

    void ResetMaterial();
    void SetFOVMaterial();
    void TogglePassOut(bool IsPassedOut);
    void BndEvt__BP_Explorer_FancyCarrySystemCarryable_K2Node_ComponentBoundEvent_0_OnCarriedEvent__DelegateSignature();
    void BndEvt__BP_Explorer_FancyCarrySystemCarryable_K2Node_ComponentBoundEvent_1_OnCarriedEvent__DelegateSignature();
    void ReceiveBeginPlay();
    void ExecuteUbergraph_BP_Explorer(int32 EntryPoint);
}; // Size: 0x4E0

#endif
