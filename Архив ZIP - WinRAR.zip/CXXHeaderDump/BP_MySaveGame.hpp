#ifndef UE4SS_SDK_BP_MySaveGame_HPP
#define UE4SS_SDK_BP_MySaveGame_HPP

class UBP_MySaveGame_C : public USaveGame
{
    TArray<FS_LevelStats> LevelStats;                                                 // 0x0028 (size: 0x10)
    bool HasSeenCutscene;                                                             // 0x0038 (size: 0x1)
    bool HasSeenEndscene;                                                             // 0x0039 (size: 0x1)
    TArray<FString> SingleplayerSaves;                                                // 0x0040 (size: 0x10)
    TArray<FString> EasySaves;                                                        // 0x0050 (size: 0x10)
    TArray<FString> NormalSaves;                                                      // 0x0060 (size: 0x10)
    TArray<FString> HardSaves;                                                        // 0x0070 (size: 0x10)
    TArray<FString> NightmareSaves;                                                   // 0x0080 (size: 0x10)
    bool HubUnlocked;                                                                 // 0x0090 (size: 0x1)
    int32 CurrentGameBuild;                                                           // 0x0094 (size: 0x4)
    TArray<FString> DocumentsFound;                                                   // 0x0098 (size: 0x10)
    TArray<FST_UI_Mission> MissionData;                                               // 0x00A8 (size: 0x10)
    int32 CurrentXP;                                                                  // 0x00B8 (size: 0x4)
    float SaveGameVersion;                                                            // 0x00BC (size: 0x4)
    TMap<class FString, class FString> SaveDisplayNamesLookup;                        // 0x00C0 (size: 0x50)

    TEnumAsByte<E_Difficulty::Type> GetDifficultyForSlot(FString Slot);
    void DoesSimilarGameEntryExist(FString DisplayName, TEnumAsByte<E_Difficulty::Type> Difficulty, bool& Result);
    void GenerateNewSaveGameName(TEnumAsByte<E_Difficulty::Type> Difficulty, FString& SlotName);
    void GetSaveGameDisplayName(const FString& SlotName, FString& Value);
}; // Size: 0x110

#endif
