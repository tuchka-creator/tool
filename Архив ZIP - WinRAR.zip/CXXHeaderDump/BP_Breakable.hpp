#ifndef UE4SS_SDK_BP_Breakable_HPP
#define UE4SS_SDK_BP_Breakable_HPP

class IBP_Breakable_C : public IInterface
{

    void Damage(class ACharacter* Character);
}; // Size: 0x28

#endif
