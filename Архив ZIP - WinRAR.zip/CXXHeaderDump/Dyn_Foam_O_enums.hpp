namespace Dyn_Foam_O {
    enum Type {
        NewEnumerator0 = 0,
        NewEnumerator1 = 1,
        NewEnumerator2 = 2,
        Dyn_Foam_MAX = 3,
    };
}

