#ifndef UE4SS_SDK_BP_Glowstick_Component_HPP
#define UE4SS_SDK_BP_Glowstick_Component_HPP

class UBP_Glowstick_Component_C : public UActorComponent
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x00B0 (size: 0x8)
    class USpotLightComponent* SpotLight;                                             // 0x00B8 (size: 0x8)

    void TickSpotlight(class USpotLightComponent* SpotLight);
    void TickPointlight(class UPointLightComponent* PointLight, FVector ForwardVector);
    void ExecuteUbergraph_BP_Glowstick_Component(int32 EntryPoint);
}; // Size: 0xC0

#endif
