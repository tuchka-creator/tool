#ifndef UE4SS_SDK_GameEnd_UI_2_HPP
#define UE4SS_SDK_GameEnd_UI_2_HPP

class UGameEnd_UI_2_C : public UUserWidget
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x0270 (size: 0x8)
    class UWidgetAnimation* Fade;                                                     // 0x0278 (size: 0x8)
    class UImage* Image;                                                              // 0x0280 (size: 0x8)
    class UImage* Image_1;                                                            // 0x0288 (size: 0x8)
    class UImage* Image_2;                                                            // 0x0290 (size: 0x8)
    class URichTextBlock* RichTextBlock_110;                                          // 0x0298 (size: 0x8)
    float Time;                                                                       // 0x02A0 (size: 0x4)
    class UMediaPlayer* MediaPlayer;                                                  // 0x02A8 (size: 0x8)
    class UMaterialInstanceDynamic* Mat;                                              // 0x02B0 (size: 0x8)
    FString CurrentMatchID;                                                           // 0x02B8 (size: 0x10)
    class UMaterialInstanceDynamic* Mat_0;                                            // 0x02C8 (size: 0x8)
    class UMaterialInstanceDynamic* Mat_1;                                            // 0x02D0 (size: 0x8)
    class UBinkMediaPlayer* BinkMediaPlayer;                                          // 0x02D8 (size: 0x8)
    FText DefaultEndingText;                                                          // 0x02E0 (size: 0x18)

    FText GetTime();
    void CanClose();
    void Construct();
    void Spectate();
    void OnFinish();
    void ExecuteUbergraph_GameEnd_UI_2(int32 EntryPoint);
}; // Size: 0x2F8

#endif
