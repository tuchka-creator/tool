#ifndef UE4SS_SDK_FluidForceDynamic_HPP
#define UE4SS_SDK_FluidForceDynamic_HPP

struct FFluidForceDynamic
{
    TEnumAsByte<FluidDynamicForceMeshType::Type> ForceType_28_DDC16EE543D2DFD3BA29C49D32198C9C; // 0x0000 (size: 0x1)
    float ForceRadius_32_C31B527C4C367A5CA5E1DF8E49E76234;                            // 0x0004 (size: 0x4)
    float ForceStrength_33_2CAA30794D1EFF60AE1C3491D011CECF;                          // 0x0008 (size: 0x4)
    class USceneComponent* ForceComponent_34_ABF6640F40D37677EF6F809E09046055;        // 0x0010 (size: 0x8)
    class UMaterialInterface* MaterialOverride_25_5A792CE8489A59E5D9B24F9E4DCFE94A;   // 0x0018 (size: 0x8)
    FFluidForceSocketInfo SkeletalMeshSetup_31_51A4130440BAFFBA1DA0FE83E942A30A;      // 0x0020 (size: 0x50)

}; // Size: 0x70

#endif
