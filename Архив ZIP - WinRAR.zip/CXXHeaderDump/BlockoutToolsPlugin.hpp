#ifndef UE4SS_SDK_BlockoutToolsPlugin_HPP
#define UE4SS_SDK_BlockoutToolsPlugin_HPP

#include "BlockoutToolsPlugin_enums.hpp"

class ABlockoutToolsParent : public AActor
{
    class USceneComponent* Root;                                                      // 0x0220 (size: 0x8)
    class UBillboardComponent* Billboard;                                             // 0x0228 (size: 0x8)
    class UMaterialInterface* BlockoutGridParent;                                     // 0x0230 (size: 0x8)
    class UMaterialInstanceDynamic* BlockoutGridMID;                                  // 0x0238 (size: 0x8)
    class UMaterialInterface* BlockoutCurrentMaterial;                                // 0x0240 (size: 0x8)
    TArray<class UStaticMeshComponent*> BlockoutMeshComponents;                       // 0x0248 (size: 0x10)
    TEnumAsByte<EBlockoutMaterialType> BlockoutMaterialType;                          // 0x0258 (size: 0x1)
    FLinearColor BlockoutMaterialColor;                                               // 0x025C (size: 0x10)
    bool bBlockoutMaterialUseGrid;                                                    // 0x026C (size: 0x1)
    bool bBlockoutWorldAligned;                                                       // 0x026D (size: 0x1)
    float BlockoutMaterialGridSize;                                                   // 0x0270 (size: 0x4)
    float BlockoutMaterialCheckerLuminance;                                           // 0x0274 (size: 0x4)
    float BlockoutMaterialRoughness;                                                  // 0x0278 (size: 0x4)
    bool bBlockoutMaterialUseTopColor;                                                // 0x027C (size: 0x1)
    FLinearColor BlockoutMaterialTopColor;                                            // 0x0280 (size: 0x10)
    bool bUseCustomMaterial;                                                          // 0x0290 (size: 0x1)
    class UMaterialInterface* CustomMaterial;                                         // 0x0298 (size: 0x8)
    class UMaterialInterface* BlockoutCustomMaterial;                                 // 0x02A0 (size: 0x8)
    bool bBlockoutEnableCollisions;                                                   // 0x02A8 (size: 0x1)
    bool bBlockoutEnableCustomCollision;                                              // 0x02A9 (size: 0x1)
    FName BlockoutCustomCollisionProfileName;                                         // 0x02AC (size: 0x8)
    bool bBlockoutCastShadows;                                                        // 0x02B4 (size: 0x1)

    void RerunConstructionScript();
    void BlockoutSetMaterial();
}; // Size: 0x2B8

class UBlockoutToolsSettings : public UObject
{
    TEnumAsByte<EBlockoutMaterialType> BlockoutMaterialType;                          // 0x0028 (size: 0x1)
    FLinearColor BlockoutMaterialColor;                                               // 0x002C (size: 0x10)
    bool bBlockoutMaterialUseGrid;                                                    // 0x003C (size: 0x1)
    bool bBlockoutWorldAligned;                                                       // 0x003D (size: 0x1)
    float BlockoutMaterialGridSize;                                                   // 0x0040 (size: 0x4)
    float BlockoutMaterialCheckerLuminance;                                           // 0x0044 (size: 0x4)
    float BlockoutMaterialRoughness;                                                  // 0x0048 (size: 0x4)
    bool bBlockoutMaterialUseTopColor;                                                // 0x004C (size: 0x1)
    FLinearColor BlockoutMaterialTopColor;                                            // 0x0050 (size: 0x10)

}; // Size: 0x60

#endif
