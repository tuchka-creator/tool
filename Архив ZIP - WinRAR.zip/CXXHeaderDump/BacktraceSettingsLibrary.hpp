#ifndef UE4SS_SDK_BacktraceSettingsLibrary_HPP
#define UE4SS_SDK_BacktraceSettingsLibrary_HPP

class UBacktraceSettings : public UDeveloperSettings
{
    FString Token;                                                                    // 0x0038 (size: 0x10)
    FString SymbolsToken;                                                             // 0x0048 (size: 0x10)
    FString Universe;                                                                 // 0x0058 (size: 0x10)
    FString ProjectName;                                                              // 0x0068 (size: 0x10)
    bool bShouldSendDebugBulids;                                                      // 0x0078 (size: 0x1)
    bool bShouldSendReleaseBulids;                                                    // 0x0079 (size: 0x1)
    bool bOverrideGlobalCrashReporterSettings;                                        // 0x007A (size: 0x1)
    bool bPortedOldSettingsStyle;                                                     // 0x007B (size: 0x1)

}; // Size: 0x80

#endif
