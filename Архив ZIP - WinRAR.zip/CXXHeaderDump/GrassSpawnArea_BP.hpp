#ifndef UE4SS_SDK_GrassSpawnArea_BP_HPP
#define UE4SS_SDK_GrassSpawnArea_BP_HPP

class AGrassSpawnArea_BP_C : public AActor
{
    class UInstancedStaticMeshComponent* HeightVisPillars;                            // 0x0220 (size: 0x8)
    class UProceduralMeshComponent* ProceduralMesh;                                   // 0x0228 (size: 0x8)
    class USceneComponent* DefaultSceneRoot;                                          // 0x0230 (size: 0x8)
    TArray<FFoliageToSpawnInArea> FoliageToSpawn;                                     // 0x0238 (size: 0x10)
    float areaHeight;                                                                 // 0x0248 (size: 0x4)
    TArray<FVector> V;                                                                // 0x0250 (size: 0x10)
    TArray<int32> Triangles;                                                          // 0x0260 (size: 0x10)
    TArray<FVector> V_Ceiling;                                                        // 0x0270 (size: 0x10)

    void UserConstructionScript();
}; // Size: 0x280

#endif
