namespace Enum_SegmentDisplayType {
    enum Type {
        NewEnumerator0 = 0,
        NewEnumerator12 = 1,
        NewEnumerator1 = 2,
        NewEnumerator13 = 3,
        NewEnumerator2 = 4,
        NewEnumerator8 = 5,
        NewEnumerator9 = 6,
        NewEnumerator3 = 7,
        NewEnumerator10 = 8,
        NewEnumerator11 = 9,
        Enum_MAX = 10,
    };
}

