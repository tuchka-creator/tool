enum EBlockoutMaterialType {
    BlockoutMaterialType_Grid = 0,
    BlockoutMaterialType_CustomMaterial = 1,
    BlockoutMaterialType_MAX = 2,
};

