#ifndef UE4SS_SDK_BP_Rope_HPP
#define UE4SS_SDK_BP_Rope_HPP

class ABP_Rope_C : public ABP_Item_C
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x0258 (size: 0x8)
    class UCableComponent* Cable;                                                     // 0x0260 (size: 0x8)
    class UArrowComponent* Arrow;                                                     // 0x0268 (size: 0x8)
    float RopeTimeline_Alpha_BA0CED1747FA0DE5DE530399DAA302F1;                        // 0x0270 (size: 0x4)
    TEnumAsByte<ETimelineDirection::Type> RopeTimeline__Direction_BA0CED1747FA0DE5DE530399DAA302F1; // 0x0274 (size: 0x1)
    class UTimelineComponent* RopeTimeline;                                           // 0x0278 (size: 0x8)
    class UDecalComponent* LastDecal;                                                 // 0x0280 (size: 0x8)
    class ABP_RopeZone_C* RopeZone;                                                   // 0x0288 (size: 0x8)
    bool IsUsing;                                                                     // 0x0290 (size: 0x1)
    class ARope_BP_C* Rope;                                                           // 0x0298 (size: 0x8)
    FVector RelativeCharacterLocation;                                                // 0x02A0 (size: 0xC)

    void OnRep_RopeZone();
    void RopeTimeline__FinishedFunc();
    void RopeTimeline__UpdateFunc();
    void RopeTimeline__ShowRope__EventFunc();
    void OnNotifyEnd_6D75097146D9F446056AF481A6C55D82(FName NotifyName);
    void OnNotifyBegin_6D75097146D9F446056AF481A6C55D82(FName NotifyName);
    void OnInterrupted_6D75097146D9F446056AF481A6C55D82(FName NotifyName);
    void OnBlendOut_6D75097146D9F446056AF481A6C55D82(FName NotifyName);
    void OnCompleted_6D75097146D9F446056AF481A6C55D82(FName NotifyName);
    void MC_ThrowCosmetics();
    void TraceForRopeLocation();
    void SRV_TossRope(FVector Location);
    void ReceiveDestroyed();
    void RemoveRope();
    void UseItem();
    void AnimateRopeThrow();
    void ExecuteUbergraph_BP_Rope(int32 EntryPoint);
}; // Size: 0x2AC

#endif
