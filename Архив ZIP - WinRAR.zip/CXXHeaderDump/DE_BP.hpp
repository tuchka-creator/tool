#ifndef UE4SS_SDK_DE_BP_HPP
#define UE4SS_SDK_DE_BP_HPP

class ADE_BP_C : public AActor
{
    class UStaticMeshComponent* StaticMesh3;                                          // 0x0220 (size: 0x8)
    class UStaticMeshComponent* StaticMesh19;                                         // 0x0228 (size: 0x8)
    class UStaticMeshComponent* StaticMesh18;                                         // 0x0230 (size: 0x8)
    class UStaticMeshComponent* StaticMesh2;                                          // 0x0238 (size: 0x8)
    class UStaticMeshComponent* StaticMesh4;                                          // 0x0240 (size: 0x8)
    class UStaticMeshComponent* StaticMesh5;                                          // 0x0248 (size: 0x8)
    class UStaticMeshComponent* StaticMesh6;                                          // 0x0250 (size: 0x8)
    class UStaticMeshComponent* StaticMesh7;                                          // 0x0258 (size: 0x8)
    class UStaticMeshComponent* StaticMesh8;                                          // 0x0260 (size: 0x8)
    class UStaticMeshComponent* StaticMesh9;                                          // 0x0268 (size: 0x8)
    class UStaticMeshComponent* StaticMesh10;                                         // 0x0270 (size: 0x8)
    class UStaticMeshComponent* StaticMesh11;                                         // 0x0278 (size: 0x8)
    class UStaticMeshComponent* StaticMesh12;                                         // 0x0280 (size: 0x8)
    class UStaticMeshComponent* StaticMesh13;                                         // 0x0288 (size: 0x8)
    class UStaticMeshComponent* StaticMesh14;                                         // 0x0290 (size: 0x8)
    class UStaticMeshComponent* StaticMesh15;                                         // 0x0298 (size: 0x8)
    class UStaticMeshComponent* StaticMesh16;                                         // 0x02A0 (size: 0x8)
    class UStaticMeshComponent* StaticMesh17;                                         // 0x02A8 (size: 0x8)
    class USceneComponent* SharedRoot;                                                // 0x02B0 (size: 0x8)

}; // Size: 0x2B8

#endif
