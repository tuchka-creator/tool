#ifndef UE4SS_SDK_BP_Ladder_HPP
#define UE4SS_SDK_BP_Ladder_HPP

class ABP_Ladder_C : public AInteractableActor
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x0248 (size: 0x8)
    class UStaticMeshComponent* StaticMesh4;                                          // 0x0250 (size: 0x8)
    class UStaticMeshComponent* StaticMesh3;                                          // 0x0258 (size: 0x8)
    class UStaticMeshComponent* StaticMesh2;                                          // 0x0260 (size: 0x8)
    class UStaticMeshComponent* StaticMesh1;                                          // 0x0268 (size: 0x8)
    class UBoxComponent* Box;                                                         // 0x0270 (size: 0x8)
    float ResetControlRotation_Alpha_C45DAAB44C24C2BC6FE4F2B00C8E573C;                // 0x0278 (size: 0x4)
    TEnumAsByte<ETimelineDirection::Type> ResetControlRotation__Direction_C45DAAB44C24C2BC6FE4F2B00C8E573C; // 0x027C (size: 0x1)
    class UTimelineComponent* ResetControlRotation;                                   // 0x0280 (size: 0x8)
    int32 LastLadderCount;                                                            // 0x0288 (size: 0x4)
    int32 UpdateCount;                                                                // 0x028C (size: 0x4)
    class ABP_LadderCamera_C* LadderCamera;                                           // 0x0290 (size: 0x8)

    void OnRep_UpdateCount();
    void RefreshLadders(int32 Count);
    void ResetControlRotation__FinishedFunc();
    void ResetControlRotation__UpdateFunc();
    void OnActorUsed(class ACharacter* Character);
    void MC_Sound();
    void ReceiveBeginPlay();
    void ExecuteUbergraph_BP_Ladder(int32 EntryPoint);
}; // Size: 0x298

#endif
