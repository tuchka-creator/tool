#ifndef UE4SS_SDK_Lobby_Menu_HPP
#define UE4SS_SDK_Lobby_Menu_HPP

class ULobby_Menu_C : public UUserWidget
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x0270 (size: 0x8)
    class ULobby_MapSelection_C* Lobby_MapSelection;                                  // 0x0278 (size: 0x8)
    class ULobby_PlayerList_C* Lobby_PlayerList;                                      // 0x0280 (size: 0x8)
    class UButton* ReadyUpBtn;                                                        // 0x0288 (size: 0x8)
    class UTextBlock* TextBlock_60;                                                   // 0x0290 (size: 0x8)
    class ALobby_GS_C* LobbyGS;                                                       // 0x0298 (size: 0x8)
    class ALobbyPS_C* LobbyPS;                                                        // 0x02A0 (size: 0x8)
    class ALobby_PlayerController_C* LobbyPC;                                         // 0x02A8 (size: 0x8)
    bool IsStarting;                                                                  // 0x02B0 (size: 0x1)
    FString CurrentSave;                                                              // 0x02B8 (size: 0x10)
    TEnumAsByte<E_Difficulty::Type> CurrentDifficulty;                                // 0x02C8 (size: 0x1)

    void Init_ReadyUpButton();
    void Set Ready Up Button(FText Text, bool WarningState?, bool HideButton?, bool LockButton?);
    void Client_Toggle_ReadyUp();
    void Server_Toggle_Launchevent();
    void Init_Client_ReadUpBtn();
    void Init_Server_ReadyUpBtn();
    void Init_Casts();
    void BndEvt__Lobby_Menu_Lobby_MapSelection_K2Node_ComponentBoundEvent_0_OnSwitched_Save__DelegateSignature(FString SaveName);
    void CanClose();
    void BndEvt__Lobby_Menu_ReadyUpBtn_K2Node_ComponentBoundEvent_6_OnButtonClickedEvent__DelegateSignature();
    void Construct();
    void BndEvt__Lobby_Menu_Lobby_MapSelection_K2Node_ComponentBoundEvent_1_OnSwitched_Difficulty__DelegateSignature(TEnumAsByte<E_Difficulty::Type> Difficulty);
    void ExecuteUbergraph_Lobby_Menu(int32 EntryPoint);
}; // Size: 0x2C9

#endif
