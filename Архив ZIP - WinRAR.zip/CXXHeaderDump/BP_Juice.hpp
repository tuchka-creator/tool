#ifndef UE4SS_SDK_BP_Juice_HPP
#define UE4SS_SDK_BP_Juice_HPP

class ABP_Juice_C : public ABP_Item_C
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x0258 (size: 0x8)
    class UStaticMeshComponent* StaticMesh1;                                          // 0x0260 (size: 0x8)
    class UStaticMeshComponent* StaticMesh;                                           // 0x0268 (size: 0x8)
    float Timeline_0_Alpha_4F50821D455C8CB87F6269AF25F4310D;                          // 0x0270 (size: 0x4)
    float Timeline_0_Drink_4F50821D455C8CB87F6269AF25F4310D;                          // 0x0274 (size: 0x4)
    TEnumAsByte<ETimelineDirection::Type> Timeline_0__Direction_4F50821D455C8CB87F6269AF25F4310D; // 0x0278 (size: 0x1)
    class UTimelineComponent* Timeline_0;                                             // 0x0280 (size: 0x8)
    class UMaterialInstanceDynamic* DynamicMaterial;                                  // 0x0288 (size: 0x8)

    void SetMaterial(bool EnabledFOV);
    void Timeline_0__FinishedFunc();
    void Timeline_0__UpdateFunc();
    void OnNotifyEnd_8D6BB16145C244F54B6DA5B60D5650E0(FName NotifyName);
    void OnNotifyBegin_8D6BB16145C244F54B6DA5B60D5650E0(FName NotifyName);
    void OnInterrupted_8D6BB16145C244F54B6DA5B60D5650E0(FName NotifyName);
    void OnBlendOut_8D6BB16145C244F54B6DA5B60D5650E0(FName NotifyName);
    void OnCompleted_8D6BB16145C244F54B6DA5B60D5650E0(FName NotifyName);
    void UseItem();
    void PlayAnimation();
    void SRV_FinishDrink();
    void ReceiveBeginPlay();
    void ExecuteUbergraph_BP_Juice(int32 EntryPoint);
}; // Size: 0x290

#endif
