#ifndef UE4SS_SDK_BP_DroppedItem_Juice_HPP
#define UE4SS_SDK_BP_DroppedItem_Juice_HPP

class ABP_DroppedItem_Juice_C : public ABP_DroppedItem_C
{
    class UStaticMeshComponent* StaticMesh2;                                          // 0x0270 (size: 0x8)
    class UStaticMeshComponent* StaticMesh;                                           // 0x0278 (size: 0x8)

}; // Size: 0x280

#endif
