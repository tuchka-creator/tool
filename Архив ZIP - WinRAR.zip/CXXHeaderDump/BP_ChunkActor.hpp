#ifndef UE4SS_SDK_BP_ChunkActor_HPP
#define UE4SS_SDK_BP_ChunkActor_HPP

class ABP_ChunkActor_C : public AActor
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x0220 (size: 0x8)
    class UStaticMeshComponent* ChunkMesh_Component;                                  // 0x0228 (size: 0x8)
    class USceneComponent* DefaultSceneRoot;                                          // 0x0230 (size: 0x8)
    class UStaticMesh* ChunkMesh;                                                     // 0x0238 (size: 0x8)
    class UMaterialInterface* ChunkMaterial;                                          // 0x0240 (size: 0x8)
    bool NeverSelfDestruct;                                                           // 0x0248 (size: 0x1)
    class UCostume* Costume;                                                          // 0x0250 (size: 0x8)
    ECostumeDismembermentPart DismembermentPart;                                      // 0x0258 (size: 0x1)

    void ReceiveBeginPlay();
    void ExecuteUbergraph_BP_ChunkActor(int32 EntryPoint);
}; // Size: 0x259

#endif
