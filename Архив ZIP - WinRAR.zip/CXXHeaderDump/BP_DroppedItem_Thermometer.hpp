#ifndef UE4SS_SDK_BP_DroppedItem_Thermometer_HPP
#define UE4SS_SDK_BP_DroppedItem_Thermometer_HPP

class ABP_DroppedItem_Thermometer_C : public ABP_DroppedItem_C
{
    class UStaticMeshComponent* StaticMesh1;                                          // 0x0270 (size: 0x8)
    class UStaticMeshComponent* StaticMesh;                                           // 0x0278 (size: 0x8)
    class UStaticMeshComponent* StaticMesh4;                                          // 0x0280 (size: 0x8)
    class UStaticMeshComponent* StaticMesh3;                                          // 0x0288 (size: 0x8)
    class UStaticMeshComponent* StaticMesh2;                                          // 0x0290 (size: 0x8)

}; // Size: 0x298

#endif
