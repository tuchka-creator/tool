#ifndef UE4SS_SDK_BP_Item_PlasticBall_HPP
#define UE4SS_SDK_BP_Item_PlasticBall_HPP

class ABP_Item_PlasticBall_C : public ABP_Item_C
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x0258 (size: 0x8)
    bool CanUse;                                                                      // 0x0260 (size: 0x1)
    TArray<class UMaterialInterface*> BallMaterialArray;                              // 0x0268 (size: 0x10)

    void OnNotifyEnd_3D9D3E014D86EA789E80D5BE8C6A60DF(FName NotifyName);
    void OnNotifyBegin_3D9D3E014D86EA789E80D5BE8C6A60DF(FName NotifyName);
    void OnInterrupted_3D9D3E014D86EA789E80D5BE8C6A60DF(FName NotifyName);
    void OnBlendOut_3D9D3E014D86EA789E80D5BE8C6A60DF(FName NotifyName);
    void OnCompleted_3D9D3E014D86EA789E80D5BE8C6A60DF(FName NotifyName);
    void OnNotifyEnd_50AF23E94A2E16360294B19962EBEFE8(FName NotifyName);
    void OnNotifyBegin_50AF23E94A2E16360294B19962EBEFE8(FName NotifyName);
    void OnInterrupted_50AF23E94A2E16360294B19962EBEFE8(FName NotifyName);
    void OnBlendOut_50AF23E94A2E16360294B19962EBEFE8(FName NotifyName);
    void OnCompleted_50AF23E94A2E16360294B19962EBEFE8(FName NotifyName);
    void UseItem();
    void MC_Throw();
    void ReceiveBeginPlay();
    void ExecuteUbergraph_BP_Item_PlasticBall(int32 EntryPoint);
}; // Size: 0x278

#endif
