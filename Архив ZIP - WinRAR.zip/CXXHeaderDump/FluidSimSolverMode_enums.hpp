namespace FluidSimSolverMode {
    enum Type {
        NewEnumerator0 = 0,
        NewEnumerator1 = 1,
        FluidSimSolverMode_MAX = 2,
    };
}

