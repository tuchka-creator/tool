#ifndef UE4SS_SDK_BP_DroppedItem_Chainsaw_HPP
#define UE4SS_SDK_BP_DroppedItem_Chainsaw_HPP

class ABP_DroppedItem_Chainsaw_C : public ABP_DroppedItem_C
{
    class USkeletalMeshComponent* SkeletalMesh;                                       // 0x0270 (size: 0x8)

}; // Size: 0x278

#endif
