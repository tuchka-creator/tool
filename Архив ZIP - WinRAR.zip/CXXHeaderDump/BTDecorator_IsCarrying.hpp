#ifndef UE4SS_SDK_BTDecorator_IsCarrying_HPP
#define UE4SS_SDK_BTDecorator_IsCarrying_HPP

class UBTDecorator_IsCarrying_C : public UBTDecorator_BlueprintBase
{

    bool PerformConditionCheckAI(class AAIController* OwnerController, class APawn* ControlledPawn);
}; // Size: 0xA0

#endif
