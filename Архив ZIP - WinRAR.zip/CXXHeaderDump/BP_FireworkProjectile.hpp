#ifndef UE4SS_SDK_BP_FireworkProjectile_HPP
#define UE4SS_SDK_BP_FireworkProjectile_HPP

class ABP_FireworkProjectile_C : public AActor
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x0220 (size: 0x8)
    class UNiagaraComponent* Ribbons;                                                 // 0x0228 (size: 0x8)
    class UNiagaraComponent* Confetti;                                                // 0x0230 (size: 0x8)
    class UParticleSystemComponent* P_Destruction_Ceramic;                            // 0x0238 (size: 0x8)
    class UParticleSystemComponent* P_Destruction_Electric;                           // 0x0240 (size: 0x8)
    class UProjectileMovementComponent* ProjectileMovement;                           // 0x0248 (size: 0x8)
    class UStaticMeshComponent* Firework;                                             // 0x0250 (size: 0x8)
    class UNiagaraComponent* Niagara3;                                                // 0x0258 (size: 0x8)
    class UNiagaraComponent* Niagara1;                                                // 0x0260 (size: 0x8)
    float TimeLeft;                                                                   // 0x0268 (size: 0x4)

    void ReceiveBeginPlay();
    void Explode();
    void ReceiveDestroyed();
    void ExecuteUbergraph_BP_FireworkProjectile(int32 EntryPoint);
}; // Size: 0x26C

#endif
