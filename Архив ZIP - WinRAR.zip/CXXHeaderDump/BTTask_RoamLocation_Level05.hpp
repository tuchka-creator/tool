#ifndef UE4SS_SDK_BTTask_RoamLocation_Level05_HPP
#define UE4SS_SDK_BTTask_RoamLocation_Level05_HPP

class UBTTask_RoamLocation_Level05_C : public UBTTask_BlueprintBase
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x00A8 (size: 0x8)
    FBlackboardKeySelector RoamLocation;                                              // 0x00B0 (size: 0x28)

    void ReceiveExecuteAI(class AAIController* OwnerController, class APawn* ControlledPawn);
    void ExecuteUbergraph_BTTask_RoamLocation_Level05(int32 EntryPoint);
}; // Size: 0xD8

#endif
