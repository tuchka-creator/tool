#ifndef UE4SS_SDK_GameEnd_UI_HPP
#define UE4SS_SDK_GameEnd_UI_HPP

class UGameEnd_UI_C : public UUserWidget
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x0270 (size: 0x8)
    class UWidgetAnimation* Fade;                                                     // 0x0278 (size: 0x8)
    class UImage* Image;                                                              // 0x0280 (size: 0x8)
    class UImage* Image_1;                                                            // 0x0288 (size: 0x8)
    float Time;                                                                       // 0x0290 (size: 0x4)
    class UMediaPlayer* MediaPlayer;                                                  // 0x0298 (size: 0x8)
    class UMaterialInstanceDynamic* Mat;                                              // 0x02A0 (size: 0x8)
    class UAudioComponent* Audio;                                                     // 0x02A8 (size: 0x8)

    void CanClose();
    void Construct();
    void OnFinish();
    void ExecuteUbergraph_GameEnd_UI(int32 EntryPoint);
}; // Size: 0x2B0

#endif
