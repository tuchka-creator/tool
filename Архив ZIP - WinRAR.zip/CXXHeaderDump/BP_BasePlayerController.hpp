#ifndef UE4SS_SDK_BP_BasePlayerController_HPP
#define UE4SS_SDK_BP_BasePlayerController_HPP

class ABP_BasePlayerController_C : public AFancyPlayerController
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x05F0 (size: 0x8)
    TArray<FBPUniqueNetId> XSXAdditionalBlockedPlayers;                               // 0x05F8 (size: 0x10)
    bool bXSXCommChecksPerformed;                                                     // 0x0608 (size: 0x1)
    bool bIsVoiceBlockedForLoadingScreen;                                             // 0x0609 (size: 0x1)

    bool IsLocalXBOXOrGDKPlayer();
    void Should Block VOIPAudio for Player(FBPUniqueNetId Player, bool& ShouldBlock);
    void GetPlayerControllerFromPlayerState(class APlayerState* PlayerState, class ABP_BasePlayerController_C*& PlayerController);
    void InpActEvt_SkipVideo_K2Node_InputActionEvent_0(FKey Key);
    void OnFailure_7A38069049F41D425743B08026BC0075(const TArray<FBPUniqueNetId>& Results);
    void OnSuccess_7A38069049F41D425743B08026BC0075(const TArray<FBPUniqueNetId>& Results);
    void OnFailure_25FE2EED481770906869D8BE77840F55(const TArray<FBPUniqueNetId>& Results);
    void OnSuccess_25FE2EED481770906869D8BE77840F55(const TArray<FBPUniqueNetId>& Results);
    void OnFailure_CCA713C34E25CEC47F87468916FB9E32(FFancyGDKCalcCannotCommunicateResult CannotCommunicateWith);
    void OnSuccess_CCA713C34E25CEC47F87468916FB9E32(FFancyGDKCalcCannotCommunicateResult CannotCommunicateWith);
    void UnlockAchievement(FName AchievementName);
    void VoteToSkipVideo();
    void UnlockMission(FName LevelName);
    void FadeOutOnBegin();
    void ClientHUDInit();
    void PrintLevelTimes();
    void StartActivity(FString ActivityName);
    void EndActivity(FString ActivityName, TEnumAsByte<ActivityCompletionStatus> Status);
    void ReceiveEndPlay(TEnumAsByte<EEndPlayReason::Type> EndPlayReason);
    void InitializeRemotePlayerVoice(class APlayerState* NewPlayerState);
    void RemoveRemotePlayerVoice(class APlayerState* PlayerState);
    void InitializeAllRemoteTalkers();
    void UpdatePlayersOnBlockList(const TArray<FBPUniqueNetId>& PlayerBlockList);
    void ServerInitializeRemotePlayerVoice(class APlayerState* TargetPlayerState);
    void ServerRemoveRemoteVoiceForPlayer(class APlayerState* TargetPlayerState);
    void HandleKickedBP();
    void ReceiveBeginPlay();
    void XboxUpdateCommBlocked();
    void EndCurrentActivity(TEnumAsByte<ActivityCompletionStatus> Status);
    void UpdateUsingMultiplayerFeatures(bool bUsingMP);
    void ExecuteUbergraph_BP_BasePlayerController(int32 EntryPoint);
}; // Size: 0x60A

#endif
