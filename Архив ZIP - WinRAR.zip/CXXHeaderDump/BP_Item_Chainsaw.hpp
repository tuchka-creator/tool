#ifndef UE4SS_SDK_BP_Item_Chainsaw_HPP
#define UE4SS_SDK_BP_Item_Chainsaw_HPP

class ABP_Item_Chainsaw_C : public ABP_Item_C
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x0258 (size: 0x8)
    class UParticleSystemComponent* ParticleSystem2;                                  // 0x0260 (size: 0x8)
    class UParticleSystemComponent* ParticleSystem1;                                  // 0x0268 (size: 0x8)
    class UParticleSystemComponent* ParticleSystem;                                   // 0x0270 (size: 0x8)
    class USkeletalMeshComponent* SkeletalMesh1;                                      // 0x0278 (size: 0x8)
    float Recoil_Alpha_9E36E6804B513BC945E146BF4A1663B9;                              // 0x0280 (size: 0x4)
    TEnumAsByte<ETimelineDirection::Type> Recoil__Direction_9E36E6804B513BC945E146BF4A1663B9; // 0x0284 (size: 0x1)
    class UTimelineComponent* Recoil;                                                 // 0x0288 (size: 0x8)
    bool CanUse;                                                                      // 0x0290 (size: 0x1)
    class AChainsaw_BP_C* Chainsaw;                                                   // 0x0298 (size: 0x8)
    class UAudioComponent* Sound;                                                     // 0x02A0 (size: 0x8)
    class UAnimMontage* Montage;                                                      // 0x02A8 (size: 0x8)

    void SetMaterial(bool EnabledFOV);
    void Recoil__FinishedFunc();
    void Recoil__UpdateFunc();
    void OnNotifyEnd_702F9C624045D5D1016E778DEB923CD4(FName NotifyName);
    void OnNotifyBegin_702F9C624045D5D1016E778DEB923CD4(FName NotifyName);
    void OnInterrupted_702F9C624045D5D1016E778DEB923CD4(FName NotifyName);
    void OnBlendOut_702F9C624045D5D1016E778DEB923CD4(FName NotifyName);
    void OnCompleted_702F9C624045D5D1016E778DEB923CD4(FName NotifyName);
    void OnNotifyEnd_FBCA7ED7436A8ED7C154A2B37E6C3659(FName NotifyName);
    void OnNotifyBegin_FBCA7ED7436A8ED7C154A2B37E6C3659(FName NotifyName);
    void OnInterrupted_FBCA7ED7436A8ED7C154A2B37E6C3659(FName NotifyName);
    void OnBlendOut_FBCA7ED7436A8ED7C154A2B37E6C3659(FName NotifyName);
    void OnCompleted_FBCA7ED7436A8ED7C154A2B37E6C3659(FName NotifyName);
    void UseItem();
    void Damage_SERVER(class UObject* Target, class AFancyCharacter* Character);
    void PlayAnimation();
    void OC_Trace();
    void ReceiveDestroyed();
    void ExecuteUbergraph_BP_Item_Chainsaw(int32 EntryPoint);
}; // Size: 0x2B0

#endif
