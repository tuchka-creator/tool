#ifndef UE4SS_SDK_BP_Dummy_Pawn_2_HPP
#define UE4SS_SDK_BP_Dummy_Pawn_2_HPP

class ABP_Dummy_Pawn_2_C : public APawn
{
    class UBoxComponent* Box;                                                         // 0x0280 (size: 0x8)
    class USceneComponent* DefaultSceneRoot;                                          // 0x0288 (size: 0x8)

}; // Size: 0x290

#endif
