#ifndef UE4SS_SDK_BPCharacter_Demo_HPP
#define UE4SS_SDK_BPCharacter_Demo_HPP

class ABPCharacter_Demo_C : public AFancyCharacter
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x0520 (size: 0x8)
    class UFancyPlayerCostumeComponent* FancyPlayerCostume;                           // 0x0528 (size: 0x8)
    class UBP_AimAssistComponent_C* BP_AimAssistComponent;                            // 0x0530 (size: 0x8)
    class UStaticMeshComponent* ItemMesh;                                             // 0x0538 (size: 0x8)
    class UVoipAudioComponent* UnderwaterAudio;                                       // 0x0540 (size: 0x8)
    class UVoipAudioComponent* VoipAudio;                                             // 0x0548 (size: 0x8)
    class UVoipAudioComponent* RadioAudio;                                            // 0x0550 (size: 0x8)
    class UVoipManagerComponent* VoipManager;                                         // 0x0558 (size: 0x8)
    class USceneComponent* Breathing point;                                           // 0x0560 (size: 0x8)
    class UStaticMeshComponent* LocalCard;                                            // 0x0568 (size: 0x8)
    class UTextRenderComponent* Nametag;                                              // 0x0570 (size: 0x8)
    class USkeletalMeshComponent* Legs;                                               // 0x0578 (size: 0x8)
    class UPawnNoiseEmitterComponent* PawnNoiseEmitter;                               // 0x0580 (size: 0x8)
    class USpringArmComponent* FlashlightArm;                                         // 0x0588 (size: 0x8)
    class UPawnSensingComponent* PawnSensing;                                         // 0x0590 (size: 0x8)
    float Timeline_Barrel_Distortion_Chromatic_Distance_EFE87DD74CC1B2DA43B0B389D6CAD9C3; // 0x0598 (size: 0x4)
    float Timeline_Barrel_Distortion_Timestamp_Shift__Vertical__EFE87DD74CC1B2DA43B0B389D6CAD9C3; // 0x059C (size: 0x4)
    float Timeline_Barrel_Distortion_Timestamp_Shift__Horizontal__EFE87DD74CC1B2DA43B0B389D6CAD9C3; // 0x05A0 (size: 0x4)
    float Timeline_Barrel_Distortion_Barrel_Distortion_Toggle_EFE87DD74CC1B2DA43B0B389D6CAD9C3; // 0x05A4 (size: 0x4)
    TEnumAsByte<ETimelineDirection::Type> Timeline_Barrel_Distortion__Direction_EFE87DD74CC1B2DA43B0B389D6CAD9C3; // 0x05A8 (size: 0x1)
    class UTimelineComponent* Timeline Barrel Distortion;                             // 0x05B0 (size: 0x8)
    float Timeline_3_CameraAlpha_D359B8424FCC0E9DEA2152AC8AC4DD3B;                    // 0x05B8 (size: 0x4)
    float Timeline_3_Ringing_D359B8424FCC0E9DEA2152AC8AC4DD3B;                        // 0x05BC (size: 0x4)
    float Timeline_3_Vignette_D359B8424FCC0E9DEA2152AC8AC4DD3B;                       // 0x05C0 (size: 0x4)
    float Timeline_3_EyeOpen_D359B8424FCC0E9DEA2152AC8AC4DD3B;                        // 0x05C4 (size: 0x4)
    TEnumAsByte<ETimelineDirection::Type> Timeline_3__Direction_D359B8424FCC0E9DEA2152AC8AC4DD3B; // 0x05C8 (size: 0x1)
    class UTimelineComponent* Timeline_3;                                             // 0x05D0 (size: 0x8)
    float Timeline_8_Alpha_DB15FA3D4A9AE3B557E4B5B1F0F6478E;                          // 0x05D8 (size: 0x4)
    TEnumAsByte<ETimelineDirection::Type> Timeline_8__Direction_DB15FA3D4A9AE3B557E4B5B1F0F6478E; // 0x05DC (size: 0x1)
    class UTimelineComponent* Timeline_8;                                             // 0x05E0 (size: 0x8)
    float Timeline_6_Alpha2_62A7627648056028525FB698DBF1EA3C;                         // 0x05E8 (size: 0x4)
    float Timeline_6_Alpha_62A7627648056028525FB698DBF1EA3C;                          // 0x05EC (size: 0x4)
    TEnumAsByte<ETimelineDirection::Type> Timeline_6__Direction_62A7627648056028525FB698DBF1EA3C; // 0x05F0 (size: 0x1)
    class UTimelineComponent* Timeline_6;                                             // 0x05F8 (size: 0x8)
    float Climb_Alpha_E0CFA5344DE67FA6AC76729151B1267F;                               // 0x0600 (size: 0x4)
    TEnumAsByte<ETimelineDirection::Type> Climb__Direction_E0CFA5344DE67FA6AC76729151B1267F; // 0x0604 (size: 0x1)
    class UTimelineComponent* Climb;                                                  // 0x0608 (size: 0x8)
    float MoveToLadder_Alpha_183D3287481A20589013F7AA5BD36722;                        // 0x0610 (size: 0x4)
    TEnumAsByte<ETimelineDirection::Type> MoveToLadder__Direction_183D3287481A20589013F7AA5BD36722; // 0x0614 (size: 0x1)
    class UTimelineComponent* MoveToLadder;                                           // 0x0618 (size: 0x8)
    float Timeline_7_Alpha2_1CC57C5E48A7286B7D1AA6881A61D32E;                         // 0x0620 (size: 0x4)
    float Timeline_7_Alpha_1CC57C5E48A7286B7D1AA6881A61D32E;                          // 0x0624 (size: 0x4)
    TEnumAsByte<ETimelineDirection::Type> Timeline_7__Direction_1CC57C5E48A7286B7D1AA6881A61D32E; // 0x0628 (size: 0x1)
    class UTimelineComponent* Timeline_7;                                             // 0x0630 (size: 0x8)
    float Plague_Ringing_40AECF8645A31E151684E48FF9C927C5;                            // 0x0638 (size: 0x4)
    float Plague_Vignette_40AECF8645A31E151684E48FF9C927C5;                           // 0x063C (size: 0x4)
    float Plague_EyeOpen_40AECF8645A31E151684E48FF9C927C5;                            // 0x0640 (size: 0x4)
    TEnumAsByte<ETimelineDirection::Type> Plague__Direction_40AECF8645A31E151684E48FF9C927C5; // 0x0644 (size: 0x1)
    class UTimelineComponent* Plague;                                                 // 0x0648 (size: 0x8)
    float Bob_Buoyancy_C74565444B6ED2300150BBA0C909B04A;                              // 0x0650 (size: 0x4)
    TEnumAsByte<ETimelineDirection::Type> Bob__Direction_C74565444B6ED2300150BBA0C909B04A; // 0x0654 (size: 0x1)
    class UTimelineComponent* Bob;                                                    // 0x0658 (size: 0x8)
    float NoClipFall_Alpha_F1E50F3342F23ADFA8A23BA6A9BFFDB6;                          // 0x0660 (size: 0x4)
    TEnumAsByte<ETimelineDirection::Type> NoClipFall__Direction_F1E50F3342F23ADFA8A23BA6A9BFFDB6; // 0x0664 (size: 0x1)
    class UTimelineComponent* NoClipFall;                                             // 0x0668 (size: 0x8)
    float Timeline_5_Fade3_19180EAC4BD70296B2F1DEB47E219483;                          // 0x0670 (size: 0x4)
    float Timeline_5_Fade2_19180EAC4BD70296B2F1DEB47E219483;                          // 0x0674 (size: 0x4)
    float Timeline_5_Fade_19180EAC4BD70296B2F1DEB47E219483;                           // 0x0678 (size: 0x4)
    float Timeline_5_EyeOpen_19180EAC4BD70296B2F1DEB47E219483;                        // 0x067C (size: 0x4)
    TEnumAsByte<ETimelineDirection::Type> Timeline_5__Direction_19180EAC4BD70296B2F1DEB47E219483; // 0x0680 (size: 0x1)
    class UTimelineComponent* Timeline_5;                                             // 0x0688 (size: 0x8)
    float Timeline_4_EyeOpen_20BF1E9A4227EABC75504A815F7E9013;                        // 0x0690 (size: 0x4)
    TEnumAsByte<ETimelineDirection::Type> Timeline_4__Direction_20BF1E9A4227EABC75504A815F7E9013; // 0x0694 (size: 0x1)
    class UTimelineComponent* Timeline_4;                                             // 0x0698 (size: 0x8)
    float Timeline_2_Vignette_CA38DEFF4E786FAC5BE4A286FEC0ED8C;                       // 0x06A0 (size: 0x4)
    float Timeline_2_EyeOpen_CA38DEFF4E786FAC5BE4A286FEC0ED8C;                        // 0x06A4 (size: 0x4)
    TEnumAsByte<ETimelineDirection::Type> Timeline_2__Direction_CA38DEFF4E786FAC5BE4A286FEC0ED8C; // 0x06A8 (size: 0x1)
    class UTimelineComponent* Timeline_2;                                             // 0x06B0 (size: 0x8)
    float LiquidPainEffects_Vignette_5817604E42528FA6E8B5BBA1AE0C0946;                // 0x06B8 (size: 0x4)
    float LiquidPainEffects_Bluriness_5817604E42528FA6E8B5BBA1AE0C0946;               // 0x06BC (size: 0x4)
    TEnumAsByte<ETimelineDirection::Type> LiquidPainEffects__Direction_5817604E42528FA6E8B5BBA1AE0C0946; // 0x06C0 (size: 0x1)
    class UTimelineComponent* LiquidPainEffects;                                      // 0x06C8 (size: 0x8)
    float Timeline_1_Alpha_9194A2554724E66565442A99606505D1;                          // 0x06D0 (size: 0x4)
    TEnumAsByte<ETimelineDirection::Type> Timeline_1__Direction_9194A2554724E66565442A99606505D1; // 0x06D4 (size: 0x1)
    class UTimelineComponent* Timeline_1;                                             // 0x06D8 (size: 0x8)
    float Sanity_ChromaticAberration_D2366F7145761D954DA5E3AF1C29E6FE;                // 0x06E0 (size: 0x4)
    float Sanity_Flare_D2366F7145761D954DA5E3AF1C29E6FE;                              // 0x06E4 (size: 0x4)
    TEnumAsByte<ETimelineDirection::Type> Sanity__Direction_D2366F7145761D954DA5E3AF1C29E6FE; // 0x06E8 (size: 0x1)
    class UTimelineComponent* Sanity;                                                 // 0x06F0 (size: 0x8)
    float FearTimeline_Animation_09874B8E4CDABC74471DA18DDE3F4BF1;                    // 0x06F8 (size: 0x4)
    TEnumAsByte<ETimelineDirection::Type> FearTimeline__Direction_09874B8E4CDABC74471DA18DDE3F4BF1; // 0x06FC (size: 0x1)
    class UTimelineComponent* FearTimeline;                                           // 0x0700 (size: 0x8)
    float BalanceFallTimeline_Rotation_B88008094E1559D6D2498B81EDC83E10;              // 0x0708 (size: 0x4)
    TEnumAsByte<ETimelineDirection::Type> BalanceFallTimeline__Direction_B88008094E1559D6D2498B81EDC83E10; // 0x070C (size: 0x1)
    class UTimelineComponent* BalanceFallTimeline;                                    // 0x0710 (size: 0x8)
    float BalanceTimeline_Rotation_A00783314A9B792244AF63BFF4BCC63A;                  // 0x0718 (size: 0x4)
    TEnumAsByte<ETimelineDirection::Type> BalanceTimeline__Direction_A00783314A9B792244AF63BFF4BCC63A; // 0x071C (size: 0x1)
    class UTimelineComponent* BalanceTimeline;                                        // 0x0720 (size: 0x8)
    float Crouch2_Scale_84DBE3CB40EB8DCD6709CDA38F0F9644;                             // 0x0728 (size: 0x4)
    float Crouch2_Z_84DBE3CB40EB8DCD6709CDA38F0F9644;                                 // 0x072C (size: 0x4)
    TEnumAsByte<ETimelineDirection::Type> Crouch2__Direction_84DBE3CB40EB8DCD6709CDA38F0F9644; // 0x0730 (size: 0x1)
    class UTimelineComponent* Crouch2;                                                // 0x0738 (size: 0x8)
    float Timeline_0_Horizontal_Offset_Frequency_75C3403D4BC3CFC45C5EBBBD45191750;    // 0x0740 (size: 0x4)
    float Timeline_0_ScreenHopFrequency_75C3403D4BC3CFC45C5EBBBD45191750;             // 0x0744 (size: 0x4)
    float Timeline_0_WarpBeltIntensity_75C3403D4BC3CFC45C5EBBBD45191750;              // 0x0748 (size: 0x4)
    float Timeline_0_ColorTornadoIntensity_75C3403D4BC3CFC45C5EBBBD45191750;          // 0x074C (size: 0x4)
    float Timeline_0_Signal_Distortion_Intensity_75C3403D4BC3CFC45C5EBBBD45191750;    // 0x0750 (size: 0x4)
    float Timeline_0_Tracking_Noise_Level_75C3403D4BC3CFC45C5EBBBD45191750;           // 0x0754 (size: 0x4)
    float Timeline_0_Chromatic_Distance_75C3403D4BC3CFC45C5EBBBD45191750;             // 0x0758 (size: 0x4)
    TEnumAsByte<ETimelineDirection::Type> Timeline_0__Direction_75C3403D4BC3CFC45C5EBBBD45191750; // 0x075C (size: 0x1)
    class UTimelineComponent* Timeline_0;                                             // 0x0760 (size: 0x8)
    float BrightnessTimeline_Screen_Brightness_D6E81A0341FBFEAD972B919617750DAD;      // 0x0768 (size: 0x4)
    TEnumAsByte<ETimelineDirection::Type> BrightnessTimeline__Direction_D6E81A0341FBFEAD972B919617750DAD; // 0x076C (size: 0x1)
    class UTimelineComponent* BrightnessTimeline;                                     // 0x0770 (size: 0x8)
    float FallTimeline_Roll_BAADBFCD450D5B6EFCED20A817513817;                         // 0x0778 (size: 0x4)
    float FallTimeline_Z_BAADBFCD450D5B6EFCED20A817513817;                            // 0x077C (size: 0x4)
    TEnumAsByte<ETimelineDirection::Type> FallTimeline__Direction_BAADBFCD450D5B6EFCED20A817513817; // 0x0780 (size: 0x1)
    class UTimelineComponent* FallTimeline;                                           // 0x0788 (size: 0x8)
    float InsanityTimeline_Random_Horizontal_Offset_Strength_02BB79164A751B3E27114BA6D8F61BB1; // 0x0790 (size: 0x4)
    float InsanityTimeline_Screen_Hop_Intensity_02BB79164A751B3E27114BA6D8F61BB1;     // 0x0794 (size: 0x4)
    float InsanityTimeline_Random_Horizontal_Offset_Frequency_02BB79164A751B3E27114BA6D8F61BB1; // 0x0798 (size: 0x4)
    float InsanityTimeline_ScreenHopFrequency_02BB79164A751B3E27114BA6D8F61BB1;       // 0x079C (size: 0x4)
    float InsanityTimeline_WarpBeltIntensity_02BB79164A751B3E27114BA6D8F61BB1;        // 0x07A0 (size: 0x4)
    float InsanityTimeline_ColorTornadoIntensity_02BB79164A751B3E27114BA6D8F61BB1;    // 0x07A4 (size: 0x4)
    float InsanityTimeline_Signal_Distortion_Intensity_02BB79164A751B3E27114BA6D8F61BB1; // 0x07A8 (size: 0x4)
    float InsanityTimeline_Tracking_Noise_Level_02BB79164A751B3E27114BA6D8F61BB1;     // 0x07AC (size: 0x4)
    float InsanityTimeline_Chromatic_Distance_02BB79164A751B3E27114BA6D8F61BB1;       // 0x07B0 (size: 0x4)
    TEnumAsByte<ETimelineDirection::Type> InsanityTimeline__Direction_02BB79164A751B3E27114BA6D8F61BB1; // 0x07B4 (size: 0x1)
    class UTimelineComponent* InsanityTimeline;                                       // 0x07B8 (size: 0x8)
    TEnumAsByte<ETimelineDirection::Type> KeepLookingTimeline__Direction_FB05A2E74D6D30EC780AFAB334E0BBA6; // 0x07C0 (size: 0x1)
    class UTimelineComponent* KeepLookingTimeline;                                    // 0x07C8 (size: 0x8)
    float TurnToActorTimeline_Smooth_EF6BC6224E4DC04E93E645995648410A;                // 0x07D0 (size: 0x4)
    float TurnToActorTimeline_Direct_EF6BC6224E4DC04E93E645995648410A;                // 0x07D4 (size: 0x4)
    TEnumAsByte<ETimelineDirection::Type> TurnToActorTimeline__Direction_EF6BC6224E4DC04E93E645995648410A; // 0x07D8 (size: 0x1)
    class UTimelineComponent* TurnToActorTimeline;                                    // 0x07E0 (size: 0x8)
    TEnumAsByte<ETimelineDirection::Type> KeepLookingLocationTimeline__Direction_1ECA7B3F4E58B8832CFBB9ACFC1482B3; // 0x07E8 (size: 0x1)
    class UTimelineComponent* KeepLookingLocationTimeline;                            // 0x07F0 (size: 0x8)
    float TurnToLocationTimeline_Smooth_F6DCA4994E9C428E02C3D09CD16816C9;             // 0x07F8 (size: 0x4)
    float TurnToLocationTimeline_Direct_F6DCA4994E9C428E02C3D09CD16816C9;             // 0x07FC (size: 0x4)
    TEnumAsByte<ETimelineDirection::Type> TurnToLocationTimeline__Direction_F6DCA4994E9C428E02C3D09CD16816C9; // 0x0800 (size: 0x1)
    class UTimelineComponent* TurnToLocationTimeline;                                 // 0x0808 (size: 0x8)
    float StaticTimeline_Random_Horizontal_Offset_Strength_B8D8B0924468125070F534B82FEED15A; // 0x0810 (size: 0x4)
    float StaticTimeline_Screen_Hop_Intensity_B8D8B0924468125070F534B82FEED15A;       // 0x0814 (size: 0x4)
    float StaticTimeline_Random_Horizontal_Offset_Frequency_B8D8B0924468125070F534B82FEED15A; // 0x0818 (size: 0x4)
    float StaticTimeline_ScreenHopFrequency_B8D8B0924468125070F534B82FEED15A;         // 0x081C (size: 0x4)
    float StaticTimeline_WarpBeltIntensity_B8D8B0924468125070F534B82FEED15A;          // 0x0820 (size: 0x4)
    float StaticTimeline_ColorTornadoIntensity_B8D8B0924468125070F534B82FEED15A;      // 0x0824 (size: 0x4)
    float StaticTimeline_Signal_Distortion_Intensity_B8D8B0924468125070F534B82FEED15A; // 0x0828 (size: 0x4)
    float StaticTimeline_Tracking_Noise_Level_B8D8B0924468125070F534B82FEED15A;       // 0x082C (size: 0x4)
    float StaticTimeline_Chromatic_Distance_B8D8B0924468125070F534B82FEED15A;         // 0x0830 (size: 0x4)
    TEnumAsByte<ETimelineDirection::Type> StaticTimeline__Direction_B8D8B0924468125070F534B82FEED15A; // 0x0834 (size: 0x1)
    class UTimelineComponent* StaticTimeline;                                         // 0x0838 (size: 0x8)
    float LeanRight_Offset_C47E33074D47E917512F4F8517EDDA78;                          // 0x0840 (size: 0x4)
    float LeanRight_Rotation_C47E33074D47E917512F4F8517EDDA78;                        // 0x0844 (size: 0x4)
    TEnumAsByte<ETimelineDirection::Type> LeanRight__Direction_C47E33074D47E917512F4F8517EDDA78; // 0x0848 (size: 0x1)
    class UTimelineComponent* LeanRight;                                              // 0x0850 (size: 0x8)
    float LeanLeft_Offset_17DE22D544C8BED35C8F5881C0002D9E;                           // 0x0858 (size: 0x4)
    float LeanLeft_Rotation_17DE22D544C8BED35C8F5881C0002D9E;                         // 0x085C (size: 0x4)
    TEnumAsByte<ETimelineDirection::Type> LeanLeft__Direction_17DE22D544C8BED35C8F5881C0002D9E; // 0x0860 (size: 0x1)
    class UTimelineComponent* LeanLeft;                                               // 0x0868 (size: 0x8)
    float MouseSensitivity;                                                           // 0x0870 (size: 0x4)
    bool IsDead;                                                                      // 0x0874 (size: 0x1)
    bool IsSprinting;                                                                 // 0x0875 (size: 0x1)
    float Stamina;                                                                    // 0x0878 (size: 0x4)
    float MaxStamina;                                                                 // 0x087C (size: 0x4)
    bool IsBurnedOut;                                                                 // 0x0880 (size: 0x1)
    bool ShouldUseStamina;                                                            // 0x0881 (size: 0x1)
    class UMaterialInstanceDynamic* PP_VCR;                                           // 0x0888 (size: 0x8)
    bool HasSeenEntity;                                                               // 0x0890 (size: 0x1)
    float CurrentFOV;                                                                 // 0x0894 (size: 0x4)
    class UGameEnd_UI_2_C* GameEndUI;                                                 // 0x0898 (size: 0x8)
    FVector LastFootLocation;                                                         // 0x08A0 (size: 0xC)
    FHorrorEngineSettings GameSettings;                                               // 0x08B0 (size: 0xA0)
    float StepSize;                                                                   // 0x0950 (size: 0x4)
    int32 LookAtActorSequenceCounter;                                                 // 0x0954 (size: 0x4)
    FRotator PlayerCurrentRotation;                                                   // 0x0958 (size: 0xC)
    bool Looking;                                                                     // 0x0964 (size: 0x1)
    bool IsFlashlightOn;                                                              // 0x0965 (size: 0x1)
    float Pitch;                                                                      // 0x0968 (size: 0x4)
    bool CanKill;                                                                     // 0x096C (size: 0x1)
    class UAudioComponent* StaticSound;                                               // 0x0970 (size: 0x8)
    bool DidJumpscare;                                                                // 0x0978 (size: 0x1)
    bool CanJumpscare;                                                                // 0x0979 (size: 0x1)
    bool IsPossessed;                                                                 // 0x097A (size: 0x1)
    bool ShouldLongCrouch;                                                            // 0x097B (size: 0x1)
    float StandingHeight;                                                             // 0x097C (size: 0x4)
    float CrouchAmount;                                                               // 0x0980 (size: 0x4)
    bool IsVOIPActivated?;                                                            // 0x0984 (size: 0x1)
    float WalkSpeed;                                                                  // 0x0988 (size: 0x4)
    float SprintSpeed;                                                                // 0x098C (size: 0x4)
    float StaminaToAdd;                                                               // 0x0990 (size: 0x4)
    bool ShouldScaleCrouch;                                                           // 0x0994 (size: 0x1)
    float LegsOffset;                                                                 // 0x0998 (size: 0x4)
    bool ShouldPlayVoiceSound;                                                        // 0x099C (size: 0x1)
    TEnumAsByte<E_CameraSetting::Type> VHSSetting;                                    // 0x099D (size: 0x1)
    bool InvertMouseY;                                                                // 0x099E (size: 0x1)
    bool ShowBody;                                                                    // 0x099F (size: 0x1)
    FLinearColor Color;                                                               // 0x09A0 (size: 0x10)
    class UInGame_UI_C* InGameUI;                                                     // 0x09B0 (size: 0x8)
    TArray<FWeightedBlendable> WeightedBlendables;                                    // 0x09B8 (size: 0x10)
    bool IsBalancing;                                                                 // 0x09C8 (size: 0x1)
    bool IsBalancingRight;                                                            // 0x09C9 (size: 0x1)
    bool IsFallingBalance;                                                            // 0x09CA (size: 0x1)
    class UAudioComponent* HeartbeatSound;                                            // 0x09D0 (size: 0x8)
    class UAudioComponent* WhisperSound;                                              // 0x09D8 (size: 0x8)
    class UObject* InspectUI;                                                         // 0x09E0 (size: 0x8)
    class ABP_Card_C* Card;                                                           // 0x09E8 (size: 0x8)
    bool PlayFootsteps;                                                               // 0x09F0 (size: 0x1)
    bool IsClimbing;                                                                  // 0x09F1 (size: 0x1)
    int32 CurrentEquipSlot;                                                           // 0x09F4 (size: 0x4)
    class ABP_Item_C* CurrentItem_Rep;                                                // 0x09F8 (size: 0x8)
    bool IsLiDAROn;                                                                   // 0x0A00 (size: 0x1)
    bool IsHoldingRope;                                                               // 0x0A01 (size: 0x1)
    class UAudioComponent* SanityWarnSound;                                           // 0x0A08 (size: 0x8)
    class UMaterialInstanceDynamic* PP_Blinking;                                      // 0x0A10 (size: 0x8)
    class UNiagaraComponent* SanitySystem;                                            // 0x0A18 (size: 0x8)
    bool IsMotionScanner;                                                             // 0x0A20 (size: 0x1)
    bool CanTalk;                                                                     // 0x0A21 (size: 0x1)
    bool UsingPushToTalk;                                                             // 0x0A22 (size: 0x1)
    int32 FOV;                                                                        // 0x0A24 (size: 0x4)
    FName CurrentHound;                                                               // 0x0A28 (size: 0x8)
    bool SmoothRotation;                                                              // 0x0A30 (size: 0x1)
    class USkeletalMeshComponent* SwimmingArms;                                       // 0x0A38 (size: 0x8)
    class USpringArmComponent* SwimmingSpring;                                        // 0x0A40 (size: 0x8)
    bool PlaySwimmingArms;                                                            // 0x0A48 (size: 0x1)
    class UMaterialInstanceDynamic* PP_Helmet;                                        // 0x0A50 (size: 0x8)
    class UMaterialInstanceDynamic* PP_Helmet_Blur;                                   // 0x0A58 (size: 0x8)
    bool HasDivingHelmet;                                                             // 0x0A60 (size: 0x1)
    class ABP_DivingHelmet_C* DivingHelmet;                                           // 0x0A68 (size: 0x8)
    bool HasWaterPhysics;                                                             // 0x0A70 (size: 0x1)
    float NoClipStart;                                                                // 0x0A74 (size: 0x4)
    bool InDivingCage;                                                                // 0x0A78 (size: 0x1)
    bool IsClimbingLadder;                                                            // 0x0A79 (size: 0x1)
    bool IsUsingRadio;                                                                // 0x0A7A (size: 0x1)
    bool IsPushingToTalk;                                                             // 0x0A7B (size: 0x1)
    class UW_VOIPInGame_C* W_VOIPHUDRef;                                              // 0x0A80 (size: 0x8)
    bool LoopbackVoice;                                                               // 0x0A88 (size: 0x1)
    bool IsAffectingWheat;                                                            // 0x0A89 (size: 0x1)
    bool ShouldSink;                                                                  // 0x0A8A (size: 0x1)
    bool PlayLandedSound;                                                             // 0x0A8B (size: 0x1)
    bool PA_Anims;                                                                    // 0x0A8C (size: 0x1)
    class ABP_Pushable_C* CurrentPushableActor_0;                                     // 0x0A90 (size: 0x8)
    FVector PA_CurrentLoc;                                                            // 0x0A98 (size: 0xC)
    FVector PA_TargetLoc;                                                             // 0x0AA4 (size: 0xC)
    FRotator PA_CurrentRot;                                                           // 0x0AB0 (size: 0xC)
    FRotator PA_TargetRot;                                                            // 0x0ABC (size: 0xC)
    bool PA_NoObstaclesF;                                                             // 0x0AC8 (size: 0x1)
    bool PA_NoObstaclesR;                                                             // 0x0AC9 (size: 0x1)
    class UAudioComponent* HydroSound;                                                // 0x0AD0 (size: 0x8)
    bool HasFallDamage;                                                               // 0x0AD8 (size: 0x1)
    bool IsPushing;                                                                   // 0x0AD9 (size: 0x1)
    float FlashlightCheckLength;                                                      // 0x0ADC (size: 0x4)
    bool CanPush;                                                                     // 0x0AE0 (size: 0x1)
    FVector CurrentLadderLocation;                                                    // 0x0AE4 (size: 0xC)
    FRotator CurrentLadderRotation;                                                   // 0x0AF0 (size: 0xC)
    class ABP_Pool_Ladder_C* CurrentLadder;                                           // 0x0B00 (size: 0x8)
    bool CanTurn;                                                                     // 0x0B08 (size: 0x1)
    bool ShouldRagdoll;                                                               // 0x0B09 (size: 0x1)
    bool ShowCamera;                                                                  // 0x0B0A (size: 0x1)
    bool CanJumpElevator;                                                             // 0x0B0B (size: 0x1)
    bool IsUsingFlaregun;                                                             // 0x0B0C (size: 0x1)
    TEnumAsByte<E_GlowstickColor::Type> IsHoldingGlowstick;                           // 0x0B0D (size: 0x1)
    float CrouchWalkSpeed;                                                            // 0x0B10 (size: 0x4)
    bool IsTangled;                                                                   // 0x0B14 (size: 0x1)
    float ControllerSensitivity;                                                      // 0x0B18 (size: 0x4)
    class UVOIPTalker* PlayerTalker;                                                  // 0x0B20 (size: 0x8)
    bool ControllerFeedback;                                                          // 0x0B28 (size: 0x1)
    bool WantsToCrouchAfterLanding;                                                   // 0x0B29 (size: 0x1)
    bool IsUsingGamepad;                                                              // 0x0B2A (size: 0x1)
    class UCostume* Costume;                                                          // 0x0B30 (size: 0x8)
    bool bRenderClarityBoostEnabled;                                                  // 0x0B38 (size: 0x1)
    int32 OriginalDLSSQuality;                                                        // 0x0B3C (size: 0x4)
    float OriginalSecondaryScreenPercentage;                                          // 0x0B40 (size: 0x4)
    bool HasBeenKilled;                                                               // 0x0B44 (size: 0x1)

    void SendPlayerDeathTelemetryEvent(FString DeathCause);
    void GetOppositeOffset(TArray<class AActor*>& Actors, float OffsetLength, FVector& OffsetDirection);
    void GetPawnsAtLocation(bool& FoundActors, TArray<class AActor*>& OverlappedActors);
    void Toggle Render Clarity Boost(bool bEnable);
    void OnRep_Card();
    void ClampMovement(float In, float& Clamped);
    void OnRep_ShouldUseStamina();
    void PlayRumble(class UForceFeedbackEffect* Rumble);
    void DestroySpawnedItems();
    bool CanOpenUI();
    void CheckGamepadPushableActorExit();
    void OnRep_CrouchWalkSpeed();
    void OnRep_IsHoldingGlowstick();
    void OnRep_IsUsingFlaregun();
    bool CanLookAround();
    void OnRep_ShowCamera();
    void OnRep_IsAffectingWheat();
    void OnRep_HasDivingHelmet();
    void OnRep_HasWaterPhysics();
    void TeleportWater(TArray<FVector>& Locations);
    void ShowSwimmingArms();
    void ArmSwimming(bool Swimming);
    void CheckStopCrouchMovementInput();
    void CheckCrouchMovementInput();
    void CheckStopJumpMovementInput();
    void CheckJumpMovementInput();
    void CheckForwardMovementInput(float Input, FVector Direction);
    void OnRep_CurrentItem_Rep();
    void ToggleFOV(int32 FOV);
    void TogglePushToTalk(bool UsingPushToTalk);
    void OnRep_IsMotionScanner();
    void SetLiquidPain(float Bluriness, float Vignette);
    void InvItemCount(int32& ItemCount);
    void InvCheckItem();
    void OnRep_IsHoldingRope();
    void OnRep_IsLiDAROn();
    void InvAddByName(FName ItemName);
    void InvRemoveCurrent(bool ShouldDrop);
    void InvFindFreeSlot(int32& Array Index, bool& Found);
    void InvAdd(class ADroppedItem* DroppedItem);
    void InvRemove(int32 Index);
    void InvSwap(int32 Index1, int32 Index2);
    void InvMove(int32 Index1, int32 Index2);
    void CanAction(bool& Variable);
    void ToggleInventory(bool Visible);
    void CheckFlashlight();
    void Create Whisper Sound();
    void ToggleInteractText(FText Text);
    void ToggleCrosshair(bool IsVisible);
    void OnRep_Color();
    void ToggleBody(bool IsActivated);
    void ToggleVHS();
    void CheckLegsOffset();
    void GetBurnoutDuration(float& Delay);
    void ShowTime();
    void HideTime();
    void ClearScreen();
    void OnRep_SprintSpeed();
    void OnRep_WalkSpeed();
    void ClearWidgets();
    void OnRep_IsPossessed();
    void CanSprint(bool& CanSprint);
    void OnRep_IsDead();
    void Create Static Sound();
    void CheckStamina();
    void OnRep_IsFlashlightOn();
    void Set Input(bool Enabled);
    void StopSprint(bool ShouldStop);
    void StartSprint();
    void Footstep/Headshake(TEnumAsByte<FootstepActionsEnum::Type> FootstepType);
    void ToggleFlashlight();
    void Toggle Post Processing(bool Activated);
    void SetPostProcessing(float Chromatic Distance, float Tracking Noise Level, float Signal Distortion Intensity, float Color Tornado Intensity, float Warp Belt Intensity, float Screen Hop Frequency, float Random Horizontal Offset Frequency, float Screen Hop Intensity, float Random Horizontal Offset Strength);
    void HasRoom(float Distance, bool& CanLean);
    void RemoveStamina();
    void AddStamina();
    void UserConstructionScript();
    void MoveToLadder__FinishedFunc();
    void MoveToLadder__UpdateFunc();
    void Timeline_7__FinishedFunc();
    void Timeline_7__UpdateFunc();
    void Climb__FinishedFunc();
    void Climb__UpdateFunc();
    void Timeline_6__FinishedFunc();
    void Timeline_6__UpdateFunc();
    void Timeline_8__FinishedFunc();
    void Timeline_8__UpdateFunc();
    void Timeline_0__FinishedFunc();
    void Timeline_0__UpdateFunc();
    void BrightnessTimeline__FinishedFunc();
    void BrightnessTimeline__UpdateFunc();
    void FallTimeline__FinishedFunc();
    void FallTimeline__UpdateFunc();
    void InsanityTimeline__FinishedFunc();
    void InsanityTimeline__UpdateFunc();
    void TurnToLocationTimeline__FinishedFunc();
    void TurnToLocationTimeline__UpdateFunc();
    void KeepLookingLocationTimeline__FinishedFunc();
    void KeepLookingLocationTimeline__UpdateFunc();
    void TurnToActorTimeline__FinishedFunc();
    void TurnToActorTimeline__UpdateFunc();
    void KeepLookingTimeline__FinishedFunc();
    void KeepLookingTimeline__UpdateFunc();
    void FearTimeline__FinishedFunc();
    void FearTimeline__UpdateFunc();
    void Sanity__FinishedFunc();
    void Sanity__UpdateFunc();
    void LiquidPainEffects__FinishedFunc();
    void LiquidPainEffects__UpdateFunc();
    void LiquidPainEffects__Kill__EventFunc();
    void Timeline_2__FinishedFunc();
    void Timeline_2__UpdateFunc();
    void Timeline_2__Halfway__EventFunc();
    void Timeline_4__FinishedFunc();
    void Timeline_4__UpdateFunc();
    void Timeline_4__Closed__EventFunc();
    void Timeline_5__FinishedFunc();
    void Timeline_5__UpdateFunc();
    void Timeline_5__Closed__EventFunc();
    void NoClipFall__FinishedFunc();
    void NoClipFall__UpdateFunc();
    void Plague__FinishedFunc();
    void Plague__UpdateFunc();
    void Plague__Breath__EventFunc();
    void Timeline_3__FinishedFunc();
    void Timeline_3__UpdateFunc();
    void Timeline_3__CameraAttach__EventFunc();
    void Timeline_3__Breath__EventFunc();
    void Timeline_1__FinishedFunc();
    void Timeline_1__UpdateFunc();
    void LeanLeft__FinishedFunc();
    void LeanLeft__UpdateFunc();
    void LeanRight__FinishedFunc();
    void LeanRight__UpdateFunc();
    void StaticTimeline__FinishedFunc();
    void StaticTimeline__UpdateFunc();
    void Crouch2__FinishedFunc();
    void Crouch2__UpdateFunc();
    void BalanceTimeline__FinishedFunc();
    void BalanceTimeline__UpdateFunc();
    void BalanceFallTimeline__FinishedFunc();
    void BalanceFallTimeline__UpdateFunc();
    void Bob__FinishedFunc();
    void Bob__UpdateFunc();
    void Timeline Barrel Distortion__FinishedFunc();
    void Timeline Barrel Distortion__UpdateFunc();
    void OnNotifyEnd_5F0718B741225A4F928EAFA37DEBB424(FName NotifyName);
    void OnNotifyBegin_5F0718B741225A4F928EAFA37DEBB424(FName NotifyName);
    void OnInterrupted_5F0718B741225A4F928EAFA37DEBB424(FName NotifyName);
    void OnBlendOut_5F0718B741225A4F928EAFA37DEBB424(FName NotifyName);
    void OnCompleted_5F0718B741225A4F928EAFA37DEBB424(FName NotifyName);
    void OnNotifyEnd_70F3CD7E4920E00B15625A85BC07DB8D(FName NotifyName);
    void OnNotifyBegin_70F3CD7E4920E00B15625A85BC07DB8D(FName NotifyName);
    void OnInterrupted_70F3CD7E4920E00B15625A85BC07DB8D(FName NotifyName);
    void OnBlendOut_70F3CD7E4920E00B15625A85BC07DB8D(FName NotifyName);
    void OnCompleted_70F3CD7E4920E00B15625A85BC07DB8D(FName NotifyName);
    void OnNotifyEnd_51A4DCE148BC0C00149B8794698E33F5(FName NotifyName);
    void OnNotifyBegin_51A4DCE148BC0C00149B8794698E33F5(FName NotifyName);
    void OnInterrupted_51A4DCE148BC0C00149B8794698E33F5(FName NotifyName);
    void OnBlendOut_51A4DCE148BC0C00149B8794698E33F5(FName NotifyName);
    void OnCompleted_51A4DCE148BC0C00149B8794698E33F5(FName NotifyName);
    void InpActEvt_ItemSlot1_K2Node_InputActionEvent_15(FKey Key);
    void InpActEvt_ItemSlot2_K2Node_InputActionEvent_14(FKey Key);
    void InpActEvt_ItemSlot3_K2Node_InputActionEvent_13(FKey Key);
    void InpActEvt_Inventory_K2Node_InputActionEvent_12(FKey Key);
    void InpActEvt_Use_K2Node_InputActionEvent_11(FKey Key);
    void OnNotifyEnd_D29E887443F8BB27A41C6A897CCFA477(FName NotifyName);
    void OnNotifyBegin_D29E887443F8BB27A41C6A897CCFA477(FName NotifyName);
    void OnInterrupted_D29E887443F8BB27A41C6A897CCFA477(FName NotifyName);
    void OnBlendOut_D29E887443F8BB27A41C6A897CCFA477(FName NotifyName);
    void OnCompleted_D29E887443F8BB27A41C6A897CCFA477(FName NotifyName);
    void OnNotifyEnd_556A838A4469A7E2C6BDC68317F1227A(FName NotifyName);
    void OnNotifyBegin_556A838A4469A7E2C6BDC68317F1227A(FName NotifyName);
    void OnInterrupted_556A838A4469A7E2C6BDC68317F1227A(FName NotifyName);
    void OnBlendOut_556A838A4469A7E2C6BDC68317F1227A(FName NotifyName);
    void OnCompleted_556A838A4469A7E2C6BDC68317F1227A(FName NotifyName);
    void OnNotifyEnd_4D724B00488829DB3EB49DB666B0EC0D(FName NotifyName);
    void OnNotifyBegin_4D724B00488829DB3EB49DB666B0EC0D(FName NotifyName);
    void OnInterrupted_4D724B00488829DB3EB49DB666B0EC0D(FName NotifyName);
    void OnBlendOut_4D724B00488829DB3EB49DB666B0EC0D(FName NotifyName);
    void OnCompleted_4D724B00488829DB3EB49DB666B0EC0D(FName NotifyName);
    void OnNotifyEnd_DB35E08445921C5BA12E20891BD497DB(FName NotifyName);
    void OnNotifyBegin_DB35E08445921C5BA12E20891BD497DB(FName NotifyName);
    void OnInterrupted_DB35E08445921C5BA12E20891BD497DB(FName NotifyName);
    void OnBlendOut_DB35E08445921C5BA12E20891BD497DB(FName NotifyName);
    void OnCompleted_DB35E08445921C5BA12E20891BD497DB(FName NotifyName);
    void OnNotifyEnd_CBC91CE2447BECCE0E9C54A0894758D6(FName NotifyName);
    void OnNotifyBegin_CBC91CE2447BECCE0E9C54A0894758D6(FName NotifyName);
    void OnInterrupted_CBC91CE2447BECCE0E9C54A0894758D6(FName NotifyName);
    void OnBlendOut_CBC91CE2447BECCE0E9C54A0894758D6(FName NotifyName);
    void OnCompleted_CBC91CE2447BECCE0E9C54A0894758D6(FName NotifyName);
    void OnNotifyEnd_18C90247430847ACB000EAA715356939(FName NotifyName);
    void OnNotifyBegin_18C90247430847ACB000EAA715356939(FName NotifyName);
    void OnInterrupted_18C90247430847ACB000EAA715356939(FName NotifyName);
    void OnBlendOut_18C90247430847ACB000EAA715356939(FName NotifyName);
    void OnCompleted_18C90247430847ACB000EAA715356939(FName NotifyName);
    void InpActEvt_Sprint_K2Node_InputActionEvent_10(FKey Key);
    void InpActEvt_Sprint_K2Node_InputActionEvent_9(FKey Key);
    void InpActEvt_ShowIDCard_K2Node_InputActionEvent_8(FKey Key);
    void OnNotifyEnd_F14B8C27489433D0AC4E5981B3D35BB2(FName NotifyName);
    void OnNotifyBegin_F14B8C27489433D0AC4E5981B3D35BB2(FName NotifyName);
    void OnInterrupted_F14B8C27489433D0AC4E5981B3D35BB2(FName NotifyName);
    void OnBlendOut_F14B8C27489433D0AC4E5981B3D35BB2(FName NotifyName);
    void OnCompleted_F14B8C27489433D0AC4E5981B3D35BB2(FName NotifyName);
    void OnNotifyEnd_9B0709674BA2A8EC63179B9F269BC874(FName NotifyName);
    void OnNotifyBegin_9B0709674BA2A8EC63179B9F269BC874(FName NotifyName);
    void OnInterrupted_9B0709674BA2A8EC63179B9F269BC874(FName NotifyName);
    void OnBlendOut_9B0709674BA2A8EC63179B9F269BC874(FName NotifyName);
    void OnCompleted_9B0709674BA2A8EC63179B9F269BC874(FName NotifyName);
    void InpActEvt_Jump_K2Node_InputActionEvent_7(FKey Key);
    void InpActEvt_Jump_K2Node_InputActionEvent_6(FKey Key);
    void InpActEvt_LeanLeft_K2Node_InputActionEvent_5(FKey Key);
    void InpActEvt_LeanLeft_K2Node_InputActionEvent_4(FKey Key);
    void InpActEvt_LeanRight_K2Node_InputActionEvent_3(FKey Key);
    void InpActEvt_LeanRight_K2Node_InputActionEvent_2(FKey Key);
    void InpActEvt_Crouch_K2Node_InputActionEvent_1(FKey Key);
    void InpActEvt_Crouch_K2Node_InputActionEvent_0(FKey Key);
    void InpAxisKeyEvt_Gamepad_LeftX_K2Node_InputAxisKeyEvent_0(float AxisValue);
    void InpAxisKeyEvt_Gamepad_LeftY_K2Node_InputAxisKeyEvent_1(float AxisValue);
    void AddTag_MC(FString Tag);
    void RemoveTag_MC(FString Tag);
    void StartClimbing();
    void StartClimbingTop();
    void StartClimbingBot_SERVER();
    void StartClimbingLadder(class ABP_Pool_Ladder_C* PoolLadder, float SpeedMultiplier);
    void StopClimbingLadder();
    void MoveToTop();
    void StartTransition(class ABP_Pool_Ladder_C* PoolLadder, float SpeedMultiplier);
    void StartClimbDown();
    void MoveToBottom();
    void StartPushingActor(class ABP_Pushable_C* PushableActor);
    void StopPushingActor();
    void StartPushingActor_SERVER(class ABP_Pushable_C* PushableActor, FVector B, FRotator NewRotation);
    void StartPushingActor_MC(class ABP_Pushable_C* PushableActor, FVector NewLocation, FRotator NewRotation);
    void StopPushingActor_SERVER(class ABP_Pushable_C* PushableActor);
    void StopPushingActor_MC(class ABP_Pushable_C* PushableActor);
    void ReceiveTick(float DeltaSeconds);
    void StopPushing();
    void SRV_BlockPushing(class ABP_Pushable_C* Pushable);
    void BndEvt__BPCharacter_Demo_CarrySystem_K2Node_ComponentBoundEvent_0_OnCarryEvent__DelegateSignature(class UFancyCarrySystemCarryable* Carryable);
    void BndEvt__BPCharacter_Demo_CarrySystem_K2Node_ComponentBoundEvent_1_OnCarryEvent__DelegateSignature(class UFancyCarrySystemCarryable* Carryable);
    void SRV_ToggleRadio(bool Enabled);
    void OC_SetupVoice();
    void DeleteVoice();
    void SpawnEquipItem_SERVER(TSubclassOf<class ABP_Item_C> ItemClass);
    void DestroyEquipItem_SERVER();
    void PickUp_SERVER(class ADroppedItem* Item);
    void Equip();
    void UnequipItem();
    void DropItem_SERVER(FName ItemType);
    void UseItem_SERVER(class ABP_Item_C* Item);
    void TryPickup();
    void HideLeftArm(bool Hide);
    void SpeedBoost();
    void StaminaBoost();
    void SpeedBoostClient();
    void HideRightArm(bool Hide);
    void DropAll();
    void MC_Pickup(FVector Location);
    void MC_Drop(FVector Location);
    void CheckSpawnedItems();
    void ConsumeCurrent(bool Drop, bool ResetUsage);
    void UpdateFOV();
    void ToggleItemVisible();
    void PlayItemMontage(class UAnimMontage* Montage, class UStaticMesh* ItemMesh, FTransform Offset);
    void PlayStatic();
    void PlayBrightness();
    void Fall();
    void PlayInsanity();
    void StopInsanity();
    void LookAtLocation(FHE_LookAtLocation Settings);
    void HE_LookAtLocation_Seq();
    void LookAtActor(FHE_LookAtActor LookAtActors);
    void HE_LookAtActorSeq();
    void StopAllMovement();
    void Fear(FHE_Fear Fear);
    void StopFear();
    void EndSanity();
    void PlayCameraShake(TSubclassOf<class UCameraShakeBase> Shake, float Duration);
    void PlayJumpScare(class ULevelSequence* Sequence, class AActor* Entity, FMovieSceneObjectBindingID EntityBinding, FMovieSceneObjectBindingID CameraBinding);
    void ShockedServer();
    void ShockedClient();
    void MC_Shocked();
    void AddHeat();
    void RemoveHeat();
    void LiquidPain();
    void WarnSanity();
    void ResetWarning();
    void ResetSanityWarning();
    void EquipHelmet();
    void AddHelmetEffects();
    void FadeHelmet();
    void SRV_UpdateBuoyancy();
    void OC_UpdateBuoyancy();
    void MC_NoClip();
    void SRV_Dive();
    void OC_Dive();
    void SRV_Drown();
    void OC_NoClip();
    void OC_CaveExit();
    void OC_UnderwaterMix();
    void StartPlague();
    void StopPlague();
    void ResetPlague();
    void OC_FadeOut();
    void MC_Slipped();
    void RemovePlague();
    void PlagueBoat();
    void MC_PassOut();
    void OC_PassOut();
    void SRV_PassOut();
    void SRV_WarnSanity();
    void SRV_ResetSanityWarning();
    void SetWalkSpeedServer(float Speed);
    void KillClient(FName DeathCause);
    void KillServer(bool bResetInteractable);
    void ReceiveDestroyed();
    void SetMinPitch();
    void OnPossess();
    void SetSprintSpeedServer(float Speed);
    void ShowCard_Server();
    void RopePitch(bool Activate);
    void HidePlayer(bool Hidden);
    void OnFlashlightEntity(class AActor* Entity);
    void ToggleFlash(class AActor* Actor);
    void MC_ShowCard();
    void SetIsClimbing(bool IsClimbing);
    void ClimbRope(FTransform StartingTransform, FTransform TargetTransform);
    void StopClimbRope();
    void MC_RopePosition(FVector AttachEnd, class AActor* Actor);
    void Climb94Rope();
    void HideItem(bool IsVisible);
    void ClimbLadder();
    void GarageStepHeight();
    void ToggleItem(class AActor* Actor);
    void ClimbCaveLadder();
    void SetCrouchWalkSpeedServer(float Speed);
    void FinishKeySequence();
    void InpAxisEvt_MoveForward_K2Node_InputAxisEvent_181(float AxisValue);
    void InpAxisEvt_MoveRight_K2Node_InputAxisEvent_192(float AxisValue);
    void Burnout();
    void BndEvt__BPCharacter_Demo_PawnSensing_K2Node_ComponentBoundEvent_0_SeePawnDelegate__DelegateSignature(class APawn* Pawn);
    void ReceiveBeginPlay();
    void OnLanded(const FHitResult& Hit);
    void K2_OnStartCrouch(float HalfHeightAdjust, float ScaledHalfHeightAdjust);
    void K2_OnEndCrouch(float HalfHeightAdjust, float ScaledHalfHeightAdjust);
    void SenseClient();
    void CreateLegs();
    void HideLegs(bool Visible);
    void ChangeCrosshairVisibility(bool IsVisible);
    void ShowInteractText(const FText& Text);
    void ToggleBlur(bool ShouldBlur);
    void StartBalance(bool Direction, bool First);
    void OnBalance();
    void StopBalance();
    void OnFall();
    void StartFlashlightCheck(bool ShouldAdd, FName Tag);
    void StopFlashlightCheck(bool ShouldCheck, FName Tag);
    void TogglePlayerLegs(bool IsHidden);
    void SRV_Launch(float Input);
    void OnQueryFinished(class UEnvQueryInstanceBlueprintWrapper* QueryInstance, TEnumAsByte<EEnvQueryStatus::Type> QueryStatus);
    void SnapToLand();
    void HideSwimmingArms(FVector Loc);
    void K2_OnMovementModeChanged(TEnumAsByte<EMovementMode> PrevMovementMode, TEnumAsByte<EMovementMode> NewMovementMode, uint8 PrevCustomMode, uint8 NewCustomMode);
    void StartUnderwater();
    void OrientMovement();
    void BobWater();
    void StopBob();
    void SRV_OrientMovement();
    void OC_StartSwimming();
    void OffsetJump();
    void ResetJumpOffset();
    void OnLandedCrouchCheck();
    void Reduce PP Barrel Distortion();
    void Restore PP Barrel Distortion();
    void ApplyCostume(class UCostume* Costume);
    void SpawnCard();
    void ReceiveEndPlay(TEnumAsByte<EEndPlayReason::Type> EndPlayReason);
    void InpAxisEvt_Turn_K2Node_InputAxisEvent_157(float AxisValue);
    void InpAxisEvt_LookUp_K2Node_InputAxisEvent_172(float AxisValue);
    void InpAxisEvt_TurnRate_K2Node_InputAxisEvent_0(float AxisValue);
    void InpAxisEvt_LookUpRate_K2Node_InputAxisEvent_1(float AxisValue);
    void ExecuteUbergraph_BPCharacter_Demo(int32 EntryPoint);
}; // Size: 0xB45

#endif
