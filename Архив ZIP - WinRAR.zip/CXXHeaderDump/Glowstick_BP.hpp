#ifndef UE4SS_SDK_Glowstick_BP_HPP
#define UE4SS_SDK_Glowstick_BP_HPP

class AGlowstick_BP_C : public AActor
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x0220 (size: 0x8)
    class UStaticMeshComponent* GlowStick;                                            // 0x0228 (size: 0x8)
    class USceneComponent* DefaultSceneRoot;                                          // 0x0230 (size: 0x8)
    TEnumAsByte<E_GlowstickColor::Type> GlowstickColor;                               // 0x0238 (size: 0x1)

    void UserConstructionScript();
    void ReceiveBeginPlay();
    void ExecuteUbergraph_Glowstick_BP(int32 EntryPoint);
}; // Size: 0x239

#endif
