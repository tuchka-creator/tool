#ifndef UE4SS_SDK_BTDecorator_ShouldRoam_HPP
#define UE4SS_SDK_BTDecorator_ShouldRoam_HPP

class UBTDecorator_ShouldRoam_C : public UBTDecorator_BlueprintBase
{

    bool PerformConditionCheckAI(class AAIController* OwnerController, class APawn* ControlledPawn);
}; // Size: 0xA0

#endif
