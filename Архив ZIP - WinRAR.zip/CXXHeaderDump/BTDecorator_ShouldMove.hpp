#ifndef UE4SS_SDK_BTDecorator_ShouldMove_HPP
#define UE4SS_SDK_BTDecorator_ShouldMove_HPP

class UBTDecorator_ShouldMove_C : public UBTDecorator_BlueprintBase
{

    bool PerformConditionCheckAI(class AAIController* OwnerController, class APawn* ControlledPawn);
}; // Size: 0xA0

#endif
