#ifndef UE4SS_SDK_BP_DroppedItem_Rope_HPP
#define UE4SS_SDK_BP_DroppedItem_Rope_HPP

class ABP_DroppedItem_Rope_C : public ABP_DroppedItem_C
{
}; // Size: 0x269

#endif
