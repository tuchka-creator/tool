#ifndef UE4SS_SDK_BP_DroppedItem_Glowstick_Yellow_HPP
#define UE4SS_SDK_BP_DroppedItem_Glowstick_Yellow_HPP

class ABP_DroppedItem_Glowstick_Yellow_C : public ABP_DroppedItem_Glowstick_C
{
}; // Size: 0x2B5

#endif
