#ifndef UE4SS_SDK_BP_FlareProjectile_HPP
#define UE4SS_SDK_BP_FlareProjectile_HPP

class ABP_FlareProjectile_C : public AActor
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x0220 (size: 0x8)
    class UNiagaraComponent* Niagara3;                                                // 0x0228 (size: 0x8)
    class UNiagaraComponent* Niagara2;                                                // 0x0230 (size: 0x8)
    class UNiagaraComponent* Niagara1;                                                // 0x0238 (size: 0x8)
    class UNiagaraComponent* Niagara;                                                 // 0x0240 (size: 0x8)
    class UStaticMeshComponent* Sphere1;                                              // 0x0248 (size: 0x8)
    class USphereComponent* Sphere;                                                   // 0x0250 (size: 0x8)
    class UProjectileMovementComponent* ProjectileMovement;                           // 0x0258 (size: 0x8)
    class USceneComponent* DefaultSceneRoot;                                          // 0x0260 (size: 0x8)
    float Fade_Fade_A328F4C84B56489B2E089B99B76CE01C;                                 // 0x0268 (size: 0x4)
    TEnumAsByte<ETimelineDirection::Type> Fade__Direction_A328F4C84B56489B2E089B99B76CE01C; // 0x026C (size: 0x1)
    class UTimelineComponent* Fade;                                                   // 0x0270 (size: 0x8)

    void Fade__FinishedFunc();
    void Fade__UpdateFunc();
    void Fade__Explode__EventFunc();
    void ReceiveTick(float DeltaSeconds);
    void ExecuteUbergraph_BP_FlareProjectile(int32 EntryPoint);
}; // Size: 0x278

#endif
