#ifndef UE4SS_SDK_BP_FlashlightVolume_HPP
#define UE4SS_SDK_BP_FlashlightVolume_HPP

class ABP_FlashlightVolume_C : public AActor
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x0220 (size: 0x8)
    class UBoxComponent* Box;                                                         // 0x0228 (size: 0x8)
    class ABP_Ambience_Manager_C* AmbienceManager;                                    // 0x0230 (size: 0x8)

    void BndEvt__BP_FlashlightVolume_Box_K2Node_ComponentBoundEvent_0_ComponentBeginOverlapSignature__DelegateSignature(class UPrimitiveComponent* OverlappedComponent, class AActor* OtherActor, class UPrimitiveComponent* OtherComp, int32 OtherBodyIndex, bool bFromSweep, const FHitResult& SweepResult);
    void BndEvt__BP_FlashlightVolume_Box_K2Node_ComponentBoundEvent_1_ComponentEndOverlapSignature__DelegateSignature(class UPrimitiveComponent* OverlappedComponent, class AActor* OtherActor, class UPrimitiveComponent* OtherComp, int32 OtherBodyIndex);
    void ExecuteUbergraph_BP_FlashlightVolume(int32 EntryPoint);
}; // Size: 0x238

#endif
