#ifndef UE4SS_SDK_BP_ExitConfirmationFlow_HPP
#define UE4SS_SDK_BP_ExitConfirmationFlow_HPP

class UBP_ExitConfirmationFlow_C : public UFancyUserFlow
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x00A8 (size: 0x8)
    class UWidget* PreviousWidget;                                                    // 0x00B0 (size: 0x8)

    void OnFailure_5187EBDB4745079782EFB389EADEC188();
    void OnSuccess_5187EBDB4745079782EFB389EADEC188();
    void Run();
    void PrepareModal(class UUserWidget* Modal);
    void HandleModalComplete(class UUserWidget* Modal);
    void ExecuteUbergraph_BP_ExitConfirmationFlow(int32 EntryPoint);
}; // Size: 0xB8

#endif
