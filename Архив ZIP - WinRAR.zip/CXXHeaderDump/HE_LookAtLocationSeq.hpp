#ifndef UE4SS_SDK_HE_LookAtLocationSeq_HPP
#define UE4SS_SDK_HE_LookAtLocationSeq_HPP

struct FHE_LookAtLocationSeq
{
    FVector LocationtoLook_15_08279B704682B57A7B58B18AAEEB7C94;                       // 0x0000 (size: 0xC)
    bool Smooth_5_454C4AB74997F23D045944B6901E1DA9;                                   // 0x000C (size: 0x1)
    float TurnSpeedSec_9_F1ED92664D8E504C55E2B299A1C16F4F;                            // 0x0010 (size: 0x4)
    float KeepLookingDurationSec_13_46B29F5047553D83F96803B9CEE30F22;                 // 0x0014 (size: 0x4)

}; // Size: 0x18

#endif
