#ifndef UE4SS_SDK_BP_Item_Toy_HPP
#define UE4SS_SDK_BP_Item_Toy_HPP

class ABP_Item_Toy_C : public ABP_Item_C
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x0258 (size: 0x8)

    void OnNotifyEnd_E7C10CF145CF5799DFA524820188E4F6(FName NotifyName);
    void OnNotifyBegin_E7C10CF145CF5799DFA524820188E4F6(FName NotifyName);
    void OnInterrupted_E7C10CF145CF5799DFA524820188E4F6(FName NotifyName);
    void OnBlendOut_E7C10CF145CF5799DFA524820188E4F6(FName NotifyName);
    void OnCompleted_E7C10CF145CF5799DFA524820188E4F6(FName NotifyName);
    void UseItem();
    void MC_Drop();
    void ReceiveBeginPlay();
    void ExecuteUbergraph_BP_Item_Toy(int32 EntryPoint);
}; // Size: 0x260

#endif
