#ifndef UE4SS_SDK_Lobby_LobbyCodeDisplay_HPP
#define UE4SS_SDK_Lobby_LobbyCodeDisplay_HPP

class ULobby_LobbyCodeDisplay_C : public UUserWidget
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x0270 (size: 0x8)
    class UTextBlock* CodeDisplay;                                                    // 0x0278 (size: 0x8)
    class UTextBlock* LobbyCodeLabel;                                                 // 0x0280 (size: 0x8)
    class UButton* ShowButtonOff;                                                     // 0x0288 (size: 0x8)
    class UButton* ShowButtonOn;                                                      // 0x0290 (size: 0x8)
    class UWidgetSwitcher* ShowButtonSwitcher;                                        // 0x0298 (size: 0x8)
    bool bShow;                                                                       // 0x02A0 (size: 0x1)
    FSlateBrush ButtonOffFocusedStyle;                                                // 0x02A8 (size: 0x88)
    FSlateBrush ButtonOnFocusedStyle;                                                 // 0x0330 (size: 0x88)
    FSlateBrush ButtonOffUnfocusedStyle;                                              // 0x03B8 (size: 0x88)
    FSlateBrush ButtonOnUnfocusedStyle;                                               // 0x0440 (size: 0x88)
    bool bFocused;                                                                    // 0x04C8 (size: 0x1)
    bool bIgnoreAcceptOnKeyboardMouse;                                                // 0x04C9 (size: 0x1)

    void Set Button Normal Style(class UButton* Button, FSlateBrush Unfocused, FSlateBrush Focused);
    void OnFocusLost(FFocusEvent InFocusEvent);
    FEventReply OnKeyDown(FGeometry MyGeometry, FKeyEvent InKeyEvent);
    FEventReply OnFocusReceived(FGeometry MyGeometry, FFocusEvent InFocusEvent);
    FText Get_CodeDisplay_Text_0();
    void SetShowState(bool On);
    void Construct();
    void BndEvt__Lobby_LobbyCodeDisplay_ShowButtonOn_K2Node_ComponentBoundEvent_0_OnButtonClickedEvent__DelegateSignature();
    void BndEvt__Lobby_LobbyCodeDisplay_ShowButtonOff_K2Node_ComponentBoundEvent_1_OnButtonClickedEvent__DelegateSignature();
    void HandleButtonPressed();
    void UpdateButtonStyle();
    void ExecuteUbergraph_Lobby_LobbyCodeDisplay(int32 EntryPoint);
}; // Size: 0x4CA

#endif
