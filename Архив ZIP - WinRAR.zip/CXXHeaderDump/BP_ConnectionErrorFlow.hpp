#ifndef UE4SS_SDK_BP_ConnectionErrorFlow_HPP
#define UE4SS_SDK_BP_ConnectionErrorFlow_HPP

class UBP_ConnectionErrorFlow_C : public UFancyUserFlow
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x00A8 (size: 0x8)
    TEnumAsByte<ENetworkFailure::Type> NetworkFailure;                                // 0x00B0 (size: 0x1)

    void Run();
    void ExecuteUbergraph_BP_ConnectionErrorFlow(int32 EntryPoint);
}; // Size: 0xB1

#endif
