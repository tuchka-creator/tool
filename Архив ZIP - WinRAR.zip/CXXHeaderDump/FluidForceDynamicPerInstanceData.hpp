#ifndef UE4SS_SDK_FluidForceDynamicPerInstanceData_HPP
#define UE4SS_SDK_FluidForceDynamicPerInstanceData_HPP

struct FFluidForceDynamicPerInstanceData
{
    FFluidForceDynamic ForceInfo_2_A6A35E3243FAF59D161A5FBAA2F6F2B1;                  // 0x0000 (size: 0x70)
    FVector ComponentLocation_13_959307184C8E5CCACA55FC8378D92CFD;                    // 0x0070 (size: 0xC)
    FVector ComponentVelocity_5_4F6589474918826DF8A6468CF0F2C361;                     // 0x007C (size: 0xC)
    float BoundsRadius_30_ADFF818743BE39AC4A481D995CB50D03;                           // 0x0088 (size: 0x4)
    float WaterLevel_34_A4E505D148073B883CA7B1B09A3E34A8;                             // 0x008C (size: 0x4)
    TMap<class FName, class FVector> SocketLocationMap_21_ABF6AA244A5F84728A5E83BE2328C7FA; // 0x0090 (size: 0x50)
    TMap<class FName, class FVector> SocketVelocityMap_26_82B0E24B45935A12E1949F918A59A537; // 0x00E0 (size: 0x50)

}; // Size: 0x130

#endif
