#ifndef UE4SS_SDK_BP_FallZone_HPP
#define UE4SS_SDK_BP_FallZone_HPP

class ABP_FallZone_C : public ATriggerBox
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x0228 (size: 0x8)

    void ReceiveActorBeginOverlap(class AActor* OtherActor);
    void ExecuteUbergraph_BP_FallZone(int32 EntryPoint);
}; // Size: 0x230

#endif
