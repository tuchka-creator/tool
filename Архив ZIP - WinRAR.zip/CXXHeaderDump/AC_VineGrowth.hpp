#ifndef UE4SS_SDK_AC_VineGrowth_HPP
#define UE4SS_SDK_AC_VineGrowth_HPP

class UAC_VineGrowth_C : public UActorComponent
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x00B0 (size: 0x8)
    class ABPCharacter_Demo_C* Player;                                                // 0x00B8 (size: 0x8)
    float IdleCounter;                                                                // 0x00C0 (size: 0x4)
    float TimeUntilVinesGrow;                                                         // 0x00C4 (size: 0x4)
    float TimeUntilTangled;                                                           // 0x00C8 (size: 0x4)
    class AVineGrow_BP_C* ClientVisuals;                                              // 0x00D0 (size: 0x8)
    bool GrowVinesClient;                                                             // 0x00D8 (size: 0x1)
    FTimerHandle KillTimer;                                                           // 0x00E0 (size: 0x8)
    bool IsTangled;                                                                   // 0x00E8 (size: 0x1)

    void SpawnClientVisuals();
    void CheckAllPlayersTangled(bool& AllTangled, TArray<class ABPCharacter_Demo_C*>& Characters);
    void OnRep_GrowVinesClient();
    void Is Player Compromised(bool& IsInGrass);
    void ReceiveBeginPlay();
    void ReceiveTick(float DeltaSeconds);
    void GrowVines();
    void ResetVines();
    void TanglePlayer();
    void ResetTangle();
    void UntanglePlayer();
    void ReceiveEndPlay(TEnumAsByte<EEndPlayReason::Type> EndPlayReason);
    void ResetUntangle();
    void ResetAfterFullyUntangled();
    void KillAllPlayers();
    void ExecuteUbergraph_AC_VineGrowth(int32 EntryPoint);
}; // Size: 0xE9

#endif
