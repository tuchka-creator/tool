#ifndef UE4SS_SDK_FadeOut_UI_HPP
#define UE4SS_SDK_FadeOut_UI_HPP

class UFadeOut_UI_C : public UUserWidget
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x0270 (size: 0x8)
    class UWidgetAnimation* FadeIn;                                                   // 0x0278 (size: 0x8)
    class UWidgetAnimation* Fade;                                                     // 0x0280 (size: 0x8)
    bool Reverse;                                                                     // 0x0288 (size: 0x1)

    void CanClose();
    void Construct();
    void ExecuteUbergraph_FadeOut_UI(int32 EntryPoint);
}; // Size: 0x289

#endif
