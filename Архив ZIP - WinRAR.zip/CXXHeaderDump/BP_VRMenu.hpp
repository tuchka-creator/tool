#ifndef UE4SS_SDK_BP_VRMenu_HPP
#define UE4SS_SDK_BP_VRMenu_HPP

class ABP_VRMenu_C : public AActor
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x0220 (size: 0x8)
    class UWidgetComponent* Widget;                                                   // 0x0228 (size: 0x8)
    class USceneComponent* DefaultSceneRoot;                                          // 0x0230 (size: 0x8)

    void RefreshFocus();
    void UnHide();
    void ReceiveBeginPlay();
    void ExecuteUbergraph_BP_VRMenu(int32 EntryPoint);
}; // Size: 0x238

#endif
