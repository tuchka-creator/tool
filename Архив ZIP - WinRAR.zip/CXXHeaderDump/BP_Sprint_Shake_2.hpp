#ifndef UE4SS_SDK_BP_Sprint_Shake_2_HPP
#define UE4SS_SDK_BP_Sprint_Shake_2_HPP

class UBP_Sprint_Shake_2_C : public UMatineeCameraShake
{
}; // Size: 0x1B0

#endif
