#ifndef UE4SS_SDK_BP_Rope_Floor_HPP
#define UE4SS_SDK_BP_Rope_Floor_HPP

class ABP_Rope_Floor_C : public AActor
{
    class UStaticMeshComponent* StaticMesh;                                           // 0x0220 (size: 0x8)

}; // Size: 0x228

#endif
