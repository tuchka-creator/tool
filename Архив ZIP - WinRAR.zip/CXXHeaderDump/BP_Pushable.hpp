#ifndef UE4SS_SDK_BP_Pushable_HPP
#define UE4SS_SDK_BP_Pushable_HPP

class ABP_Pushable_C : public APushableActor
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x0250 (size: 0x8)
    class UStaticMeshComponent* StaticMesh1;                                          // 0x0258 (size: 0x8)
    class UAudioComponent* Audio;                                                     // 0x0260 (size: 0x8)
    class UStaticMeshComponent* StaticMesh3;                                          // 0x0268 (size: 0x8)
    class USceneComponent* CablePoint;                                                // 0x0270 (size: 0x8)
    class UStaticMeshComponent* StaticMesh2;                                          // 0x0278 (size: 0x8)
    int32 Index;                                                                      // 0x0280 (size: 0x4)
    class ABPCharacter_Demo_C* PushingActor;                                          // 0x0288 (size: 0x8)
    bool Active;                                                                      // 0x0290 (size: 0x1)
    bool CanPush;                                                                     // 0x0291 (size: 0x1)
    bool IsPlaced;                                                                    // 0x0292 (size: 0x1)

    void OnRep_Index();
    TArray<FVector> Get Right Collision Points(class ABPCharacter_Demo_C* PushingActor, float Axis);
    void Can Push(class ABPCharacter_Demo_C* Target, float NewParam, bool MoveForward, bool& NewParam2);
    void Get Forward Collision Points(class ABPCharacter_Demo_C* PushingActor, float Axis, TArray<FVector>& CollisionPoints);
    void OnRep_CanPush();
    void OnRep_Active();
    void UserConstructionScript();
    void OnActorUsed(class ACharacter* Character);
    void ExecuteUbergraph_BP_Pushable(int32 EntryPoint);
}; // Size: 0x293

#endif
