#ifndef UE4SS_SDK_BP_DismemberComponent_HPP
#define UE4SS_SDK_BP_DismemberComponent_HPP

class UBP_DismemberComponent_C : public UActorComponent
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x00B0 (size: 0x8)
    class USkeletalMeshComponent* SkeletalMesh;                                       // 0x00B8 (size: 0x8)
    FName BrokenBone;                                                                 // 0x00C0 (size: 0x8)
    FName ParentOfBrokenBone;                                                         // 0x00C8 (size: 0x8)
    class UStaticMesh* Mesh_R_Leg;                                                    // 0x00D0 (size: 0x8)
    class UStaticMesh* Mesh_R_Hand;                                                   // 0x00D8 (size: 0x8)
    class UStaticMesh* Mesh_R_Arm;                                                    // 0x00E0 (size: 0x8)
    class UStaticMesh* Mesh_Head;                                                     // 0x00E8 (size: 0x8)
    int32 AmountOfBloodGashes;                                                        // 0x00F0 (size: 0x4)
    TArray<class UParticleSystemComponent*> BloodSpurtEmitterReference;               // 0x00F8 (size: 0x10)
    bool OnlySpawnMush;                                                               // 0x0108 (size: 0x1)
    class UCostume* Costume;                                                          // 0x0110 (size: 0x8)

    void GetBoneAsDismembermentPart(ECostumeDismembermentPart& DismembermentPart);
    class UMaterialInterface* ChooseMeatMaterial(bool GetBoneMaterial);
    class UStaticMesh* ChooseMeatPiece(bool GetBoneMesh);
    bool BoneIsNonMush();
    bool BrokenBoneIs(FString Substring);
    void ApplyCostume(class UCostume* Costume);
    void SpawnRandomSpatter(FVector Location, FRotator Rotation, class UDecalComponent*& DecalComponent);
    FRotator CalculateBloodEffectRotation();
    void Dismember(FName Bone, FVector ImpactNormal);
    void SpawnDecal();
    void ExecuteUbergraph_BP_DismemberComponent(int32 EntryPoint);
}; // Size: 0x118

#endif
