#ifndef UE4SS_SDK_InteractiveGrassManager_BP_HPP
#define UE4SS_SDK_InteractiveGrassManager_BP_HPP

class AInteractiveGrassManager_BP_C : public AActor
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x0220 (size: 0x8)
    class UBillboardComponent* Icon;                                                  // 0x0228 (size: 0x8)
    class USceneComponent* DefaultSceneRoot;                                          // 0x0230 (size: 0x8)
    float WindStrengthChanger_Multi_C3C4D7E84F596148E4C0609D15288382;                 // 0x0238 (size: 0x4)
    TEnumAsByte<ETimelineDirection::Type> WindStrengthChanger__Direction_C3C4D7E84F596148E4C0609D15288382; // 0x023C (size: 0x1)
    class UTimelineComponent* WindStrengthChanger;                                    // 0x0240 (size: 0x8)
    float WindDirectionChanger_Multi_9C34F595444C0F6BF631DAB82A6B23DF;                // 0x0248 (size: 0x4)
    TEnumAsByte<ETimelineDirection::Type> WindDirectionChanger__Direction_9C34F595444C0F6BF631DAB82A6B23DF; // 0x024C (size: 0x1)
    class UTimelineComponent* WindDirectionChanger;                                   // 0x0250 (size: 0x8)
    FVector WindDirection;                                                            // 0x0258 (size: 0xC)
    float WindStrength;                                                               // 0x0264 (size: 0x4)
    TArray<bool> univMaterialInteractionChannels;                                     // 0x0268 (size: 0x10)
    int32 currentDispInteractingActors;                                               // 0x0278 (size: 0x4)
    int32 maxDisplacementInteractingActors;                                           // 0x027C (size: 0x4)
    float newWindTextureRotationAngle;                                                // 0x0280 (size: 0x4)
    float newWindTextureRotationValue;                                                // 0x0284 (size: 0x4)
    float previousWindStrength;                                                       // 0x0288 (size: 0x4)
    float DirectionChangeDuration;                                                    // 0x028C (size: 0x4)
    float StrengthChangeDuration;                                                     // 0x0290 (size: 0x4)
    class UFoliageInstancedStaticMeshComponent* FoliageComponent;                     // 0x0298 (size: 0x8)
    float FoliageChunkSize;                                                           // 0x02A0 (size: 0x4)
    float FoliageChunkDeactivateRadius;                                               // 0x02A4 (size: 0x4)
    TArray<class AInteractiveFoliageChunk_BP_C*> interactiveFoliageChunks;            // 0x02A8 (size: 0x10)
    float FoliageChunkDetectionInterval;                                              // 0x02B8 (size: 0x4)
    float FoliageChunkDeactivateInterval;                                             // 0x02BC (size: 0x4)
    float originalCloudShadowOpacity;                                                 // 0x02C0 (size: 0x4)
    TArray<class UINTERACTIVE_FoliageComp_BP_C*> componentsToSpawnWith;               // 0x02C8 (size: 0x10)

    void PopulateMapWithGrass();
    void AddFoliageChunkActor(FVector ChunkCenter, class UINTERACTIVE_FoliageComp_BP_C* SourceComponent, bool replaceWithSourceComponent, bool leaveDefaultComponent, class AInteractiveFoliageChunk_BP_C*& addedChunk);
    void DistanceToViewTarget(FVector fromLocation, float& Distance);
    void FreeUpMaterialInteractionChannel(int32 nrOfChannel);
    void GetFreeMaterialInteractionChannel(bool& Found, int32& foundChannel);
    void SpawnFoliageCluster(FVector CenterLocation, float sizeX_, float sizeY_, float density_, float nonUniformDistribution, FFoliageToSpawn_Struct FoliageToSpawn, FVector minScale, FVector MaxScale, bool useGrassSpawnAreas, class AGrassSpawnArea_BP_C* grassSpawnArea);
    void SpawnFoliage(bool spawnUnderCursor, FVector locationIfNotUnderCursor, FVector normalIfNotUnderCursor, FVector minScale, FVector MaxScale, FFoliageToSpawn_Struct FoliageToSpawn, bool fromCluster, bool clusterLastIndex);
    void WindDirectionChanger__FinishedFunc();
    void WindDirectionChanger__UpdateFunc();
    void WindDirectionChanger__ChangeDirection__EventFunc();
    void WindStrengthChanger__FinishedFunc();
    void WindStrengthChanger__UpdateFunc();
    void WindStrengthChanger__Change__EventFunc();
    void ReceiveBeginPlay();
    void SmoothlyChangeWindDirection(FVector newDirection);
    void SmoothlyChangeWindStrength(float newStrength);
    void ExecuteUbergraph_InteractiveGrassManager_BP(int32 EntryPoint);
}; // Size: 0x2D8

#endif
