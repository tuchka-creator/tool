#ifndef UE4SS_SDK_BP_DroppedItem_Glowstick_HPP
#define UE4SS_SDK_BP_DroppedItem_Glowstick_HPP

class ABP_DroppedItem_Glowstick_C : public ABP_DroppedItem_C
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x0270 (size: 0x8)
    class USpotLightComponent* SpotLight;                                             // 0x0278 (size: 0x8)
    class UPointLightComponent* PointLight;                                           // 0x0280 (size: 0x8)
    FGuid GlowstickID;                                                                // 0x0288 (size: 0x10)
    bool ShouldGlow;                                                                  // 0x0298 (size: 0x1)
    class UBP_Glowstick_Component_C* GlowstickComponent;                              // 0x02A0 (size: 0x8)
    FRotator SpotlightRotation;                                                       // 0x02A8 (size: 0xC)
    bool IsSpawned;                                                                   // 0x02B4 (size: 0x1)

    void ReceiveDestroyed();
    void ReceiveBeginPlay();
    void ExecuteUbergraph_BP_DroppedItem_Glowstick(int32 EntryPoint);
}; // Size: 0x2B5

#endif
