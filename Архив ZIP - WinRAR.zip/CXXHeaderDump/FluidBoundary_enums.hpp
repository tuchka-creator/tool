namespace FluidBoundary {
    enum Type {
        NewEnumerator0 = 0,
        NewEnumerator1 = 1,
        FluidBoundary_MAX = 2,
    };
}

