#ifndef UE4SS_SDK_BP_JoinWithLobbyCodeFlow_HPP
#define UE4SS_SDK_BP_JoinWithLobbyCodeFlow_HPP

class UBP_JoinWithLobbyCodeFlow_C : public UFancyUserFlow
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x00A8 (size: 0x8)
    class UWidget* PrevFocusedWidget;                                                 // 0x00B0 (size: 0x8)
    bool bSuccessfullyEnteredLobby;                                                   // 0x00B8 (size: 0x1)

    void PrepareModal(class UUserWidget* Modal);
    void ExitFlow();
    void OnComplete(class UUserWidget* Modal);
    void Run();
    void ExecuteUbergraph_BP_JoinWithLobbyCodeFlow(int32 EntryPoint);
}; // Size: 0xB9

#endif
