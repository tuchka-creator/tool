#ifndef UE4SS_SDK_BP_LadderPiece_HPP
#define UE4SS_SDK_BP_LadderPiece_HPP

class ABP_LadderPiece_C : public AInteractableActor
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x0248 (size: 0x8)
    class UWidgetComponent* Widget;                                                   // 0x0250 (size: 0x8)

    void OnActorUsed(class ACharacter* Character);
    void OnBeginHighlight();
    void OnEndHighlight();
    void ReceiveBeginPlay();
    void ExecuteUbergraph_BP_LadderPiece(int32 EntryPoint);
}; // Size: 0x258

#endif
