#ifndef UE4SS_SDK_BP_Lever_HPP
#define UE4SS_SDK_BP_Lever_HPP

class ABP_Lever_C : public AInteractableActor
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x0248 (size: 0x8)
    class USkeletalMeshComponent* SkeletalMesh;                                       // 0x0250 (size: 0x8)
    class ABP_Elevator_C* Elevator;                                                   // 0x0258 (size: 0x8)
    int32 LeverState;                                                                 // 0x0260 (size: 0x4)

    void ToggleElevator();
    void OnActorUsed(class ACharacter* Character);
    void NextState();
    void ExecuteUbergraph_BP_Lever(int32 EntryPoint);
}; // Size: 0x264

#endif
