#ifndef UE4SS_SDK_Disguised_AnimBP_HPP
#define UE4SS_SDK_Disguised_AnimBP_HPP

class UDisguised_AnimBP_C : public UAnimInstance
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x02C0 (size: 0x8)
    FAnimNode_Root AnimGraphNode_Root;                                                // 0x02C8 (size: 0x30)
    FAnimNode_TransitionResult AnimGraphNode_TransitionResult_1;                      // 0x02F8 (size: 0x28)
    FAnimNode_TransitionResult AnimGraphNode_TransitionResult;                        // 0x0320 (size: 0x28)
    FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer;                            // 0x0348 (size: 0x80)
    FAnimNode_StateResult AnimGraphNode_StateResult_1;                                // 0x03C8 (size: 0x30)
    FAnimNode_BlendSpacePlayer AnimGraphNode_BlendSpacePlayer;                        // 0x03F8 (size: 0xE8)
    FAnimNode_StateResult AnimGraphNode_StateResult;                                  // 0x04E0 (size: 0x30)
    FAnimNode_StateMachine AnimGraphNode_StateMachine;                                // 0x0510 (size: 0xB0)
    float Speed;                                                                      // 0x05C0 (size: 0x4)
    float Direction;                                                                  // 0x05C4 (size: 0x4)
    float Pitch;                                                                      // 0x05C8 (size: 0x4)
    bool EnableJump;                                                                  // 0x05CC (size: 0x1)
    bool Jumping;                                                                     // 0x05CD (size: 0x1)
    bool Crouching;                                                                   // 0x05CE (size: 0x1)
    FHorrorEngineSettings GameSettings;                                               // 0x05D0 (size: 0xA0)
    bool Flashlight;                                                                  // 0x0670 (size: 0x1)

    void AnimGraph(FPoseLink& AnimGraph);
    void Footstep(TEnumAsByte<FootstepActionsEnum::Type> FootstepType);
    void EvaluateGraphExposedInputs_ExecuteUbergraph_Disguised_AnimBP_AnimGraphNode_TransitionResult_6DD3BEF641BB0964890E58B7142F3B58();
    void EvaluateGraphExposedInputs_ExecuteUbergraph_Disguised_AnimBP_AnimGraphNode_TransitionResult_3A3BFB584A1DA03B6E1877846B531A8E();
    void BlueprintUpdateAnimation(float DeltaTimeX);
    void AnimNotify_Footstep();
    void ExecuteUbergraph_Disguised_AnimBP(int32 EntryPoint);
}; // Size: 0x671

#endif
