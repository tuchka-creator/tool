#ifndef UE4SS_SDK_BP_Spectator_HPP
#define UE4SS_SDK_BP_Spectator_HPP

class ABP_Spectator_C : public APawn
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x0280 (size: 0x8)
    class USpringArmComponent* SpringArm;                                             // 0x0288 (size: 0x8)
    class UCameraComponent* Camera;                                                   // 0x0290 (size: 0x8)
    int32 SpectatingIndex;                                                            // 0x0298 (size: 0x4)
    class ABPCharacter_Demo_C* Target;                                                // 0x02A0 (size: 0x8)
    bool CanSwitch;                                                                   // 0x02A8 (size: 0x1)
    class AMP_PlayerController_C* Player Controller;                                  // 0x02B0 (size: 0x8)

    void GetPlayerNamePlatform(class APlayerState* PlayerState, FString& PlayerName, EFancyPlatform& PlayerPlatform);
    void SpectateIndex(int32 SpectateIndex);
    void SpectateNext();
    void SpectatePrevious();
    void InpActEvt_Secondary_K2Node_InputActionEvent_3(FKey Key);
    void InpActEvt_Use_K2Node_InputActionEvent_2(FKey Key);
    void InpActEvt_LeanLeft_K2Node_InputActionEvent_1(FKey Key);
    void InpActEvt_LeanRight_K2Node_InputActionEvent_0(FKey Key);
    void InpAxisEvt_LookUp_K2Node_InputAxisEvent_0(float AxisValue);
    void InpAxisEvt_Turn_K2Node_InputAxisEvent_1(float AxisValue);
    void SpectateNextPlayer();
    void SpectatePreviousPlayer();
    void UpdateSpectating(FString Spectating, EFancyPlatform PlayerPlatform);
    void InpAxisEvt_LookUpRate_K2Node_InputAxisEvent_2(float AxisValue);
    void InpAxisEvt_TurnRate_K2Node_InputAxisEvent_3(float AxisValue);
    void ReceivePossessed(class AController* NewController);
    void ClientPossessed(class AMP_PlayerController_C* PlayerController);
    void ResetSpectateToIndex0();
    void OnTargetDestroyed(class AActor* DestroyedActor);
    void ExecuteUbergraph_BP_Spectator(int32 EntryPoint);
}; // Size: 0x2B8

#endif
