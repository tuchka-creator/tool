#ifndef UE4SS_SDK_BPP_HISM_HPP
#define UE4SS_SDK_BPP_HISM_HPP

class ABPP_HISM_C : public AActor
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x0220 (size: 0x8)
    class UHierarchicalInstancedStaticMeshComponent* HierarchicalInstancedStaticMesh; // 0x0228 (size: 0x8)
    class UStaticMesh* Static Mesh;                                                   // 0x0230 (size: 0x8)
    TArray<FTransform> Instance Transforms;                                           // 0x0238 (size: 0x10)
    bool Cull Distance Enable;                                                        // 0x0248 (size: 0x1)
    float Cull Distance Falloff Percentage;                                           // 0x024C (size: 0x4)
    TArray<FCullDistanceSizePair> Cull Distances;                                     // 0x0250 (size: 0x10)
    FName Collision Profile Name;                                                     // 0x0260 (size: 0x8)
    TEnumAsByte<ECollisionEnabled::Type> Collision Enabled Enum;                      // 0x0268 (size: 0x1)

    void TODO_SetBBOxOfActor();
    void SetMaxDrawDistance();
    void UserConstructionScript();
    void ReceiveBeginPlay();
    void ExecuteUbergraph_BPP_HISM(int32 EntryPoint);
}; // Size: 0x269

#endif
