#ifndef UE4SS_SDK_GrabKeySequence_TPP_HPP
#define UE4SS_SDK_GrabKeySequence_TPP_HPP

class USequenceDirector_C : public ULevelSequenceDirector
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x0038 (size: 0x8)

    void SequenceEvent__ENTRYPOINTSequenceDirector_0(class USkeletalMeshComponent* SkeletalMeshComponent0);
    void OnNotifyEnd_9BB4ADF046723EC1F8B0AAAEB1953204(FName NotifyName);
    void OnNotifyBegin_9BB4ADF046723EC1F8B0AAAEB1953204(FName NotifyName);
    void OnInterrupted_9BB4ADF046723EC1F8B0AAAEB1953204(FName NotifyName);
    void OnBlendOut_9BB4ADF046723EC1F8B0AAAEB1953204(FName NotifyName);
    void OnCompleted_9BB4ADF046723EC1F8B0AAAEB1953204(FName NotifyName);
    void SkeletalMeshComponent0_Event_0(class USkeletalMeshComponent* SkeletalMeshComponent0);
    void ExecuteUbergraph_SequenceDirector(int32 EntryPoint);
}; // Size: 0x40

#endif
