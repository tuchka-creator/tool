#ifndef UE4SS_SDK_BP_Climb_Ladder_HPP
#define UE4SS_SDK_BP_Climb_Ladder_HPP

class UBP_Climb_Ladder_C : public UMatineeCameraShake
{
}; // Size: 0x1B0

#endif
