#ifndef UE4SS_SDK_ABP_BoneThief_HPP
#define UE4SS_SDK_ABP_BoneThief_HPP

class UABP_BoneThief_C : public UAnimInstance
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x02C0 (size: 0x8)
    FAnimNode_Root AnimGraphNode_Root;                                                // 0x02C8 (size: 0x30)
    FAnimNode_LookAt AnimGraphNode_LookAt_1;                                          // 0x0300 (size: 0x1B0)
    FAnimNode_LookAt AnimGraphNode_LookAt;                                            // 0x04B0 (size: 0x1B0)
    FAnimNode_Slot AnimGraphNode_Slot;                                                // 0x0660 (size: 0x48)
    FAnimNode_ConvertComponentToLocalSpace AnimGraphNode_ComponentToLocalSpace_1;     // 0x06A8 (size: 0x20)
    FAnimNode_MeshSpaceRefPose AnimGraphNode_MeshRefPose;                             // 0x06C8 (size: 0x10)
    FAnimNode_BlendListByBool AnimGraphNode_BlendListByBool;                          // 0x06D8 (size: 0xA0)
    FAnimNode_ConvertLocalToComponentSpace AnimGraphNode_LocalToComponentSpace;       // 0x0778 (size: 0x20)
    FAnimNode_ConvertComponentToLocalSpace AnimGraphNode_ComponentToLocalSpace;       // 0x0798 (size: 0x20)
    FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer;                            // 0x07B8 (size: 0x80)
    FVector Target;                                                                   // 0x0838 (size: 0xC)
    bool IsAttacking;                                                                 // 0x0844 (size: 0x1)

    void AnimGraph(FPoseLink& AnimGraph);
    void BlueprintUpdateAnimation(float DeltaTimeX);
    void ExecuteUbergraph_ABP_BoneThief(int32 EntryPoint);
}; // Size: 0x845

#endif
