#ifndef UE4SS_SDK_BP_BoneThief_HPP
#define UE4SS_SDK_BP_BoneThief_HPP

class ABP_BoneThief_C : public APawn
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x0280 (size: 0x8)
    class USceneComponent* GrabPoint;                                                 // 0x0288 (size: 0x8)
    class UCameraComponent* Camera;                                                   // 0x0290 (size: 0x8)
    class USkeletalMeshComponent* SkeletalMesh;                                       // 0x0298 (size: 0x8)
    class USkeletalMeshComponent* BoneFisher_SM;                                      // 0x02A0 (size: 0x8)
    class USceneComponent* DefaultSceneRoot;                                          // 0x02A8 (size: 0x8)
    float Grab_Alpha_0EB628E7460829FC127E1FA2302B5056;                                // 0x02B0 (size: 0x4)
    TEnumAsByte<ETimelineDirection::Type> Grab__Direction_0EB628E7460829FC127E1FA2302B5056; // 0x02B4 (size: 0x1)
    class UTimelineComponent* Grab;                                                   // 0x02B8 (size: 0x8)
    float Retreat_Alpha_D190BF6F46B7AA9BFB3127AC2C47A4F9;                             // 0x02C0 (size: 0x4)
    TEnumAsByte<ETimelineDirection::Type> Retreat__Direction_D190BF6F46B7AA9BFB3127AC2C47A4F9; // 0x02C4 (size: 0x1)
    class UTimelineComponent* Retreat;                                                // 0x02C8 (size: 0x8)
    float ReachForPlayer_Alpha_6A06713A42BD4081ABBB3688A82317DC;                      // 0x02D0 (size: 0x4)
    TEnumAsByte<ETimelineDirection::Type> ReachForPlayer__Direction_6A06713A42BD4081ABBB3688A82317DC; // 0x02D4 (size: 0x1)
    class UTimelineComponent* ReachForPlayer;                                         // 0x02D8 (size: 0x8)
    float DropPlayer_Alpha_2A9CD8444A595394AE952A8E899ECF21;                          // 0x02E0 (size: 0x4)
    TEnumAsByte<ETimelineDirection::Type> DropPlayer__Direction_2A9CD8444A595394AE952A8E899ECF21; // 0x02E4 (size: 0x1)
    class UTimelineComponent* DropPlayer;                                             // 0x02E8 (size: 0x8)
    FVector StartingLocation;                                                         // 0x02F0 (size: 0xC)
    class ABPCharacter_Demo_C* TargetPlayer;                                          // 0x0300 (size: 0x8)
    FTransform FallingPlayerTransform;                                                // 0x0310 (size: 0x30)
    bool IsFalling;                                                                   // 0x0340 (size: 0x1)
    FVector GrabOffset;                                                               // 0x0344 (size: 0xC)
    FVector GrabLocation;                                                             // 0x0350 (size: 0xC)
    FTransform MeshTransform;                                                         // 0x0360 (size: 0x30)
    class ABPCharacter_Demo_C* ClosestPlayer;                                         // 0x0390 (size: 0x8)
    bool IsAttacking;                                                                 // 0x0398 (size: 0x1)
    class UAudioComponent* ScreamSound;                                               // 0x03A0 (size: 0x8)
    bool ShouldTick;                                                                  // 0x03A8 (size: 0x1)
    bool IsHidden;                                                                    // 0x03A9 (size: 0x1)

    void OnRep_TargetPlayer();
    void OnRep_IsHidden();
    void OnRep_ShouldTick();
    void FindClosestPlayer();
    void FinishEat();
    void DropPlayer__FinishedFunc();
    void DropPlayer__UpdateFunc();
    void ReachForPlayer__FinishedFunc();
    void ReachForPlayer__UpdateFunc();
    void Retreat__FinishedFunc();
    void Retreat__UpdateFunc();
    void Retreat__CloseMouth__EventFunc();
    void Grab__FinishedFunc();
    void Grab__UpdateFunc();
    void OnNotifyEnd_2CDAB9AD40D5645F7919AE9166EAB8F5(FName NotifyName);
    void OnNotifyBegin_2CDAB9AD40D5645F7919AE9166EAB8F5(FName NotifyName);
    void OnInterrupted_2CDAB9AD40D5645F7919AE9166EAB8F5(FName NotifyName);
    void OnBlendOut_2CDAB9AD40D5645F7919AE9166EAB8F5(FName NotifyName);
    void OnCompleted_2CDAB9AD40D5645F7919AE9166EAB8F5(FName NotifyName);
    void OnNotifyEnd_48C95D594520A50A5D41B79FC957FCBC(FName NotifyName);
    void OnNotifyBegin_48C95D594520A50A5D41B79FC957FCBC(FName NotifyName);
    void OnInterrupted_48C95D594520A50A5D41B79FC957FCBC(FName NotifyName);
    void OnBlendOut_48C95D594520A50A5D41B79FC957FCBC(FName NotifyName);
    void OnCompleted_48C95D594520A50A5D41B79FC957FCBC(FName NotifyName);
    void Attack(class ABPCharacter_Demo_C* TargetPlayer);
    void ReceiveTick(float DeltaSeconds);
    void ResetAttack();
    void ReceiveBeginPlay();
    void HideBoneThief();
    void GrabPlayer();
    void MC_Scream();
    void MC_Breathe();
    void MC_Montage();
    void MC_SlowBreathe();
    void Apply Costume To Skeletal Mesh(class ABPCharacter_Demo_C* InTargetPlayer);
    void ExecuteUbergraph_BP_BoneThief(int32 EntryPoint);
}; // Size: 0x3AA

#endif
