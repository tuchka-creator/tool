#ifndef UE4SS_SDK_BP_DivingHelmet_HPP
#define UE4SS_SDK_BP_DivingHelmet_HPP

class ABP_DivingHelmet_C : public AActor
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x0220 (size: 0x8)
    class USpotLightComponent* SpotLight;                                             // 0x0228 (size: 0x8)
    class USpringArmComponent* SpringArm;                                             // 0x0230 (size: 0x8)
    class UStaticMeshComponent* StaticMesh;                                           // 0x0238 (size: 0x8)
    class USceneComponent* DefaultSceneRoot;                                          // 0x0240 (size: 0x8)

    void UpdateLight(class AActor* Player);
    void ExecuteUbergraph_BP_DivingHelmet(int32 EntryPoint);
}; // Size: 0x248

#endif
