#ifndef UE4SS_SDK_BP_Ceiling_Gate_HPP
#define UE4SS_SDK_BP_Ceiling_Gate_HPP

class ABP_Ceiling_Gate_C : public AActor
{
    class UStaticMeshComponent* Frame;                                                // 0x0220 (size: 0x8)
    class UStaticMeshComponent* Gate;                                                 // 0x0228 (size: 0x8)
    class UPhysicsConstraintComponent* PhysicsConstraint;                             // 0x0230 (size: 0x8)
    class USceneComponent* DefaultSceneRoot;                                          // 0x0238 (size: 0x8)
    bool IsOpen;                                                                      // 0x0240 (size: 0x1)

    void OnRep_IsOpen();
}; // Size: 0x241

#endif
