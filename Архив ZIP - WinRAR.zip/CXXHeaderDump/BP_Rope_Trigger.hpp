#ifndef UE4SS_SDK_BP_Rope_Trigger_HPP
#define UE4SS_SDK_BP_Rope_Trigger_HPP

class ABP_Rope_Trigger_C : public ATriggerBox
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x0228 (size: 0x8)
    class USceneComponent* Breakpoint;                                                // 0x0230 (size: 0x8)
    int32 TestingIndex;                                                               // 0x0238 (size: 0x4)
    class ABP_FallingPlank_C* FirstPlank;                                             // 0x0240 (size: 0x8)
    class ABP_FallingPlank_C* FallingWeight;                                          // 0x0248 (size: 0x8)
    class ADestructibleActor* Glass;                                                  // 0x0250 (size: 0x8)
    class ABP_FallingPlank_C* SecondPlank;                                            // 0x0258 (size: 0x8)
    bool bSnapRope;                                                                   // 0x0260 (size: 0x1)
    class AActor* GlassBlockingVolume;                                                // 0x0268 (size: 0x8)

    void OnRep_bSnapRope();
    void SnapRope();
    void BreakRope(class AFancyCharacter* Player);
    void DestroyBlockingVolume();
    void ExecuteUbergraph_BP_Rope_Trigger(int32 EntryPoint);
}; // Size: 0x270

#endif
