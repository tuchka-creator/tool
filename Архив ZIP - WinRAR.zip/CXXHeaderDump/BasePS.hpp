#ifndef UE4SS_SDK_BasePS_HPP
#define UE4SS_SDK_BasePS_HPP

class ABasePS_C : public AFancyPlayerState
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x0358 (size: 0x8)
    class USceneComponent* DefaultSceneRoot;                                          // 0x0360 (size: 0x8)
    FS_PlayerConnectionInfo PlayerConnection;                                         // 0x0368 (size: 0x8)
    FS_UserProfile UserInfo;                                                          // 0x0370 (size: 0x18)
    TArray<FBPUniqueNetId> BlockedPlayersList;                                        // 0x0388 (size: 0x10)

    void Load_Player_Headset();
    void OnRep_PlayerConnection();
    void OnRep_UserInfo();
    void OnRep_Player_UserProfile_OR();
    void OnRep_Player_ConnectionInfo_OR();
    void Load_Player_UserProfile();
    void Load_Player_ConnectionInfo(bool Client_ReadyStatus);
    void SR_Update_Player_UserProfile(FS_UserProfile Player_UserProfile);
    void ReceiveBeginPlay();
    void OC_Init();
    void SR_Update_Player_ConnectionInfo(FS_PlayerConnectionInfo Player_ConnectionInfo);
    void SR_LoadHeadset(TEnumAsByte<E_HeadsetType::Type> HeadsetType, int32 PlayerId);
    void ExecuteUbergraph_BasePS(int32 EntryPoint);
}; // Size: 0x398

#endif
