#ifndef UE4SS_SDK_BP_Ragdoll_HPP
#define UE4SS_SDK_BP_Ragdoll_HPP

class ABP_Ragdoll_C : public AActor
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x0220 (size: 0x8)
    class USkeletalMeshComponent* Mesh;                                               // 0x0228 (size: 0x8)
    class USceneComponent* DefaultSceneRoot;                                          // 0x0230 (size: 0x8)
    class UCostume* Costume;                                                          // 0x0238 (size: 0x8)

    void OnNotifyEnd_7CA886504E74A26B7124BE88FF3FEBF5(FName NotifyName);
    void OnNotifyBegin_7CA886504E74A26B7124BE88FF3FEBF5(FName NotifyName);
    void OnInterrupted_7CA886504E74A26B7124BE88FF3FEBF5(FName NotifyName);
    void OnBlendOut_7CA886504E74A26B7124BE88FF3FEBF5(FName NotifyName);
    void OnCompleted_7CA886504E74A26B7124BE88FF3FEBF5(FName NotifyName);
    void ReceiveBeginPlay();
    void ExecuteUbergraph_BP_Ragdoll(int32 EntryPoint);
}; // Size: 0x240

#endif
