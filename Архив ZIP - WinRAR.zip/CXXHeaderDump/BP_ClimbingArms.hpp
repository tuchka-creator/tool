#ifndef UE4SS_SDK_BP_ClimbingArms_HPP
#define UE4SS_SDK_BP_ClimbingArms_HPP

class ABP_ClimbingArms_C : public AActor
{
    class USkeletalMeshComponent* SkeletalMesh;                                       // 0x0220 (size: 0x8)
    class USpringArmComponent* SpringArm;                                             // 0x0228 (size: 0x8)
    class UCameraComponent* Camera;                                                   // 0x0230 (size: 0x8)
    class USceneComponent* Scene;                                                     // 0x0238 (size: 0x8)

}; // Size: 0x240

#endif
