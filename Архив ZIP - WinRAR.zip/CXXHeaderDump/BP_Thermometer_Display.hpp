#ifndef UE4SS_SDK_BP_Thermometer_Display_HPP
#define UE4SS_SDK_BP_Thermometer_Display_HPP

class ABP_Thermometer_Display_C : public AActor
{
    class USceneComponent* DefaultSceneRoot;                                          // 0x0220 (size: 0x8)
    FString Value;                                                                    // 0x0228 (size: 0x10)
    bool bOn;                                                                         // 0x0238 (size: 0x1)
    FLinearColor Colour;                                                              // 0x023C (size: 0x10)
    float Brightness;                                                                 // 0x024C (size: 0x4)
    TArray<class UStaticMeshComponent*> SegmentArray;                                 // 0x0250 (size: 0x10)
    float Background Opacity;                                                         // 0x0260 (size: 0x4)
    TEnumAsByte<Enum_SegmentDisplayType::Type> Segment Type;                          // 0x0264 (size: 0x1)
    int32 Length;                                                                     // 0x0268 (size: 0x4)
    float Distance;                                                                   // 0x026C (size: 0x4)
    bool UsingFOV;                                                                    // 0x0270 (size: 0x1)

    void SetDisplayValue(class UMeshComponent* Mesh, FString Value);
    void MaterialSettings(class UMeshComponent* Mesh);
    void SetSegmentType(class UPrimitiveComponent* Mesh);
    void SetLength();
    void Update();
    void Construct Update();
    void Construct Core();
    void UserConstructionScript();
}; // Size: 0x271

#endif
