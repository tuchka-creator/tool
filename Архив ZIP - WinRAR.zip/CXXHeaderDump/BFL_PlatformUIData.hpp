#ifndef UE4SS_SDK_BFL_PlatformUIData_HPP
#define UE4SS_SDK_BFL_PlatformUIData_HPP

class UBFL_PlatformUIData_C : public UBlueprintFunctionLibrary
{

    void GetRichTextImage(FText DTRow, class UObject* __WorldContext, FText& RichText);
    void GetInputPlatform(class UObject* __WorldContext, FString& Platform);
    void GetKeybindByInputName(TEnumAsByte<E_InputActions::Type> InputName, class UObject* __WorldContext, FText& Name, FString& Platform);
    void GetInputActionKeyName_DEPRECATED(const FName ActionName, class UObject* __WorldContext, FText& Name);
    void GetRichTextInputImage(TEnumAsByte<E_InputActions::Type> InputName, class UObject* __WorldContext, FText& RichText);
}; // Size: 0x28

#endif
