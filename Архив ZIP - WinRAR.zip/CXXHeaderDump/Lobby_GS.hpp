#ifndef UE4SS_SDK_Lobby_GS_HPP
#define UE4SS_SDK_Lobby_GS_HPP

class ALobby_GS_C : public AGameState
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x0290 (size: 0x8)
    class USceneComponent* DefaultSceneRoot;                                          // 0x0298 (size: 0x8)
    FText CurrentGameMode;                                                            // 0x02A0 (size: 0x18)
    TArray<FS_ConnectedPlayer> PlayersConnected;                                      // 0x02B8 (size: 0x10)
    FText ServerName;                                                                 // 0x02C8 (size: 0x18)
    bool ReadyForLaunch?;                                                             // 0x02E0 (size: 0x1)
    bool Launching?;                                                                  // 0x02E1 (size: 0x1)
    FName CurrentLevel;                                                               // 0x02E4 (size: 0x8)
    FST_UI_Mission CurrentMissionData;                                                // 0x02F0 (size: 0x98)
    FString LobbyCode;                                                                // 0x0388 (size: 0x10)
    int32 MaxPlayers;                                                                 // 0x0398 (size: 0x4)

    void OnRep_MaxPlayers();
    void OnRep_CurrentMissionData();
    void Update_Lobby_VoiceChat(bool CanTalk);
    void Update_Lobby_Launchevent(bool LaunchingGame?);
    void Set_CurrentMap();
    void OnRep_Current_GameMode();
    void UpdateLobbyFromGS();
    void Reset_Player_ReadyStatus();
    void Update_Lobby_PlayerList();
    void Update_Host_ReadyUpButton(FText Text, bool WarningState?);
    void Update_Lobby_StatusIndicator(ESlateVisibility CircularThrobber_Visibility, FText LobbyStatus_Text);
    void OnRep_ReadyForLaunch?();
    void OnRep_Launching?();
    void Check_EveryoneReady?(bool& CanStart);
    void OnRep_ServerName();
    void Update_ServerName();
    void OnRep_PlayersConnected();
    void Update_ConnectedPlayers_Array();
    void OnFailure_BAB015064C915C7C1CCCA3AAB0A02F3B();
    void OnSuccess_BAB015064C915C7C1CCCA3AAB0A02F3B();
    void UpdateCanJoin(bool CanJoin);
    void ReceiveBeginPlay();
    void ExecuteUbergraph_Lobby_GS(int32 EntryPoint);
}; // Size: 0x39C

#endif
