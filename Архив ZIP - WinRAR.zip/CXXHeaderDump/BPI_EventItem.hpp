#ifndef UE4SS_SDK_BPI_EventItem_HPP
#define UE4SS_SDK_BPI_EventItem_HPP

class IBPI_EventItem_C : public IInterface
{

    void ToggleEvent(bool Enable);
}; // Size: 0x28

#endif
