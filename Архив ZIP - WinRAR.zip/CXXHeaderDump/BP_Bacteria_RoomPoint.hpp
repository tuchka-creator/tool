#ifndef UE4SS_SDK_BP_Bacteria_RoomPoint_HPP
#define UE4SS_SDK_BP_Bacteria_RoomPoint_HPP

class ABP_Bacteria_RoomPoint_C : public AActor
{
    class USphereComponent* Sphere;                                                   // 0x0220 (size: 0x8)
    class USceneComponent* DefaultSceneRoot;                                          // 0x0228 (size: 0x8)

}; // Size: 0x230

#endif
