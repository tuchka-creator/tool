#ifndef UE4SS_SDK_BP_DroppedItem_FlareGun_HPP
#define UE4SS_SDK_BP_DroppedItem_FlareGun_HPP

class ABP_DroppedItem_FlareGun_C : public ABP_DroppedItem_C
{
}; // Size: 0x269

#endif
