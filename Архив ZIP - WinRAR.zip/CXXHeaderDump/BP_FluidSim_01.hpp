#ifndef UE4SS_SDK_BP_FluidSim_01_HPP
#define UE4SS_SDK_BP_FluidSim_01_HPP

class ABP_FluidSim_01_C : public AActor
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x0220 (size: 0x8)
    class UJumpFlood_Component2D_C* JumpFlood_Component2D;                            // 0x0228 (size: 0x8)
    class USceneCaptureComponent2D* SceneCaptureComponent2D;                          // 0x0230 (size: 0x8)
    class UWaveFoamSimComponent_C* WaveFoamSimComponent;                              // 0x0238 (size: 0x8)
    class UShallowWaterSimComponent_C* ShallowWaterSimComponent;                      // 0x0240 (size: 0x8)
    class USceneComponent* DefaultSceneRoot;                                          // 0x0248 (size: 0x8)
    class UMaterialInstanceDynamic* RippleSimMID;                                     // 0x0250 (size: 0x8)
    class UMaterialInstanceDynamic* RenderNormalsMID;                                 // 0x0258 (size: 0x8)
    class UMaterialInstanceDynamic* DisplayMID;                                       // 0x0260 (size: 0x8)
    class UMaterialInstanceDynamic* DisplayBottomMID;                                 // 0x0268 (size: 0x8)
    class UMaterialInstanceDynamic* CrossSectionMID;                                  // 0x0270 (size: 0x8)
    class UMaterialInstanceDynamic* Composite DistanceField MID;                      // 0x0278 (size: 0x8)
    TArray<class UTextureRenderTarget2D*> RippleRTs;                                  // 0x0280 (size: 0x10)
    bool Show Simulation Mesh;                                                        // 0x0290 (size: 0x1)
    class UMaterialInterface* Display Material;                                       // 0x0298 (size: 0x8)
    TEnumAsByte<FluidSimSolverMode::Type> Solver;                                     // 0x02A0 (size: 0x1)
    float Virtual FPS;                                                                // 0x02A4 (size: 0x4)
    int32 Passes;                                                                     // 0x02A8 (size: 0x4)
    float TimeAccumulator;                                                            // 0x02AC (size: 0x4)
    float FixedStep;                                                                  // 0x02B0 (size: 0x4)
    float Damping;                                                                    // 0x02B4 (size: 0x4)
    bool Enabled;                                                                     // 0x02B8 (size: 0x1)
    float Simulation World Size;                                                      // 0x02BC (size: 0x4)
    int32 Resolution;                                                                 // 0x02C0 (size: 0x4)
    TEnumAsByte<FluidBoundary::Type> Boundary Condition;                              // 0x02C4 (size: 0x1)
    float Travel Speed;                                                               // 0x02C8 (size: 0x4)
    class UTextureRenderTarget2D* NormalRT;                                           // 0x02D0 (size: 0x8)
    FVector CutPos;                                                                   // 0x02D8 (size: 0xC)
    FVector PrevLoc;                                                                  // 0x02E4 (size: 0xC)
    FVector PrecLoc2;                                                                 // 0x02F0 (size: 0xC)
    FVector PrevOffset;                                                               // 0x02FC (size: 0xC)
    FVector PrevOffset2;                                                              // 0x0308 (size: 0xC)
    FVector GridCenter;                                                               // 0x0314 (size: 0xC)
    class UTextureRenderTarget2D* TempRT;                                             // 0x0320 (size: 0x8)
    class UTextureRenderTarget2D* ForcesRT;                                           // 0x0328 (size: 0x8)
    float ApplyForces;                                                                // 0x0330 (size: 0x4)
    int32 Renders Per Frame;                                                          // 0x0334 (size: 0x4)
    bool Show Cross Section;                                                          // 0x0338 (size: 0x1)
    bool Perf Test Mode;                                                              // 0x0339 (size: 0x1)
    class UTextureRenderTarget2D* PerfRT;                                             // 0x0340 (size: 0x8)
    TArray<FFluidForceImpulsePerInstanceData> ImpulseForces;                          // 0x0348 (size: 0x10)
    TMap<class UActorComponent*, class FFluidForceDynamicPerInstanceData> DynamicForces; // 0x0358 (size: 0x50)
    TMap<class UMaterialInterface*, class UMaterialInstanceDynamic*> ForceParentAndMIDMap; // 0x03A8 (size: 0x50)
    class UStaticMeshComponent* Fluid Display Mesh;                                   // 0x03F8 (size: 0x8)
    class UStaticMeshComponent* Cross Section Mesh;                                   // 0x0400 (size: 0x8)
    float FluidSizeSquared;                                                           // 0x0408 (size: 0x4)
    bool LocalPawnRef;                                                                // 0x040C (size: 0x1)
    bool Debug Text;                                                                  // 0x040D (size: 0x1)
    int32 Pawn Check Every N Frames;                                                  // 0x0410 (size: 0x4)
    TMap<class UActorComponent*, class FFluidForceDynamicPerInstanceData> ProjectileForces; // 0x0418 (size: 0x50)
    bool Follow Player ;                                                              // 0x0468 (size: 0x1)
    int32 Frames Since Last Active Force;                                             // 0x046C (size: 0x4)
    float Default Water Depth;                                                        // 0x0470 (size: 0x4)
    bool Fixed Time Step;                                                             // 0x0474 (size: 0x1)
    int32 Frames until Simulation Idle;                                               // 0x0478 (size: 0x4)
    class UTexture* LandscapeWaterTexture;                                            // 0x0480 (size: 0x8)
    bool Simulate Wave Foam;                                                          // 0x0488 (size: 0x1)
    int32 WaveFoamDiffuseIdx;                                                         // 0x048C (size: 0x4)
    float Wave Sim World Size;                                                        // 0x0490 (size: 0x4)
    int32 Wave Foam Resolution;                                                       // 0x0494 (size: 0x4)
    float Fading;                                                                     // 0x0498 (size: 0x4)
    float Wave Time Offset;                                                           // 0x049C (size: 0x4)
    class UTextureRenderTarget2D* DepthCaptureRT;                                     // 0x04A0 (size: 0x8)
    class UTextureRenderTarget2D* EdgeMaskRT;                                         // 0x04A8 (size: 0x8)
    class UTextureRenderTarget2D* JumpFloodA;                                         // 0x04B0 (size: 0x8)
    class UTextureRenderTarget2D* JumpFloodB;                                         // 0x04B8 (size: 0x8)
    bool Generate SceneCapture DistanceField;                                         // 0x04C0 (size: 0x1)
    class AWaterBody* WaterBody;                                                      // 0x04C8 (size: 0x8)
    class UMaterialInstanceDynamic* EdgeMaskMID;                                      // 0x04D0 (size: 0x8)
    class UMaterialInstanceDynamic* ComputeDistanceMID;                               // 0x04D8 (size: 0x8)
    class UTextureRenderTarget2D* VoronoiDistance_RefCopy;                            // 0x04E0 (size: 0x8)
    TEnumAsByte<FluidTerrainModes::Type> Terrain Mode;                                // 0x04E8 (size: 0x1)
    class ALandscape* Landscape;                                                      // 0x04F0 (size: 0x8)
    float Wave Threshold;                                                             // 0x04F8 (size: 0x4)

    void Get Frames Since Last Active Force();
    void Clear Sim from Waterbody MIDs();
    void Remove Projectile Force(class UActorComponent* Component);
    void Register Projectile Force(FFluidForceDynamic Dynamic Fluid Force, class USceneComponent* Tracked Component);
    void GetPlayerPawnForces();
    void Validate RTs(bool& RTs All Valid);
    void Set Waterbody MID Params();
    void GetLocalPawn(class APawn*& Pawn);
    void Draw Dynamic Force(class UCanvas*& Canvas, FVector2D& Canvas Size, FFluidForceDynamicPerInstanceData& Dynamic Force Settings);
    void Remove Dynamic Force(class UActorComponent* Component);
    void Register Dynamic Force(FFluidForceDynamic Dynamic Fluid Force, class USceneComponent* Tracked Component, float WaterLevel);
    void Update Dynamic Forces();
    void Draw Impulse Force(class UCanvas* Canvas, FVector2D Canvas Size, FFluidForceImpulsePerInstanceData Impulse Settings);
    void Update Impulse Lifetimes();
    void Apply Fluid Force Impulse(FFluidForceImpulse Impulse Settings);
    void Get LandscapeWaterInfo();
    void Get Force MID(class UMaterialInterface*& Parent, class UMaterialInstanceDynamic*& Mid);
    void GridMovement();
    void Setup SimMID and MPC Values();
    void SetupDisplayMIDs();
    void Convert Force Position(FVector Force Location, float Sine Bob, FVector& UV Location);
    void Cycle Render Targets(class UTextureRenderTarget2D*& Current Target);
    void UserConstructionScript();
    void ReceiveBeginPlay();
    void ReceiveTick(float DeltaSeconds);
    void Clear RTs();
    void Allocate RTs();
    void ReCheckScalability();
    void Release RTs();
    void FluidGridDebug();
    void Get Wave Spectrum();
    void Initialize In Editor();
    void Tick Custom();
    void Capture Height and DF();
    void ExecuteUbergraph_BP_FluidSim_01(int32 EntryPoint);
}; // Size: 0x4FC

#endif
