#ifndef UE4SS_SDK_Lobby_PlayerList_Item_HPP
#define UE4SS_SDK_Lobby_PlayerList_Item_HPP

class ULobby_PlayerList_Item_C : public UUserWidget
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x0270 (size: 0x8)
    class USizeBox* HostIndicator;                                                    // 0x0278 (size: 0x8)
    class UButton* Kick_Btn;                                                          // 0x0280 (size: 0x8)
    class UTextBlock* KickButton_Text;                                                // 0x0288 (size: 0x8)
    class UImage* Player_Avatar_Image;                                                // 0x0290 (size: 0x8)
    class UTextBlock* Player_ReadyStatus;                                             // 0x0298 (size: 0x8)
    class UTextBlock* Player_Username_text;                                           // 0x02A0 (size: 0x8)
    class UImage* Speaker_Image;                                                      // 0x02A8 (size: 0x8)
    FS_ConnectedPlayer ConnectedPlayer;                                               // 0x02B0 (size: 0x58)
    FSlateColor Ready_Color;                                                          // 0x0308 (size: 0x28)
    FSlateColor NotReady_Color;                                                       // 0x0330 (size: 0x28)

    void Set_Speaking(bool IsSpeaking);
    void KickPlayer();
    void SetUp();
    void Set_Avatar();
    void Set_Username();
    void Set_KickButton();
    void Set_HostIndicator();
    void Set_ReadyStatus();
    void CanClose();
    void Construct();
    void BndEvt__WB_Lobby_PlayerList_Item_Kick_Btn_K2Node_ComponentBoundEvent_0_OnButtonClickedEvent__DelegateSignature();
    void ExecuteUbergraph_Lobby_PlayerList_Item(int32 EntryPoint);
}; // Size: 0x358

#endif
