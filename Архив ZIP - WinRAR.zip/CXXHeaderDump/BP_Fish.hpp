#ifndef UE4SS_SDK_BP_Fish_HPP
#define UE4SS_SDK_BP_Fish_HPP

class ABP_Fish_C : public ACharacter
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x04C0 (size: 0x8)
    class USceneComponent* EyeSight;                                                  // 0x04C8 (size: 0x8)
    class USphereComponent* KillPlayer;                                               // 0x04D0 (size: 0x8)
    class UAudioComponent* Audio;                                                     // 0x04D8 (size: 0x8)
    bool ShouldMove;                                                                  // 0x04E0 (size: 0x1)
    bool CanAttack;                                                                   // 0x04E1 (size: 0x1)
    bool IsTargetting;                                                                // 0x04E2 (size: 0x1)
    float AttackOffset;                                                               // 0x04E4 (size: 0x4)
    class ABP_RowBoat_C* TargetPlayer;                                                // 0x04E8 (size: 0x8)
    float MovementSpeed;                                                              // 0x04F0 (size: 0x4)

    void CanSeePlayer(class ABPCharacter_Demo_C* Target, bool& CanSee);
    void OnRep_IsTargetting();
    void StopMovement();
    void LookAtEntity(class ABPCharacter_Demo_C* Target);
    void MC_KillSound();
    void Jumpscare(class ABPCharacter_Demo_C* Player);
    void PlayFlip();
    void MC_KillAnimation(class ABPCharacter_Demo_C* Target);
    void BndEvt__BP_Hound_KillPlayer_K2Node_ComponentBoundEvent_0_ComponentBeginOverlapSignature__DelegateSignature(class UPrimitiveComponent* OverlappedComponent, class AActor* OtherActor, class UPrimitiveComponent* OtherComp, int32 OtherBodyIndex, bool bFromSweep, const FHitResult& SweepResult);
    void BndEvt__BP_Hound_KillPlayer_K2Node_ComponentBoundEvent_1_ComponentEndOverlapSignature__DelegateSignature(class UPrimitiveComponent* OverlappedComponent, class AActor* OtherActor, class UPrimitiveComponent* OtherComp, int32 OtherBodyIndex);
    void AttackPlayer(class ABPCharacter_Demo_C* Player);
    void StartSound();
    void MC_Stop(float Delay);
    void StopSound();
    void ReceiveBeginPlay();
    void ReceiveTick(float DeltaSeconds);
    void ExecuteUbergraph_BP_Fish(int32 EntryPoint);
}; // Size: 0x4F4

#endif
