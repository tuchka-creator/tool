#ifndef UE4SS_SDK_Lobby_JoinWithCode_Modal_HPP
#define UE4SS_SDK_Lobby_JoinWithCode_Modal_HPP

class ULobby_JoinWithCode_Modal_C : public UUserWidget
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x0270 (size: 0x8)
    class UUI_Menu_Button_ProperFocus_C* Cancel;                                      // 0x0278 (size: 0x8)
    class UTextBlock* ErrorMessage;                                                   // 0x0280 (size: 0x8)
    class UImage* Image_shadow;                                                       // 0x0288 (size: 0x8)
    class UUI_Menu_Button_ProperFocus_C* Join;                                        // 0x0290 (size: 0x8)
    class UEditableTextBox* LobbyCode_TextBox;                                        // 0x0298 (size: 0x8)
    class UWidgetSwitcher* MessageTypeSwitcher;                                       // 0x02A0 (size: 0x8)
    class UTextBlock* OkMessage;                                                      // 0x02A8 (size: 0x8)
    class UCircularThrobber* Throbber;                                                // 0x02B0 (size: 0x8)
    class UTextBlock* Title;                                                          // 0x02B8 (size: 0x8)
    FLobby_JoinWithCode_Modal_CCompleteCallback CompleteCallback;                     // 0x02C0 (size: 0x10)
    void CompleteCallback();
    float WaitUntilTime;                                                              // 0x02D0 (size: 0x4)
    FText SearchingLobbyCode;                                                         // 0x02D8 (size: 0x18)
    class UBP_FindSessionFlow_C* CurrentSearchFlow;                                   // 0x02F0 (size: 0x8)
    bool Cancelled;                                                                   // 0x02F8 (size: 0x1)
    bool bIsCleaningLobbyCodeInput;                                                   // 0x02F9 (size: 0x1)
    FBlueprintSessionResult CurrentResult;                                            // 0x0300 (size: 0x108)

    class UWidget* CustomNavigation_TryJoin(EUINavigation Navigation);
    void CleanUpLobbyCodeInput(const FText& InText);
    void ShowMessage(FText Text, bool bIsError);
    void RefreshMessageAndJoinButton(class UBP_FindSessionFlow_C* FindSessionResults);
    void CreateFilters(TArray<FSessionsSearchSetting>& Array);
    FEventReply OnFocusReceived(FGeometry MyGeometry, FFocusEvent InFocusEvent);
    void BndEvt__Lobby_JoinWithCode_Modal_LobbyCode_TextBox_K2Node_ComponentBoundEvent_2_OnEditableTextBoxChangedEvent__DelegateSignature(const FText& Text);
    void BndEvt__Lobby_JoinWithCode_Modal_Join_K2Node_ComponentBoundEvent_0_OnClick__DelegateSignature();
    void BndEvt__Lobby_JoinWithCode_Modal_Cancel_K2Node_ComponentBoundEvent_1_OnClick__DelegateSignature();
    void BindCustomModalCompleteCallback(const FBindCustomModalCompleteCallbackCompleteCallback& CompleteCallback);
    void ExecuteUbergraph_Lobby_JoinWithCode_Modal(int32 EntryPoint);
    void CompleteCallback__DelegateSignature();
}; // Size: 0x408

#endif
