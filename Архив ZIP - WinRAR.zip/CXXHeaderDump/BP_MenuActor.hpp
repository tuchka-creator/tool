#ifndef UE4SS_SDK_BP_MenuActor_HPP
#define UE4SS_SDK_BP_MenuActor_HPP

class ABP_MenuActor_C : public APawn
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x0280 (size: 0x8)
    class UWidgetComponent* Widget;                                                   // 0x0288 (size: 0x8)
    class UWidgetComponent* Keyboard;                                                 // 0x0290 (size: 0x8)
    class UMotionControllerComponent* MotionController;                               // 0x0298 (size: 0x8)
    class UMotionControllerComponent* MotionController1;                              // 0x02A0 (size: 0x8)
    class UCameraComponent* Camera;                                                   // 0x02A8 (size: 0x8)
    class USceneComponent* Scene;                                                     // 0x02B0 (size: 0x8)
    class UWidgetInteractionComponent* WidgetInteraction1;                            // 0x02B8 (size: 0x8)
    class UWidgetInteractionComponent* WidgetInteraction;                             // 0x02C0 (size: 0x8)
    float SmoothMove_Alpha_71DC4F2C4FC90E5CAD63AD8598EB1D51;                          // 0x02C8 (size: 0x4)
    TEnumAsByte<ETimelineDirection::Type> SmoothMove__Direction_71DC4F2C4FC90E5CAD63AD8598EB1D51; // 0x02CC (size: 0x1)
    class UTimelineComponent* SmoothMove;                                             // 0x02D0 (size: 0x8)
    class UWBP_Keyboard_Basic_C* WBP_Keyboard_Basic;                                  // 0x02D8 (size: 0x8)
    FTransform MenuTransform;                                                         // 0x02E0 (size: 0x30)
    class UNiagaraComponent* LeftBeam;                                                // 0x0310 (size: 0x8)
    class UNiagaraComponent* RightBeam;                                               // 0x0318 (size: 0x8)
    FTransform StartTransform;                                                        // 0x0320 (size: 0x30)
    class ABP_VRMenu_C* Menu;                                                         // 0x0350 (size: 0x8)
    bool IsHeldLeft;                                                                  // 0x0358 (size: 0x1)
    bool IsHeldRight;                                                                 // 0x0359 (size: 0x1)

    void Update Beam();
    void ToggleWidgetInteraction();
    void RefreshFocus();
    void SmoothMove__FinishedFunc();
    void SmoothMove__UpdateFunc();
    void InpActEvt_Use_K2Node_InputActionEvent_4(FKey Key);
    void InpActEvt_Use_K2Node_InputActionEvent_3(FKey Key);
    void InpActEvt_Secondary_K2Node_InputActionEvent_2(FKey Key);
    void InpActEvt_Secondary_K2Node_InputActionEvent_1(FKey Key);
    void InpActEvt_Interact_K2Node_InputActionEvent_0(FKey Key);
    void ToggleKeyboard(bool Hide);
    void ReceiveBeginPlay();
    void CloseSettings();
    void OpenSettings();
    void MoveTo();
    void CloseWarning();
    void HeldLeft(bool Down);
    void HeldRight(bool Down);
    void SetMainMenuShakeActive(bool Active);
    void ExecuteUbergraph_BP_MenuActor(int32 EntryPoint);
}; // Size: 0x35A

#endif
