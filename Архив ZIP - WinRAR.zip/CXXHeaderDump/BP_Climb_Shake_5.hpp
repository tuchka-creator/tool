#ifndef UE4SS_SDK_BP_Climb_Shake_5_HPP
#define UE4SS_SDK_BP_Climb_Shake_5_HPP

class UBP_Climb_Shake_5_C : public UMatineeCameraShake
{
}; // Size: 0x1B0

#endif
