#ifndef UE4SS_SDK_BP_Autosave_Flow_HPP
#define UE4SS_SDK_BP_Autosave_Flow_HPP

class UBP_Autosave_Flow_C : public UFancyUserFlow
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x00A8 (size: 0x8)
    class UWidget* PrevFocusedWidget;                                                 // 0x00B0 (size: 0x8)

    void Run();
    void PrepareModal(class UUserWidget* Modal);
    void OnCompleteModal(class UUserWidget* Modal);
    void ExecuteUbergraph_BP_Autosave_Flow(int32 EntryPoint);
}; // Size: 0xB8

#endif
