#ifndef UE4SS_SDK_BP_Thermometer_HPP
#define UE4SS_SDK_BP_Thermometer_HPP

class ABP_Thermometer_C : public ABP_Item_C
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x0258 (size: 0x8)
    class USceneComponent* Scene1;                                                    // 0x0260 (size: 0x8)
    class ABP_Thermometer_Display_C* NumberDisplay;                                   // 0x0268 (size: 0x8)
    int32 Temperature;                                                                // 0x0270 (size: 0x4)
    bool IsUsingFOV;                                                                  // 0x0274 (size: 0x1)

    void Has Spawned Display(bool& HasSpawned);
    void SetMaterial(bool EnabledFOV);
    void OnRep_Temperature();
    void ReceiveBeginPlay();
    void ReceiveDestroyed();
    void ExecuteUbergraph_BP_Thermometer(int32 EntryPoint);
}; // Size: 0x275

#endif
