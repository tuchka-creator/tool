#ifndef UE4SS_SDK_BP_Item_AlmondWater_HPP
#define UE4SS_SDK_BP_Item_AlmondWater_HPP

class ABP_Item_AlmondWater_C : public ABP_Item_C
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x0258 (size: 0x8)
    class UStaticMeshComponent* Cylinder;                                             // 0x0260 (size: 0x8)
    class UStaticMeshComponent* AWC_Locker;                                           // 0x0268 (size: 0x8)
    class UStaticMeshComponent* AWC_Gate;                                             // 0x0270 (size: 0x8)
    float OpenCan_Alpha_15A195AB4DCA7E5C5215DEB67191AA92;                             // 0x0278 (size: 0x4)
    TEnumAsByte<ETimelineDirection::Type> OpenCan__Direction_15A195AB4DCA7E5C5215DEB67191AA92; // 0x027C (size: 0x1)
    class UTimelineComponent* OpenCan;                                                // 0x0280 (size: 0x8)
    bool HalloweenMat;                                                                // 0x0288 (size: 0x1)
    bool EnabledFOV;                                                                  // 0x0289 (size: 0x1)

    void SetMaterial(bool EnabledFOV);
    void OpenCan__FinishedFunc();
    void OpenCan__UpdateFunc();
    void OnNotifyEnd_3881A8424F905F4C29433AB5756CB3DA(FName NotifyName);
    void OnNotifyBegin_3881A8424F905F4C29433AB5756CB3DA(FName NotifyName);
    void OnInterrupted_3881A8424F905F4C29433AB5756CB3DA(FName NotifyName);
    void OnBlendOut_3881A8424F905F4C29433AB5756CB3DA(FName NotifyName);
    void OnCompleted_3881A8424F905F4C29433AB5756CB3DA(FName NotifyName);
    void PlayAnimation();
    void UseItem();
    void Damage_SERVER(class UObject* Target, class AFancyCharacter* Character);
    void ToggleEvent(bool Enable);
    void OnEventLoaded(uint8 EventType);
    void ExecuteUbergraph_BP_Item_AlmondWater(int32 EntryPoint);
}; // Size: 0x28A

#endif
