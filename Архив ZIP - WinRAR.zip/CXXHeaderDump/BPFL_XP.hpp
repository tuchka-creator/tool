#ifndef UE4SS_SDK_BPFL_XP_HPP
#define UE4SS_SDK_BPFL_XP_HPP

class UBPFL_XP_C : public UBlueprintFunctionLibrary
{

    void CalculateXPNeededForNextLevel(int32 CurrentXP, class UObject* __WorldContext, int32& CurrentLevel, int32& CurrentLevelBaseXP, int32& NextLevelXP, int32& XPNeeded);
    void LoadLevelFromXP(int32 XP, class UObject* __WorldContext, int32& Level, int32& VisualLevel);
    void LoadEXP(class UObject* __WorldContext, float& Exp);
    void AddEXP(float XP, class UObject* __WorldContext);
}; // Size: 0x28

#endif
