#ifndef UE4SS_SDK_BP_Ceiling_2Light_2_level0_HPP
#define UE4SS_SDK_BP_Ceiling_2Light_2_level0_HPP

class ABP_Ceiling_2Light_2_level0_C : public AActor
{
    class USpotLightComponent* SpotLight1;                                            // 0x0220 (size: 0x8)
    class USpotLightComponent* SpotLight;                                             // 0x0228 (size: 0x8)
    class USceneComponent* DefaultSceneRoot;                                          // 0x0230 (size: 0x8)

}; // Size: 0x238

#endif
