#ifndef UE4SS_SDK_BP_Animation_HPP
#define UE4SS_SDK_BP_Animation_HPP

class ABP_Animation_C : public ACharacter
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x04C0 (size: 0x8)
    class UAudioComponent* Audio;                                                     // 0x04C8 (size: 0x8)
    class UCapsuleComponent* KillPlayer;                                              // 0x04D0 (size: 0x8)
    bool ShouldMove;                                                                  // 0x04D8 (size: 0x1)
    class ABPCharacter_Demo_C* Target;                                                // 0x04E0 (size: 0x8)
    bool CanAttack;                                                                   // 0x04E8 (size: 0x1)

    void LookAtEntity(class ABPCharacter_Demo_C* Target);
    void StopMovement();
    void OnMoveFinished_7E70DA774128EF044FF5A1902873E256(TEnumAsByte<EPathFollowingResult::Type> Result, class AAIController* AIController);
    void OnRequestFailed_7E70DA774128EF044FF5A1902873E256();
    void OnMoveFinished_FA9FB91748D8CD6E57E2CFB9369E87DF(TEnumAsByte<EPathFollowingResult::Type> Result, class AAIController* AIController);
    void OnRequestFailed_FA9FB91748D8CD6E57E2CFB9369E87DF();
    void StartChasing();
    void AttackPlayer(class ABPCharacter_Demo_C* Player);
    void MC_KillSound(class ABPCharacter_Demo_C* Character);
    void ReceiveBeginPlay();
    void OnQueryFinish(class UEnvQueryInstanceBlueprintWrapper* QueryInstance, TEnumAsByte<EEnvQueryStatus::Type> QueryStatus);
    void Jumpscare(class ABPCharacter_Demo_C* Player);
    void BndEvt__BP_Animation_KillPlayer_K2Node_ComponentBoundEvent_0_ComponentBeginOverlapSignature__DelegateSignature(class UPrimitiveComponent* OverlappedComponent, class AActor* OtherActor, class UPrimitiveComponent* OtherComp, int32 OtherBodyIndex, bool bFromSweep, const FHitResult& SweepResult);
    void Retreat(FVector Location);
    void MC_KillAnimation(class ABPCharacter_Demo_C* Player);
    void MC_ChangeEyeColor();
    void MC_StartSound();
    void MC_StopSound();
    void StopSound();
    void ExecuteUbergraph_BP_Animation(int32 EntryPoint);
}; // Size: 0x4E9

#endif
