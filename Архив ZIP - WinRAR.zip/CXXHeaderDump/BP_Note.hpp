#ifndef UE4SS_SDK_BP_Note_HPP
#define UE4SS_SDK_BP_Note_HPP

class ABP_Note_C : public AClientInteractableActor
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x0248 (size: 0x8)
    class UTexture* NoteTexture;                                                      // 0x0250 (size: 0x8)
    FName NoteRow;                                                                    // 0x0258 (size: 0x8)

    void ReceiveBeginPlay();
    void OnActorUsed(class ACharacter* Character);
    void ExecuteUbergraph_BP_Note(int32 EntryPoint);
}; // Size: 0x260

#endif
