#ifndef UE4SS_SDK_BP_Card_HPP
#define UE4SS_SDK_BP_Card_HPP

class ABP_Card_C : public AActor
{
    class UWidgetComponent* Widget;                                                   // 0x0220 (size: 0x8)
    class UStaticMeshComponent* id_card_03_Strap;                                     // 0x0228 (size: 0x8)
    class UStaticMeshComponent* id_card_03_Rectangle001;                              // 0x0230 (size: 0x8)
    class UStaticMeshComponent* id_card_03_Metal_03;                                  // 0x0238 (size: 0x8)
    class UStaticMeshComponent* id_card_03_Metal_02;                                  // 0x0240 (size: 0x8)
    class UStaticMeshComponent* id_card_03_Metal_01;                                  // 0x0248 (size: 0x8)
    class USceneComponent* DefaultSceneRoot;                                          // 0x0250 (size: 0x8)
    bool IsVisible;                                                                   // 0x0258 (size: 0x1)

    void RefreshPlayerInfo();
    void OnRep_IsVisible();
    void ToggleVisibility(bool IsVisible);
}; // Size: 0x259

#endif
