#ifndef UE4SS_SDK_FluidForceImpulsePerInstanceData_HPP
#define UE4SS_SDK_FluidForceImpulsePerInstanceData_HPP

struct FFluidForceImpulsePerInstanceData
{
    FFluidForceImpulse ImpulseSettings_41_C9A94C02422D8BF40DF6B1BB2A0D8CBC;           // 0x0000 (size: 0x50)
    float ElapsedTime_44_12C387C1450456E47FC74BBD11EEAE4F;                            // 0x0050 (size: 0x4)
    float StartOffset_48_78EF0E3F4B05F70C5679F9B9F41D590F;                            // 0x0054 (size: 0x4)
    bool IsSplashEffect_54_4A5B178940D26E71D6FCDF84584A5284;                          // 0x0058 (size: 0x1)

}; // Size: 0x59

#endif
