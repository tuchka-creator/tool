#ifndef UE4SS_SDK_FluidForceImpulseTimedEffects_HPP
#define UE4SS_SDK_FluidForceImpulseTimedEffects_HPP

struct FFluidForceImpulseTimedEffects
{
    bool EnableWaterDropsEffect_39_0A7932284406807D62695D8E0927BD70;                  // 0x0000 (size: 0x1)
    float EffectRadius_30_C9A94C02422D8BF40DF6B1BB2A0D8CBC;                           // 0x0004 (size: 0x4)
    float Strength_29_2CAA30794D1EFF60AE1C3491D011CECF;                               // 0x0008 (size: 0x4)
    float WaterDropsperSquareMeter_27_C31B527C4C367A5CA5E1DF8E49E76234;               // 0x000C (size: 0x4)
    float StartTimeOffset_33_5A792CE8489A59E5D9B24F9E4DCFE94A;                        // 0x0010 (size: 0x4)
    float Lifetime_35_C2749C1449C41D4F236BCBAF6ED34113;                               // 0x0014 (size: 0x4)
    float StrengthoverLifePower_37_4FA6941A4AD024828AFEB782783DD01C;                  // 0x0018 (size: 0x4)
    class UMaterialInterface* MaterialOverride_42_FB856A244A1713590BB76EAA7CC7A0DF;   // 0x0020 (size: 0x8)

}; // Size: 0x28

#endif
