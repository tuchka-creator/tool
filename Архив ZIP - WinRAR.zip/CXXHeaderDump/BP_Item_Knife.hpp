#ifndef UE4SS_SDK_BP_Item_Knife_HPP
#define UE4SS_SDK_BP_Item_Knife_HPP

class ABP_Item_Knife_C : public ABP_Item_C
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x0258 (size: 0x8)
    bool CanUse;                                                                      // 0x0260 (size: 0x1)
    class AActor* KnifeThirdPersonVisuals;                                            // 0x0268 (size: 0x8)

    void OnNotifyEnd_DCFF09A94F2F9174E32D89AADA2A2E4E(FName NotifyName);
    void OnNotifyBegin_DCFF09A94F2F9174E32D89AADA2A2E4E(FName NotifyName);
    void OnInterrupted_DCFF09A94F2F9174E32D89AADA2A2E4E(FName NotifyName);
    void OnBlendOut_DCFF09A94F2F9174E32D89AADA2A2E4E(FName NotifyName);
    void OnCompleted_DCFF09A94F2F9174E32D89AADA2A2E4E(FName NotifyName);
    void OnNotifyEnd_EAE1020347AF8423F02534B24A6EB7A0(FName NotifyName);
    void OnNotifyBegin_EAE1020347AF8423F02534B24A6EB7A0(FName NotifyName);
    void OnInterrupted_EAE1020347AF8423F02534B24A6EB7A0(FName NotifyName);
    void OnBlendOut_EAE1020347AF8423F02534B24A6EB7A0(FName NotifyName);
    void OnCompleted_EAE1020347AF8423F02534B24A6EB7A0(FName NotifyName);
    void UseItem();
    void Damage_SERVER(class UObject* Target, class AFancyCharacter* Character);
    void PlayAnimation();
    void TraceForHit();
    void SRV_StabPlayer(class AFancyCharacter* Instigator, class ABPCharacter_Demo_C* Player, FVector ImpactPoint);
    void MC_Splat(FVector Location, FRotator Rotation);
    void MC_Untangle(FVector Location);
    void ExecuteUbergraph_BP_Item_Knife(int32 EntryPoint);
}; // Size: 0x270

#endif
