#ifndef UE4SS_SDK_BP_DroppedItem_DivingHelmet_HPP
#define UE4SS_SDK_BP_DroppedItem_DivingHelmet_HPP

class ABP_DroppedItem_DivingHelmet_C : public ABP_DroppedItem_C
{
}; // Size: 0x269

#endif
