#ifndef UE4SS_SDK_BP_Level0Exit_HPP
#define UE4SS_SDK_BP_Level0Exit_HPP

class ABP_Level0Exit_C : public ABP_ExitZone_C
{
    class UStaticMeshComponent* Cube4;                                                // 0x0250 (size: 0x8)
    class UStaticMeshComponent* Cube3;                                                // 0x0258 (size: 0x8)
    class UStaticMeshComponent* Cube2;                                                // 0x0260 (size: 0x8)
    class UStaticMeshComponent* Cube1;                                                // 0x0268 (size: 0x8)
    class UStaticMeshComponent* Cube;                                                 // 0x0270 (size: 0x8)
    class UStaticMeshComponent* StaticMesh;                                           // 0x0278 (size: 0x8)

}; // Size: 0x280

#endif
