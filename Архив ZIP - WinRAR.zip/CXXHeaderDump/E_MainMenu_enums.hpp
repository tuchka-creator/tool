namespace E_MainMenu {
    enum Type {
        NewEnumerator0 = 0,
        NewEnumerator7 = 1,
        NewEnumerator3 = 2,
        NewEnumerator1 = 3,
        NewEnumerator8 = 4,
        E_MAX = 5,
    };
}

