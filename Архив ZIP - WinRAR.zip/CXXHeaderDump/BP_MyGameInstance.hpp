#ifndef UE4SS_SDK_BP_MyGameInstance_HPP
#define UE4SS_SDK_BP_MyGameInstance_HPP

class UBP_MyGameInstance_C : public UFancyGameInstance
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x0278 (size: 0x8)
    class UW_LoadingScreen_C* W_LoadingScreenRef;                                     // 0x0280 (size: 0x8)
    FText LoadingMessage;                                                             // 0x0288 (size: 0x18)
    FText LoadingMessageTip;                                                          // 0x02A0 (size: 0x18)
    bool AlreadyIntro?;                                                               // 0x02B8 (size: 0x1)
    float TimeLoadingBeforeContinue;                                                  // 0x02BC (size: 0x4)
    TArray<class AMP_PlayerController_C*> ToRespawn;                                  // 0x02C0 (size: 0x10)
    TEnumAsByte<E_Difficulty::Type> Difficulty;                                       // 0x02D0 (size: 0x1)
    bool WasKicked;                                                                   // 0x02D1 (size: 0x1)
    FString Code;                                                                     // 0x02D8 (size: 0x10)
    bool FromHub;                                                                     // 0x02E8 (size: 0x1)
    bool IsExit;                                                                      // 0x02E9 (size: 0x1)
    bool HasSeenSanityWarning;                                                        // 0x02EA (size: 0x1)
    TMap<FString, TEnumAsByte<E_HeadsetType::Type>> HeadsetMap;                       // 0x02F0 (size: 0x50)
    FString ExtraData;                                                                // 0x0340 (size: 0x10)
    bool IsLoading;                                                                   // 0x0350 (size: 0x1)
    float LastXP;                                                                     // 0x0354 (size: 0x4)
    TEnumAsByte<E_GameMode::Type> CurrentMode;                                        // 0x0358 (size: 0x1)
    FName StartingLevel;                                                              // 0x035C (size: 0x8)
    bool DidCompleteMission;                                                          // 0x0364 (size: 0x1)
    FMissionStructure MissionCompleteData;                                            // 0x0368 (size: 0x60)
    bool HasSeenGlowstickHint;                                                        // 0x03C8 (size: 0x1)
    bool HasSeenRadioHint;                                                            // 0x03C9 (size: 0x1)
    float MissionCompletionTime;                                                      // 0x03CC (size: 0x4)
    bool IsPrivateGame;                                                               // 0x03D0 (size: 0x1)
    int32 MaxPlayers;                                                                 // 0x03D4 (size: 0x4)
    TArray<FName> AchievementQueue;                                                   // 0x03D8 (size: 0x10)
    bool IsCurrentlyUnlockingAchievement;                                             // 0x03E8 (size: 0x1)
    bool HasPremium;                                                                  // 0x03E9 (size: 0x1)
    bool PremiumDialogCompleted;                                                      // 0x03EA (size: 0x1)
    FBP_MyGameInstance_COnPlayerLoginStatusChange OnPlayerLoginStatusChange;          // 0x03F0 (size: 0x10)
    void OnPlayerLoginStatusChange(int32 PlayerNum, EBPLoginStatus PreviousStatus, EBPLoginStatus NewStatus, FBPUniqueNetId NewPlayerUniqueNetID);
    bool InitialPremiumCheckDone;                                                     // 0x0400 (size: 0x1)
    class UW_ErrorModal_C* ErrorModal;                                                // 0x0408 (size: 0x8)
    FString LobbyCode;                                                                // 0x0410 (size: 0x10)
    bool HasCommRestrictedDialogDisplayed;                                            // 0x0420 (size: 0x1)
    bool bHasSeenCrossplayWarning;                                                    // 0x0421 (size: 0x1)
    bool CanPlayOnline;                                                               // 0x0422 (size: 0x1)
    bool CanCrossplay;                                                                // 0x0423 (size: 0x1)
    bool CanCommunicateOnline;                                                        // 0x0424 (size: 0x1)
    FBP_MyGameInstance_COnCheckPremiumStateDone OnCheckPremiumStateDone;              // 0x0428 (size: 0x10)
    void OnCheckPremiumStateDone(bool JustGotPremium);
    FBP_MyGameInstance_COnInlineLoginDone OnInlineLoginDone;                          // 0x0438 (size: 0x10)
    void OnInlineLoginDone(bool Success);
    bool bEOSLoginCallbackBound;                                                      // 0x0448 (size: 0x1)
    bool bHasSeenAutosaveModal;                                                       // 0x0449 (size: 0x1)
    bool bIsGameChatActive;                                                           // 0x044A (size: 0x1)
    bool bIsInCinematic;                                                              // 0x044B (size: 0x1)
    FDateTime LastPrivCheckTime;                                                      // 0x0450 (size: 0x8)
    FBP_MyGameInstance_COnCheckCrossplayPrivilegeComplete OnCheckCrossplayPrivilegeComplete; // 0x0458 (size: 0x10)
    void OnCheckCrossplayPrivilegeComplete(bool bSuccess);
    class UFancyTelemetryEventBuilder* GameplayActivityStartEventBuilder;             // 0x0468 (size: 0x8)
    class UFancyTelemetryEventBuilder* GameplayActivityEndEventBuilder;               // 0x0470 (size: 0x8)
    EFancyGameplayActivityEndStatus GameplayActivityEndStatus;                        // 0x0478 (size: 0x1)
    bool CanSendDisconnectionEvent;                                                   // 0x0479 (size: 0x1)

    void RefreshGameplayActivityEventData(class APlayerState* NewPlayerState);
    void ResolveGameplayActivityEndStatus(FString Options);
    void SendPlayerDisconnectEvent(EFancyPlayerDisconnectReason DisconnectReason);
    void SendGameplayActivityEndEvent(TEnumAsByte<E_GameMode::Type> LevelMode, TEnumAsByte<E_Difficulty::Type> LevelDifficulty);
    void SendGameplayActivityStartEvent();
    void CheckCanCrossplayPrivilege(bool bForceAttemptToResolve, const FCheckCanCrossplayPrivilegeEvent& Event);
    void UnBindEOSLoginCallback();
    void BindEOSLoginCallback();
    void FixResolutionOnSteamDeck();
    void CreateSessionSettings(bool IsPrivate, class APlayerController* InPlayerController, const TArray<FSessionPropertyKeyPair>& Array);
    bool IsOnline();
    void PatchInputIni();
    bool IsPremiumAvailable();
    void UpdatePlayerSpeakingInScoreboard(const FBPUniqueNetId& NetId, bool IsSpeaking);
    void CheckShouldDisplayEvent();
    void ResetInput();
    void CheckCodeUnique(FSessionsSearchSetting Code);
    void GenerateCode();
    void OnFailure_F6A1C64C4BF407E4C67D4F8266759C0F(FName WrittenAchievementName, float WrittenProgress, int32 WrittenUserTag);
    void OnSuccess_F6A1C64C4BF407E4C67D4F8266759C0F(FName WrittenAchievementName, float WrittenProgress, int32 WrittenUserTag);
    void OnFailure_4A8E1BF4489B644EBB46CCB5CE87A8FB();
    void OnSuccess_4A8E1BF4489B644EBB46CCB5CE87A8FB();
    void OnFailure_D7E8A28A46B4BD5B7318A6A66AFD14E2();
    void OnSuccess_D7E8A28A46B4BD5B7318A6A66AFD14E2();
    void OnFailure_C5B79B204D20B91A7829848F8D941EA8(const bool SessionInfo);
    void OnSuccess_C5B79B204D20B91A7829848F8D941EA8(const bool SessionInfo);
    void OnFailure_8D32C966478C31E18DECF896A41FD4CE(const bool SessionInfo);
    void OnSuccess_8D32C966478C31E18DECF896A41FD4CE(const bool SessionInfo);
    void OnFailure_4DF97576439008BC743F0C8D8DD6B7AE(const bool SessionInfo);
    void OnSuccess_4DF97576439008BC743F0C8D8DD6B7AE(const bool SessionInfo);
    void OnFailure_230A28C84B39D41BC65D169688F5D581(const bool SessionInfo);
    void OnSuccess_230A28C84B39D41BC65D169688F5D581(const bool SessionInfo);
    void OnFailure_5D2C7C2D42FC55C47765C8BB8F07226A(const bool SessionInfo);
    void OnSuccess_5D2C7C2D42FC55C47765C8BB8F07226A(const bool SessionInfo);
    void OnFailure_108456A74123143EAC64CCBE7FEC6A51(const bool SessionInfo);
    void OnSuccess_108456A74123143EAC64CCBE7FEC6A51(const bool SessionInfo);
    void OnFailure_00167D3340D34B282413138479CDBF85();
    void OnSuccess_00167D3340D34B282413138479CDBF85();
    void OnFailure_36EA07F14906798B445565A0E68A0CAB(const bool SessionInfo);
    void OnSuccess_36EA07F14906798B445565A0E68A0CAB(const bool SessionInfo);
    void OnFailure_738E87BA453FC78726BB63BF27C708EE();
    void OnSuccess_738E87BA453FC78726BB63BF27C708EE();
    void UnlockAchievement(FName AchievementName, class APlayerController* PlayerController);
    void OnPlayerTalkingStateChanged(FBPUniqueNetId PlayerId, bool bIsTalking);
    void ResetAfterErrorFocus(class APlayerController* PlayerController, class UWidget* Widget);
    void OnSteamOverlayIsActive(bool isOverlayActive);
    void ReceiveInit();
    void ReceiveShutdown();
    void OnInputDeviceChangedEvent(const TEnumAsByte<EFancyInputDevice> NewInputDevice);
    void Initialize_AudioSettings();
    void UpdateMissionTime(float DeltaSeconds);
    void FramePacingOnXSS();
    void UnlockAchievementFromQueue(FName Name);
    void CheckAchievementQueue();
    void StartAchievementCheckTimer();
    void ShowPremiumAccountUpgradeDialog();
    void CheckPremiumState();
    void JoinServerSession(FBlueprintSessionResult Session, class APlayerController* PlayerController, class UWidget* ParentRef, bool ShowLoadingScreen);
    void InitializeUserHandlingEvents();
    void OnApplicationReactivate();
    void OnApplicationDeactivate();
    void ReturnToMainMenu();
    void OnPlayerLoginStatusChanged(int32 PlayerNum, EBPLoginStatus PreviousStatus, EBPLoginStatus NewStatus, FBPUniqueNetId NewPlayerUniqueNetID);
    void HideLoadingScreen();
    void HandleNetworkError(TEnumAsByte<ENetworkFailure::Type> FailureType, bool bIsServer);
    void HandleConnectionStatusChanged(bool NewConnectionStatus);
    void OnControllerDisconnected();
    void BindOnControllerDisconnect();
    void CheckCanPlayOnlinePrivilege();
    void CheckCanCommunicateOnlinePrivilege();
    void InlineLogin();
    void OnEOSLoginDone(bool bSuccess);
    void OnCheckPremiumStateDone_Login(bool JustGotPremium);
    void OnPlayerLoginChanged(int32 PlayerNum);
    void SageGameChatActive(bool bActive);
    void CreateServer(class APlayerController* PlayerController, class UWidget* WidgetRef, class UWidget* ParentRef, FName LevelName, int32 MaxPlayer, bool IsPrivate);
    void OnSessionInviteAccepted(bool bWasSuccessful, int32 LocalPlayerNum, FBPUniqueNetId PersonInvited, const FBlueprintSessionResult& SessionToJoin);
    void ShowLoadingScreen(class APlayerController* PlayerController, FText Message);
    void _CheckCanCrossplayPrivilege_Internal(bool bForceAttemptToResolve);
    void RefreshPlayerCommPrivileges();
    void ResolveGameplayActivityEndStatusEvent(FString PendingMapOptions);
    void ExecuteUbergraph_BP_MyGameInstance(int32 EntryPoint);
    void OnCheckCrossplayPrivilegeComplete__DelegateSignature(bool bSuccess);
    void OnInlineLoginDone__DelegateSignature(bool Success);
    void OnCheckPremiumStateDone__DelegateSignature(bool JustGotPremium);
    void OnPlayerLoginStatusChange__DelegateSignature(int32 PlayerNum, EBPLoginStatus PreviousStatus, EBPLoginStatus NewStatus, FBPUniqueNetId NewPlayerUniqueNetID);
}; // Size: 0x47A

#endif
