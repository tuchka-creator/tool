#ifndef UE4SS_SDK_Base_GM_HPP
#define UE4SS_SDK_Base_GM_HPP

class ABase_GM_C : public AGameMode
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x0308 (size: 0x8)
    class USceneComponent* DefaultSceneRoot;                                          // 0x0310 (size: 0x8)
    TArray<class ALobby_PlayerController_Nebula_C*> PlayerControllers;                // 0x0318 (size: 0x10)

    void GetPlayerControllerFromPlayerState(class APlayerState* PlayerState, class ABP_BasePlayerController_C*& PlayerController);
    void KickPlayer(int32 PlayerId);
    void Handle Player Disconnection(class AController* Player);
    void Handle_PlayerConnection(class APlayerController* NewPlayer);
    void ServerTravel_ToGameplayMap(FName Map);
    void K2_PostLogin(class APlayerController* NewPlayer);
    void K2_OnSwapPlayerControllers(class APlayerController* OldPC, class APlayerController* NewPC);
    void K2_OnLogout(class AController* ExitingController);
    void HandleStartingNewPlayer(class APlayerController* NewPlayer);
    void ExecuteUbergraph_Base_GM(int32 EntryPoint);
}; // Size: 0x328

#endif
