#ifndef UE4SS_SDK_BP_DroppedItem_Firework_HPP
#define UE4SS_SDK_BP_DroppedItem_Firework_HPP

class ABP_DroppedItem_Firework_C : public ABP_DroppedItem_C
{
}; // Size: 0x269

#endif
