#ifndef UE4SS_SDK_BP_Elevator_HPP
#define UE4SS_SDK_BP_Elevator_HPP

class ABP_Elevator_C : public AActor
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x0220 (size: 0x8)
    class UAudioComponent* Audio;                                                     // 0x0228 (size: 0x8)
    class UStaticMeshComponent* Base1;                                                // 0x0230 (size: 0x8)
    class UStaticMeshComponent* Base;                                                 // 0x0238 (size: 0x8)
    class USceneComponent* DefaultSceneRoot;                                          // 0x0240 (size: 0x8)
    float Elevator_Alpha_920449764532D6CC95C07E8186EC2016;                            // 0x0248 (size: 0x4)
    TEnumAsByte<ETimelineDirection::Type> Elevator__Direction_920449764532D6CC95C07E8186EC2016; // 0x024C (size: 0x1)
    class UTimelineComponent* Elevator;                                               // 0x0250 (size: 0x8)
    bool Is Moving?;                                                                  // 0x0258 (size: 0x1)
    bool IsMovingDown;                                                                // 0x0259 (size: 0x1)
    class ABP_Lever_C* Lever;                                                         // 0x0260 (size: 0x8)
    float CeilingLevel;                                                               // 0x0268 (size: 0x4)
    float FloorLevel;                                                                 // 0x026C (size: 0x4)
    float MovementSpeed;                                                              // 0x0270 (size: 0x4)

    void OnRep_Is Moving?();
    void Elevator__FinishedFunc();
    void Elevator__UpdateFunc();
    void StopElevator();
    void ReceiveBeginPlay();
    void SetComplete();
    void ReceiveTick(float DeltaSeconds);
    void MoveElevator(bool Down);
    void ExecuteUbergraph_BP_Elevator(int32 EntryPoint);
}; // Size: 0x274

#endif
