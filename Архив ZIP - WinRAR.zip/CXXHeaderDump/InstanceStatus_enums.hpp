namespace InstanceStatus {
    enum Type {
        NewEnumerator0 = 0,
        InstanceStatus_MAX = 1,
    };
}

