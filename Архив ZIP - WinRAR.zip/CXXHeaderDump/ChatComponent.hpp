#ifndef UE4SS_SDK_ChatComponent_HPP
#define UE4SS_SDK_ChatComponent_HPP

class UChatComponent_C : public UActorComponent
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x00B0 (size: 0x8)
    class UWB_Chat_C* WB_ChatRef;                                                     // 0x00B8 (size: 0x8)
    bool IsFiltering;                                                                 // 0x00C0 (size: 0x1)
    bool ShowChat;                                                                    // 0x00C1 (size: 0x1)

    void GetSenderPlayerState(const FS_ChatMessage& ChatMessage, class APlayerState*& PlayerState, bool& Success);
    void Get All ChatComponents(TArray<class UChatComponent_C*>& PlayerControllers);
    void Clear_Chat();
    void Focus_Chat();
    void Create_Chat_Widget(bool IsInGame);
    void OC_Setup_Chat_Widget(bool IsInGame);
    void OC_Update_Chat(FS_ChatMessage Message);
    void SR_Update_Chat(const FS_ChatMessage& Message);
    void ReceiveBeginPlay();
    void ToggleChatBox(bool IsVisible);
    void ExecuteUbergraph_ChatComponent(int32 EntryPoint);
}; // Size: 0xC2

#endif
