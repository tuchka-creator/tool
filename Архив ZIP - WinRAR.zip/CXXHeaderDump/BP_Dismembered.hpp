#ifndef UE4SS_SDK_BP_Dismembered_HPP
#define UE4SS_SDK_BP_Dismembered_HPP

class ABP_Dismembered_C : public AActor
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x0220 (size: 0x8)
    class USkeletalMeshComponent* Breathing_Idle__3_;                                 // 0x0228 (size: 0x8)
    class UBP_DismemberComponent_C* BP_DismemberComponent;                            // 0x0230 (size: 0x8)
    class USceneComponent* DefaultSceneRoot;                                          // 0x0238 (size: 0x8)
    class UCostume* Costume;                                                          // 0x0240 (size: 0x8)

    void UserConstructionScript();
    void ReceiveBeginPlay();
    void MC_Sound();
    void ExecuteUbergraph_BP_Dismembered(int32 EntryPoint);
}; // Size: 0x248

#endif
