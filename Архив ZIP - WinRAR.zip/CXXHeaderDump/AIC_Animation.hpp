#ifndef UE4SS_SDK_AIC_Animation_HPP
#define UE4SS_SDK_AIC_Animation_HPP

class AAIC_Animation_C : public AAIController
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x0328 (size: 0x8)
    class UPawnSensingComponent* PawnSensing;                                         // 0x0330 (size: 0x8)
    FName Target;                                                                     // 0x0338 (size: 0x8)

    void BndEvt__PartyGoer_BP_PawnSensing_K2Node_ComponentBoundEvent_0_SeePawnDelegate__DelegateSignature(class APawn* Pawn);
    void ExecuteUbergraph_AIC_Animation(int32 EntryPoint);
}; // Size: 0x340

#endif
