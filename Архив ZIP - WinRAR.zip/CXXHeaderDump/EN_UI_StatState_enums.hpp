namespace EN_UI_StatState {
    enum Type {
        NewEnumerator0 = 0,
        NewEnumerator1 = 1,
        NewEnumerator2 = 2,
        NewEnumerator4 = 3,
        NewEnumerator5 = 4,
        NewEnumerator6 = 5,
        EN_UI_MAX = 6,
    };
}

