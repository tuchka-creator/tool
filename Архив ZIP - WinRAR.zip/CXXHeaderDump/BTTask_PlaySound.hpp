#ifndef UE4SS_SDK_BTTask_PlaySound_HPP
#define UE4SS_SDK_BTTask_PlaySound_HPP

class UBTTask_PlaySound_C : public UBTTask_BlueprintBase
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x00A8 (size: 0x8)

    void ReceiveExecuteAI(class AAIController* OwnerController, class APawn* ControlledPawn);
    void MC_PlaySound(FVector Location);
    void ExecuteUbergraph_BTTask_PlaySound(int32 EntryPoint);
}; // Size: 0xB0

#endif
