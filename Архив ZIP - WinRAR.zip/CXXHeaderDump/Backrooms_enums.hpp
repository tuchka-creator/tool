enum ActivityCompletionStatus {
    ActivityCompleted = 0,
    ActivityFailed = 1,
    ActivityCancelled = 2,
    ActivityCompletionStatus_MAX = 3,
};

enum class EAimAssistCastType {
    Sphere = 0,
    Cone = 1,
    EAimAssistCastType_MAX = 2,
};

enum class EArmVisibility {
    Right = 0,
    Both = 1,
    EArmVisibility_MAX = 2,
};

enum class ECollisionSelectionMethod {
    UseCollisionChannel = 0,
    UseCollisionProfile = 1,
    ECollisionSelectionMethod_MAX = 2,
};

enum class ECostumeDismembermentPart {
    None = 0,
    Head = 1,
    Hand = 2,
    Arm = 3,
    Leg = 4,
    ECostumeDismembermentPart_MAX = 5,
};

enum class ECostumeSelectorFeedbackState {
    Idle = 0,
    ShowingStartLoadFeedback = 1,
    Loading = 2,
    ShowingLoadCompleteFeedback = 3,
    ECostumeSelectorFeedbackState_MAX = 4,
};

enum class EFancyActivitySessionType {
    None = 0,
    Gameplay = 1,
    SettingsMenu = 2,
    CosmeticSelection = 3,
    EFancyActivitySessionType_MAX = 4,
};

enum class EFancyEventType {
    None = 0,
    Halloween = 1,
    Christmas = 2,
    EFancyEventType_MAX = 3,
};

enum class EFancyGameplayActivityEndStatus {
    None = 0,
    Success = 1,
    Failure = 2,
    ManualRestart = 3,
    Quit = 4,
    Disconnect = 5,
    Unknown = 6,
    EFancyGameplayActivityEndStatus_MAX = 7,
};

enum EFancyInputDevice {
    KeyboardMouse = 0,
    Gamepad = 1,
    Oculus = 2,
    HTCVive = 3,
    EFancyInputDevice_MAX = 4,
};

enum class EFancyModalButton {
    Button1 = 0,
    Button2 = 1,
    EFancyModalButton_MAX = 2,
};

enum class EFancyNetIDFormat {
    Unknown = 0,
    EOS = 1,
    EOSPlus = 2,
    Platform = 3,
    EFancyNetIDFormat_MAX = 4,
};

enum class EFancyPlatform {
    None = 0,
    Windows = 1,
    WinGDK = 2,
    XboxSeries = 3,
    PS5 = 4,
    Switch2 = 5,
    EFancyPlatform_MAX = 6,
};

enum class EFancyPlayerDisconnectReason {
    None = 0,
    Quit = 1,
    HostLeftSession = 2,
    NetworkFailure = 3,
    Kick = 4,
    Unknown = 5,
    EFancyPlayerDisconnectReason_MAX = 6,
};

enum class EFancySaveSubsystemFlushingState {
    Idle = 0,
    WarmingUpForQueuedSaves = 1,
    WritingQueuedSaves = 2,
    EFancySaveSubsystemFlushingState_MAX = 3,
};

enum class EFancyTelemetryEventType {
    None = 0,
    AppStart = 1,
    AppEnd = 2,
    ActivitySessionStart = 3,
    ActivitySessionEnd = 4,
    CosmeticSelection = 5,
    PlayerDeath = 6,
    PlayerDisconnect = 7,
    EFancyTelemetryEventType_MAX = 8,
};

enum class EFancyUserPrivileges {
    CanPlay = 0,
    CanPlayOnline = 1,
    CanCommunicateOnline = 2,
    CanUseUserGeneratedContent = 3,
    CanUserCrossPlay = 4,
    EFancyUserPrivileges_MAX = 5,
};

enum class EFancyUserReportCategory {
    Invalid = 0,
    Cheating = 1,
    Exploiting = 2,
    OffensiveProfile = 3,
    VerbalAbuse = 4,
    Scamming = 5,
    Spamming = 6,
    Other = 7,
    EFancyUserReportCategory_MAX = 8,
};

enum class EGizmoType {
    None = 0,
    Location = 1,
    Rotation = 2,
    Scale = 3,
    EGizmoType_MAX = 4,
};

enum class EInputMode {
    UIOnly = 0,
    GameAndUI = 1,
    GameOnly = 2,
    Unknown = 3,
    EInputMode_MAX = 4,
};

enum class EItemRarity {
    Undefined = 0,
    Common = 1,
    Uncommon = 2,
    Rare = 3,
    Epic = 4,
    Legendary = 5,
    EItemRarity_MAX = 6,
};

enum class EItemType {
    Undefined = 0,
    Placeable = 1,
    Equipment = 2,
    Consumable = 3,
    Material = 4,
    EItemType_MAX = 5,
};

enum class EItemTypes {
    TOOL = 0,
    CONSUMABLE = 1,
    EItemTypes_MAX = 2,
};

enum class EMotionComponentType {
    TARGET = 0,
    TEAMMATE = 1,
    SCANNER = 2,
    EMotionComponentType_MAX = 3,
};

enum class EMoveAxis {
    None = 0,
    XAxis = 1,
    YAxis = 2,
    ZAxis = 3,
    EMoveAxis_MAX = 4,
};

enum class EOnJoinSessionCompleteFancyResult {
    Success = 0,
    SessionIsFull = 1,
    SessionDoesNotExist = 2,
    CouldNotRetrieveAddress = 3,
    AlreadyInSession = 4,
    UnknownError = 5,
    EOnJoinSessionCompleteFancyResult_MAX = 6,
};

enum class ERotationAxis {
    None = 0,
    Yaw = 1,
    Roll = 2,
    Pitch = 3,
    ERotationAxis_MAX = 4,
};

enum class EScaleAxis {
    None = 0,
    ScaleX = 1,
    ScaleY = 2,
    ScaleZ = 3,
    EScaleAxis_MAX = 4,
};

enum class EVRRotationQuantization {
    RoundTo10Bits = 0,
    RoundToShort = 1,
    EVRRotationQuantization_MAX = 2,
};

enum class EVRVectorQuantization {
    RoundOneDecimal = 0,
    RoundTwoDecimals = 1,
    EVRVectorQuantization_MAX = 2,
};

enum class EVRVelocityType {
    VRLOCITY_Default = 0,
    VRLOCITY_RunningAverage = 1,
    VRLOCITY_SamplePeak = 2,
    VRLOCITY_MAX = 3,
};

