#ifndef UE4SS_SDK_BP_RefreshWaterBodies_HPP
#define UE4SS_SDK_BP_RefreshWaterBodies_HPP

class ABP_RefreshWaterBodies_C : public AActor
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x0220 (size: 0x8)
    class UBoxComponent* Box;                                                         // 0x0228 (size: 0x8)
    class USceneComponent* DefaultSceneRoot;                                          // 0x0230 (size: 0x8)

    void ReceiveActorBeginOverlap(class AActor* OtherActor);
    void ExecuteUbergraph_BP_RefreshWaterBodies(int32 EntryPoint);
}; // Size: 0x238

#endif
