#ifndef UE4SS_SDK_BPFL_OnlineInteractions_HPP
#define UE4SS_SDK_BPFL_OnlineInteractions_HPP

class UBPFL_OnlineInteractions_C : public UBlueprintFunctionLibrary
{

    void CheckForBlockedPlayer(class ABP_BasePlayerController_C* Player, class UObject* __WorldContext, bool& IsBlocked);
}; // Size: 0x28

#endif
