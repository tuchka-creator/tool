#ifndef UE4SS_SDK_BP_ScannerDirector_HPP
#define UE4SS_SDK_BP_ScannerDirector_HPP

class ABP_ScannerDirector_C : public AMotionScannerDirector
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x02A8 (size: 0x8)
    class USceneComponent* DefaultSceneRoot;                                          // 0x02B0 (size: 0x8)
    int32 TotalSpawned;                                                               // 0x02B8 (size: 0x4)
    class UMaterialInstanceDynamic* LIDARDotsMat;                                     // 0x02C0 (size: 0x8)
    float DotScaleFactorSK;                                                           // 0x02C8 (size: 0x4)
    float SkelMeshCollisionUVROF;                                                     // 0x02CC (size: 0x4)
    bool CanRunSKCollisionUV;                                                         // 0x02D0 (size: 0x1)
    FVector2D UVData;                                                                 // 0x02D4 (size: 0x8)
    float DotScaleFactor;                                                             // 0x02DC (size: 0x4)

    void InitializeMaterials();
    void FixUVStretching(FVector HitLocation, FVector HitNormal, class UPrimitiveComponent* HitComponent, int32 FaceIndex, FVector2D HitUVLocation, float& FixedSize, FVector& FixedStretch);
    void CheckForExistingRT(class AActor* HitActor, class UPrimitiveComponent* HitComponent, class UTextureRenderTarget2D*& RenderTarget);
    void ReceiveBeginPlay();
    void ClearRenderTargets();
    void MC_LidarDot(FHitResult HitResult, FColor Color);
    void ExecuteUbergraph_BP_ScannerDirector(int32 EntryPoint);
}; // Size: 0x2E0

#endif
