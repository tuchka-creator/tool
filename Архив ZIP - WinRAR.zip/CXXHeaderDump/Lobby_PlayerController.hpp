#ifndef UE4SS_SDK_Lobby_PlayerController_HPP
#define UE4SS_SDK_Lobby_PlayerController_HPP

class ALobby_PlayerController_C : public ABP_BasePlayerController_C
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x0610 (size: 0x8)
    class UChatComponent_C* ChatComponent;                                            // 0x0618 (size: 0x8)
    class ULobby_HUD_C* LobbyHUD_Ref;                                                 // 0x0620 (size: 0x8)
    class ULobby_Menu_C* LobbyMenu_Ref;                                               // 0x0628 (size: 0x8)
    class UWB_SettingsPanel_Theme2_C* SettingsUI_Ref;                                 // 0x0630 (size: 0x8)
    TArray<FS_ConnectedPlayer> ConnectedPlayers;                                      // 0x0638 (size: 0x10)
    bool IsLaunchingGame;                                                             // 0x0648 (size: 0x1)
    FName CurrentGameMode;                                                            // 0x064C (size: 0x8)
    FText ReadyUpButton_Text;                                                         // 0x0658 (size: 0x18)
    bool Warning State?;                                                              // 0x0670 (size: 0x1)
    bool Hide Button?;                                                                // 0x0671 (size: 0x1)
    bool ReadyUpButton_Initialized?;                                                  // 0x0672 (size: 0x1)
    bool LockButton?;                                                                 // 0x0673 (size: 0x1)
    FText ServerName;                                                                 // 0x0678 (size: 0x18)
    class UW_VOIPHUD_C* VOIP_HUD_Ref;                                                 // 0x0690 (size: 0x8)
    bool CanTalk;                                                                     // 0x0698 (size: 0x1)

    void OnRep_CanTalk();
    void Update_PlayerSpeaking(bool IsSpeaking, FBPUniqueNetId UniqueId);
    void CreateLoadingScreen(FText LoadingScreen_FeedbackText, class UTexture2D* LoadingScreen_Image);
    void Create_MapTravel_LoadingScreen(FName Map);
    void Update_GameMode();
    void Save_ReadyUpButton_State(FText ReadyUpButton_Text, bool Warning State?, bool Hide Button?);
    void Create_WB_Lobby_HUD();
    void Get_Player_Name();
    void Get_Chat_Component();
    void Update_WB_LobbyMenu();
    void Update_LobbyStatusIndicator(ESlateVisibility CircularThrobberVisibility, FText LobbyStatusText);
    void Update_Launchevent();
    void Update_ReadyUpButton();
    void Update_LobbyPlayerList();
    void InpActEvt_Settings_K2Node_InputActionEvent_3(FKey Key);
    void OnFailure_866615BE41AC454694EE4F9532779BF7();
    void OnSuccess_866615BE41AC454694EE4F9532779BF7();
    void InpActEvt_Chat_K2Node_InputActionEvent_2(FKey Key);
    void InpActEvt_Talk_K2Node_InputActionEvent_1(FKey Key);
    void InpActEvt_Talk_K2Node_InputActionEvent_0(FKey Key);
    void ReceiveBeginPlay();
    void MC_LoadingScreen();
    void OC_Update_LobbyStatusIndicator(ESlateVisibility CircularThrobber_Visibility, FText LobbyStatus_Text);
    void OC_Update_ReadyUpButton(FText Text, bool WarningState?, bool HideButton?);
    void OC_Launchevent(bool IsLaunchingGame);
    void OC_Update_ServerName(FText ServerName);
    void OC_Update_ConnectedPlayersList(const TArray<FS_ConnectedPlayer>& ConnectedPlayers);
    void ReceiveEndPlay(TEnumAsByte<EEndPlayReason::Type> EndPlayReason);
    void OC_KickedFromLobby();
    void OC_Create_MapTravel_Loadingscreen(FName Map);
    void StartVoice();
    void ExecuteUbergraph_Lobby_PlayerController(int32 EntryPoint);
}; // Size: 0x699

#endif
