#ifndef UE4SS_SDK_BP_MothJelly_HPP
#define UE4SS_SDK_BP_MothJelly_HPP

class ABP_MothJelly_C : public ABP_Item_C
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x0258 (size: 0x8)
    float HoverDown_Z_EB7179E447BA8799493D5BACD216363D;                               // 0x0260 (size: 0x4)
    TEnumAsByte<ETimelineDirection::Type> HoverDown__Direction_EB7179E447BA8799493D5BACD216363D; // 0x0264 (size: 0x1)
    class UTimelineComponent* HoverDown;                                              // 0x0268 (size: 0x8)

    void HoverDown__FinishedFunc();
    void HoverDown__UpdateFunc();
    void OnNotifyEnd_1CCDCF174099237E391B5AA1C23BF140(FName NotifyName);
    void OnNotifyBegin_1CCDCF174099237E391B5AA1C23BF140(FName NotifyName);
    void OnInterrupted_1CCDCF174099237E391B5AA1C23BF140(FName NotifyName);
    void OnBlendOut_1CCDCF174099237E391B5AA1C23BF140(FName NotifyName);
    void OnCompleted_1CCDCF174099237E391B5AA1C23BF140(FName NotifyName);
    void UseItem();
    void PlayAnimation();
    void SRV_FinishEat();
    void ToggleEvent(bool Enable);
    void OnEventLoaded(uint8 EventType);
    void ExecuteUbergraph_BP_MothJelly(int32 EntryPoint);
}; // Size: 0x270

#endif
