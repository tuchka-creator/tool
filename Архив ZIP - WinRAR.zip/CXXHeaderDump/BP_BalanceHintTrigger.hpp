#ifndef UE4SS_SDK_BP_BalanceHintTrigger_HPP
#define UE4SS_SDK_BP_BalanceHintTrigger_HPP

class ABP_BalanceHintTrigger_C : public ATriggerBox
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x0228 (size: 0x8)
    class UDataTable* PlaystationIcons;                                               // 0x0230 (size: 0x8)
    class UDataTable* XBoxIcons;                                                      // 0x0238 (size: 0x8)
    class UDataTable* KeyboardIcons;                                                  // 0x0240 (size: 0x8)

    void ReceiveActorBeginOverlap(class AActor* OtherActor);
    void ExecuteUbergraph_BP_BalanceHintTrigger(int32 EntryPoint);
}; // Size: 0x248

#endif
