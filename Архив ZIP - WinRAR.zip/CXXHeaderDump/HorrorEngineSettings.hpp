#ifndef UE4SS_SDK_HorrorEngineSettings_HPP
#define UE4SS_SDK_HorrorEngineSettings_HPP

struct FHorrorEngineSettings
{
    FHorrorEngine_Footstep FootstepSoundSettings_7_32F93BE340214E304DD49FB17F5E4051;  // 0x0000 (size: 0xA0)

}; // Size: 0xA0

#endif
