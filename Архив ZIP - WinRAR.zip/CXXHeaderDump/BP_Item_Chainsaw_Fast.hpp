#ifndef UE4SS_SDK_BP_Item_Chainsaw_Fast_HPP
#define UE4SS_SDK_BP_Item_Chainsaw_Fast_HPP

class ABP_Item_Chainsaw_Fast_C : public ABP_Item_Chainsaw_C
{
}; // Size: 0x2B0

#endif
