#ifndef UE4SS_SDK_BP_Swim_Shake_HPP
#define UE4SS_SDK_BP_Swim_Shake_HPP

class UBP_Swim_Shake_C : public UMatineeCameraShake
{
}; // Size: 0x1B0

#endif
