#ifndef UE4SS_SDK_Lobby_Name_Box_HPP
#define UE4SS_SDK_Lobby_Name_Box_HPP

class ULobby_Name_Box_C : public UUserWidget
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x0270 (size: 0x8)
    class UEditableTextBox* EditableTextBox_Name;                                     // 0x0278 (size: 0x8)
    class USizeBox* SizeBox;                                                          // 0x0280 (size: 0x8)
    FLobby_Name_Box_COnNameSwitched OnNameSwitched;                                   // 0x0288 (size: 0x10)
    void OnNameSwitched(FText SelectedOption);

    void CanClose();
    void BndEvt__Lobby_Name_Box_EditableTextBox_Name_K2Node_ComponentBoundEvent_0_OnEditableTextBoxChangedEvent__DelegateSignature(const FText& Text);
    void ExecuteUbergraph_Lobby_Name_Box(int32 EntryPoint);
    void OnNameSwitched__DelegateSignature(FText SelectedOption);
}; // Size: 0x298

#endif
