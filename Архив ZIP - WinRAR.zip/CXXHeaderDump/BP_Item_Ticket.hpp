#ifndef UE4SS_SDK_BP_Item_Ticket_HPP
#define UE4SS_SDK_BP_Item_Ticket_HPP

class ABP_Item_Ticket_C : public ABP_Item_C
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x0258 (size: 0x8)
    class UCameraComponent* Camera;                                                   // 0x0260 (size: 0x8)
    bool CanUse;                                                                      // 0x0268 (size: 0x1)

    void UseItem();
    void PlayAnimation();
    void ExecuteUbergraph_BP_Item_Ticket(int32 EntryPoint);
}; // Size: 0x269

#endif
