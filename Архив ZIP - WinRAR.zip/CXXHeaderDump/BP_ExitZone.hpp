#ifndef UE4SS_SDK_BP_ExitZone_HPP
#define UE4SS_SDK_BP_ExitZone_HPP

class ABP_ExitZone_C : public AActor
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x0220 (size: 0x8)
    class UBoxComponent* Box;                                                         // 0x0228 (size: 0x8)
    class USceneComponent* DefaultSceneRoot;                                          // 0x0230 (size: 0x8)
    bool ShouldRemove;                                                                // 0x0238 (size: 0x1)
    FName Level;                                                                      // 0x023C (size: 0x8)
    bool IsFromHub;                                                                   // 0x0244 (size: 0x1)
    bool IsAnExit;                                                                    // 0x0245 (size: 0x1)
    FTimerHandle CheckTimer;                                                          // 0x0248 (size: 0x8)

    void OnExit();
    void OnEnterZone(class AActor* Actor);
    void OnExitZone(class AActor* Actor);
    void BndEvt__BP_ExitZone_Box_K2Node_ComponentBoundEvent_1_ComponentEndOverlapSignature__DelegateSignature(class UPrimitiveComponent* OverlappedComponent, class AActor* OtherActor, class UPrimitiveComponent* OtherComp, int32 OtherBodyIndex);
    void BndEvt__BP_ExitZone_Box_K2Node_ComponentBoundEvent_0_ComponentBeginOverlapSignature__DelegateSignature(class UPrimitiveComponent* OverlappedComponent, class AActor* OtherActor, class UPrimitiveComponent* OtherComp, int32 OtherBodyIndex, bool bFromSweep, const FHitResult& SweepResult);
    void CheckPlayers();
    void ExecuteUbergraph_BP_ExitZone(int32 EntryPoint);
}; // Size: 0x250

#endif
