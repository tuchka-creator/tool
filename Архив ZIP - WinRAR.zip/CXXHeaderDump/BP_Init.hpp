#ifndef UE4SS_SDK_BP_Init_HPP
#define UE4SS_SDK_BP_Init_HPP

class ABP_Init_C : public AActor
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x0220 (size: 0x8)
    class UMediaSoundComponent* MediaSound;                                           // 0x0228 (size: 0x8)
    class USceneComponent* DefaultSceneRoot;                                          // 0x0230 (size: 0x8)
    FText Password;                                                                   // 0x0238 (size: 0x18)
    class UUI_Desktop_C* DesktopWidget;                                               // 0x0250 (size: 0x8)

    void Logined(class UUI_SignIn_C* Widget);
    void ReceiveBeginPlay();
    void ExecuteUbergraph_BP_Init(int32 EntryPoint);
}; // Size: 0x258

#endif
