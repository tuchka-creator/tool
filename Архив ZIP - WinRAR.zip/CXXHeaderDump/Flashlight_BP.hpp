#ifndef UE4SS_SDK_Flashlight_BP_HPP
#define UE4SS_SDK_Flashlight_BP_HPP

class AFlashlight_BP_C : public AActor
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x0220 (size: 0x8)
    class UStaticMeshComponent* FlashlightMesh;                                       // 0x0228 (size: 0x8)
    class USpotLightComponent* Flashlight;                                            // 0x0230 (size: 0x8)
    class USceneComponent* DefaultSceneRoot;                                          // 0x0238 (size: 0x8)

    void ReceiveBeginPlay();
    void ExecuteUbergraph_Flashlight_BP(int32 EntryPoint);
}; // Size: 0x240

#endif
