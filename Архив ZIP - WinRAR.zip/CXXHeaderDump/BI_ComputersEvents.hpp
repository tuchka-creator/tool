#ifndef UE4SS_SDK_BI_ComputersEvents_HPP
#define UE4SS_SDK_BI_ComputersEvents_HPP

class IBI_ComputersEvents_C : public IInterface
{

    void onClose();
    void LaunchShortcut(int32 Program ID, class UTexture2D* Texture2D (if applicatable), FText Text (if applicatable), class USoundBase* Sounnd (if applicatable), class UFileMediaSource* Media (if applicatable), FString Level Name (if applicatable));
}; // Size: 0x28

#endif
