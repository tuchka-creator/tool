#ifndef UE4SS_SDK_BFL_SetMaxDrawDistance_HPP
#define UE4SS_SDK_BFL_SetMaxDrawDistance_HPP

class UBFL_SetMaxDrawDistance_C : public UBlueprintFunctionLibrary
{

    void Set Instance Draw Distance(bool EnableCullDistances, class UInstancedStaticMeshComponent* InstancedStaticMesh, TArray<FCullDistanceSizePair>& CullDistances, class UStaticMesh* StaticMesh, float FalloffPercentage, class UObject* __WorldContext);
    void ReverseSortCullDistances(TArray<FCullDistanceSizePair>& CullDistances, class UObject* __WorldContext, TArray<FCullDistanceSizePair>& SortedCullDistances);
    void GetObjectBoundsSize(class UStaticMeshComponent* StaticMesh, float Scale, bool Debug, class UObject* __WorldContext, float& Size);
    void Set Max Draw Distance(bool EnableCullDistances, TArray<class UStaticMeshComponent*>& StaticMeshes, TArray<FCullDistanceSizePair>& CullDistances, float ScaleMin, float ScaleMax, float ScaleUniform, bool Debug, class UObject* __WorldContext);
}; // Size: 0x28

#endif
