#ifndef UE4SS_SDK_BP_FallDamage_HPP
#define UE4SS_SDK_BP_FallDamage_HPP

class UBP_FallDamage_C : public UActorComponent
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x00B0 (size: 0x8)

    void OnLanded();
    void MC_FallSound(FVector Location);
    void ExecuteUbergraph_BP_FallDamage(int32 EntryPoint);
}; // Size: 0xB8

#endif
