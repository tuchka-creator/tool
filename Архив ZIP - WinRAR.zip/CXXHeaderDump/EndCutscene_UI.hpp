#ifndef UE4SS_SDK_EndCutscene_UI_HPP
#define UE4SS_SDK_EndCutscene_UI_HPP

class UEndCutscene_UI_C : public UUserWidget
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x0270 (size: 0x8)
    class UWidgetAnimation* FadeIn;                                                   // 0x0278 (size: 0x8)
    class UImage* Image_1;                                                            // 0x0280 (size: 0x8)
    class UMediaPlayer* MediaPlayer;                                                  // 0x0288 (size: 0x8)
    class UMaterialInstanceDynamic* Mat;                                              // 0x0290 (size: 0x8)
    FName LevelToLoad;                                                                // 0x0298 (size: 0x8)
    bool IsSolo;                                                                      // 0x02A0 (size: 0x1)

    void Construct();
    void OnFinish();
    void PreConstruct(bool IsDesignTime);
    void ExecuteUbergraph_EndCutscene_UI(int32 EntryPoint);
}; // Size: 0x2A1

#endif
