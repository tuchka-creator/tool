#ifndef UE4SS_SDK_BP_CameraManager_HPP
#define UE4SS_SDK_BP_CameraManager_HPP

class ABP_CameraManager_C : public APlayerCameraManager
{
}; // Size: 0x2810

#endif
