#ifndef UE4SS_SDK_BP_Rope_Zone_HPP
#define UE4SS_SDK_BP_Rope_Zone_HPP

class ABP_Rope_Zone_C : public ATriggerBox
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x0228 (size: 0x8)

    void ReceiveActorBeginOverlap(class AActor* OtherActor);
    void ReceiveActorEndOverlap(class AActor* OtherActor);
    void ExecuteUbergraph_BP_Rope_Zone(int32 EntryPoint);
}; // Size: 0x230

#endif
