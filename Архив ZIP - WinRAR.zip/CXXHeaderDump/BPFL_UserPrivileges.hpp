#ifndef UE4SS_SDK_BPFL_UserPrivileges_HPP
#define UE4SS_SDK_BPFL_UserPrivileges_HPP

class UBPFL_UserPrivileges_C : public UBlueprintFunctionLibrary
{

    void CanUseCommunication(class UObject* __WorldContext, bool& CanCommunicateOnline);
    void CanCrossplay(class UObject* __WorldContext, bool& CanCrossplay);
    void CanPlayOnline(class UObject* __WorldContext, bool& CanPlayOnline);
}; // Size: 0x28

#endif
