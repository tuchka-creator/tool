#ifndef UE4SS_SDK_BP_DroppedItem_Jelly_HPP
#define UE4SS_SDK_BP_DroppedItem_Jelly_HPP

class ABP_DroppedItem_Jelly_C : public ABP_DroppedItem_C
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x0270 (size: 0x8)
    float Lerp_Alpha_A2CD5C794142AEE6C3D02881757E0FED;                                // 0x0278 (size: 0x4)
    TEnumAsByte<ETimelineDirection::Type> Lerp__Direction_A2CD5C794142AEE6C3D02881757E0FED; // 0x027C (size: 0x1)
    class UTimelineComponent* Lerp;                                                   // 0x0280 (size: 0x8)
    FVector StartingLocation;                                                         // 0x0288 (size: 0xC)

    void Lerp__FinishedFunc();
    void Lerp__UpdateFunc();
    void ToggleEvent(bool Enable);
    void OnEventLoaded(uint8 EventType);
    void DropJelly();
    void ExecuteUbergraph_BP_DroppedItem_Jelly(int32 EntryPoint);
}; // Size: 0x294

#endif
