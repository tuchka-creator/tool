#ifndef UE4SS_SDK_Lobby_HUD_HPP
#define UE4SS_SDK_Lobby_HUD_HPP

class ULobby_HUD_C : public UUserWidget
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x0270 (size: 0x8)
    class UBackgroundBlur* BackgroundBlur;                                            // 0x0278 (size: 0x8)
    class UButton* Button;                                                            // 0x0280 (size: 0x8)
    class UButton* Button_91;                                                         // 0x0288 (size: 0x8)
    class UCircularThrobber* CircularThrobber;                                        // 0x0290 (size: 0x8)
    class UTextBlock* LobbyName_Text;                                                 // 0x0298 (size: 0x8)
    class UTextBlock* LobbyStatus_Text;                                               // 0x02A0 (size: 0x8)
    class UTextBlock* ServerCode;                                                     // 0x02A8 (size: 0x8)
    class UScrollBox* VoiceBox;                                                       // 0x02B0 (size: 0x8)
    class UW_VOIPAnim_C* W_VOIPAnim;                                                  // 0x02B8 (size: 0x8)
    class UBorder* WarningOverlay;                                                    // 0x02C0 (size: 0x8)
    class ALobbyPS_C* LobbyPS;                                                        // 0x02C8 (size: 0x8)
    class ALobby_GS_C* LobbyGS;                                                       // 0x02D0 (size: 0x8)
    class ALobby_PlayerController_C* LobbyPC;                                         // 0x02D8 (size: 0x8)
    int32 Countdown;                                                                  // 0x02E0 (size: 0x4)
    bool LaunchingGame?;                                                              // 0x02E4 (size: 0x1)
    bool LaunchActive?;                                                               // 0x02E5 (size: 0x1)

    void HideMicIcon(FBPUniqueNetId UniqueId);
    void ShowMicIcon(FBPUniqueNetId UniqueId);
    void SetServerCode(const FString& ServerCode);
    void Init_Casts();
    void SetUp();
    void Init_LobbyStatus_Indicator();
    void SetServerName(const FString& ServerName);
    void Update_LobbyStatus_Indicator(ESlateVisibility CircularThrobber_Visibility, FText LobbyStatus_Text);
    void CanClose();
    void Construct();
    void Toggle_Launchevent(bool LaunchingGame?);
    void Countdown_Launchevent();
    void BndEvt__Lobby_HUD_Button_91_K2Node_ComponentBoundEvent_0_OnButtonClickedEvent__DelegateSignature();
    void BndEvt__Lobby_HUD_Button_K2Node_ComponentBoundEvent_1_OnButtonClickedEvent__DelegateSignature();
    void ExecuteUbergraph_Lobby_HUD(int32 EntryPoint);
}; // Size: 0x2E6

#endif
