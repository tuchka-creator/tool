#ifndef UE4SS_SDK_BTDecorator_ShouldMove_2_HPP
#define UE4SS_SDK_BTDecorator_ShouldMove_2_HPP

class UBTDecorator_ShouldMove_2_C : public UBTDecorator_BlueprintBase
{

    bool PerformConditionCheckAI(class AAIController* OwnerController, class APawn* ControlledPawn);
}; // Size: 0xA0

#endif
