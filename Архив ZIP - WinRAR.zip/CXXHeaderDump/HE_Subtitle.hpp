#ifndef UE4SS_SDK_HE_Subtitle_HPP
#define UE4SS_SDK_HE_Subtitle_HPP

struct FHE_Subtitle
{
    FText SubtitleText_6_6BCC1FAE4AA18AB3A2C109B289F03ECC;                            // 0x0000 (size: 0x18)
    class USoundBase* SubtitleSound_7_F7B3336B46D26792EC7D11B38686BB07;               // 0x0018 (size: 0x8)
    bool Soundis3D_29_AC97CC71400FF9784591338B5C6BC8B7;                               // 0x0020 (size: 0x1)
    FHE_SubtitleSub AttachSettingsIfSoundis3D_39_9AD9772245A27FB5452EC09DB720CB1F;    // 0x0028 (size: 0x20)
    float ModifyDuration+or-Sec_46_08FC403D464A20C6CBF55A82BF774C1F;                  // 0x0048 (size: 0x4)

}; // Size: 0x4C

#endif
