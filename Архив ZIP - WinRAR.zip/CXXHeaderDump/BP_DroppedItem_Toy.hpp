#ifndef UE4SS_SDK_BP_DroppedItem_Toy_HPP
#define UE4SS_SDK_BP_DroppedItem_Toy_HPP

class ABP_DroppedItem_Toy_C : public ABP_DroppedItem_C
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x0270 (size: 0x8)
    class UAudioComponent* Audio;                                                     // 0x0278 (size: 0x8)
    float Glow_Alpha_301BE3A64C64C111B293B5B4B5BFB3F9;                                // 0x0280 (size: 0x4)
    TEnumAsByte<ETimelineDirection::Type> Glow__Direction_301BE3A64C64C111B293B5B4B5BFB3F9; // 0x0284 (size: 0x1)
    class UTimelineComponent* Glow;                                                   // 0x0288 (size: 0x8)
    FString PlushieID;                                                                // 0x0290 (size: 0x10)
    bool IsSpawnedToy;                                                                // 0x02A0 (size: 0x1)
    FString LastHitObject;                                                            // 0x02A8 (size: 0x10)
    class UMaterialInstanceDynamic* DynamicMat;                                       // 0x02B8 (size: 0x8)

    void UserConstructionScript();
    void Glow__FinishedFunc();
    void Glow__UpdateFunc();
    void BndEvt__BP_DroppedItem_Toy_ItemMesh_K2Node_ComponentBoundEvent_0_ComponentHitSignature__DelegateSignature(class UPrimitiveComponent* HitComponent, class AActor* OtherActor, class UPrimitiveComponent* OtherComp, FVector NormalImpulse, const FHitResult& Hit);
    void ReceiveBeginPlay();
    void GlowEyes();
    void ExecuteUbergraph_BP_DroppedItem_Toy(int32 EntryPoint);
}; // Size: 0x2C0

#endif
