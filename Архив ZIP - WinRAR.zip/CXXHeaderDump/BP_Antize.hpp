#ifndef UE4SS_SDK_BP_Antize_HPP
#define UE4SS_SDK_BP_Antize_HPP

class UBP_Antize_C : public UBlueprintFunctionLibrary
{

    void UnlockMission(FString MissionDTRow, class UObject* __WorldContext);
    void SaveMainGame(class UBP_MySaveGame_C* SaveGame, class UObject* __WorldContext);
    void Save Slot(class UBP_MySaveGame_C* SaveGame, class UObject* __WorldContext, bool& Success);
    void Load Saves(class UObject* __WorldContext, class UBP_MySaveGame_C*& SaveGame);
    void Finished Level Lobby Hard(int32 LevelIndex, float Time, class UObject* __WorldContext);
    void Finished Level Lobby Normal(int32 LevelIndex, float Time, class UObject* __WorldContext);
    void CreateNewLobbySave(class UObject* __WorldContext, class UBP_LobbySaveGame_C*& SaveGame);
    void GetLobbySaveGame(class UObject* __WorldContext, class UBP_LobbySaveGame_C*& SaveGame);
    void Finished Level Lobby Easy(int32 LevelIndex, float Time, class UObject* __WorldContext);
    void Create New Save File(class UObject* __WorldContext, class UBP_MySaveGame_C*& SaveGame);
    void FinishedLevel(int32 LevelIndex, float Time, class UObject* __WorldContext);
    void Get Save Game(class UObject* __WorldContext, class UBP_MySaveGame_C*& SaveGame);
    void FinishedCutscene(class UObject* __WorldContext);
    void SaveGame(class UBP_MySaveGame_C* SaveGame, class UObject* __WorldContext);
    void ConvertStringToFloat(FString In, class UObject* __WorldContext, float& Out);
    void FinishedEndScene(class UObject* __WorldContext);
}; // Size: 0x28

#endif
