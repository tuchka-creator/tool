#ifndef UE4SS_SDK_BP_Moth_HPP
#define UE4SS_SDK_BP_Moth_HPP

class ABP_Moth_C : public ACharacter
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x04C0 (size: 0x8)
    class UAudioComponent* Audio1;                                                    // 0x04C8 (size: 0x8)
    class USceneComponent* Scene;                                                     // 0x04D0 (size: 0x8)
    class UCameraComponent* Camera;                                                   // 0x04D8 (size: 0x8)
    class USkeletalMeshComponent* AttachedPlayer;                                     // 0x04E0 (size: 0x8)
    class USceneComponent* EyeSight;                                                  // 0x04E8 (size: 0x8)
    class USphereComponent* KillPlayer;                                               // 0x04F0 (size: 0x8)
    class UAudioComponent* Audio;                                                     // 0x04F8 (size: 0x8)
    float ToggleState_Alpha_B3C7BB3D404C6E94D9311B9279D18EDC;                         // 0x0500 (size: 0x4)
    TEnumAsByte<ETimelineDirection::Type> ToggleState__Direction_B3C7BB3D404C6E94D9311B9279D18EDC; // 0x0504 (size: 0x1)
    class UTimelineComponent* ToggleState;                                            // 0x0508 (size: 0x8)
    bool ShouldMove;                                                                  // 0x0510 (size: 0x1)
    bool CanAttack;                                                                   // 0x0511 (size: 0x1)
    bool StartIdle;                                                                   // 0x0512 (size: 0x1)
    FTransform IdleTransform;                                                         // 0x0520 (size: 0x30)
    bool IsIdle;                                                                      // 0x0550 (size: 0x1)
    FTransform StartTransform;                                                        // 0x0560 (size: 0x30)
    class ABPCharacter_Demo_C* Attached;                                              // 0x0590 (size: 0x8)
    class AActor* HiveLocation;                                                       // 0x0598 (size: 0x8)
    bool IsCarrying;                                                                  // 0x05A0 (size: 0x1)
    bool ShouldTrigger;                                                               // 0x05A1 (size: 0x1)
    class APlayerController* CarryingController;                                      // 0x05A8 (size: 0x8)
    bool LargerRadius;                                                                // 0x05B0 (size: 0x1)
    float ChaseSpeed;                                                                 // 0x05B4 (size: 0x4)

    void OnRep_IsIdle();
    void CanSeePlayer(class ABPCharacter_Demo_C* Target, bool& CanSee);
    void LookAtTarget(class ABPCharacter_Demo_C* Target);
    void StopMovement();
    void LookAtEntity(class ABPCharacter_Demo_C* Target);
    void ToggleState__FinishedFunc();
    void ToggleState__UpdateFunc();
    void OnFail_01FE13E14A76136BD0F89EBBB3E97A95(TEnumAsByte<EPathFollowingResult::Type> MovementResult);
    void OnSuccess_01FE13E14A76136BD0F89EBBB3E97A95(TEnumAsByte<EPathFollowingResult::Type> MovementResult);
    void OnFail_80D0F13747A7105F75433DB2011DDF34(TEnumAsByte<EPathFollowingResult::Type> MovementResult);
    void OnSuccess_80D0F13747A7105F75433DB2011DDF34(TEnumAsByte<EPathFollowingResult::Type> MovementResult);
    void OnNotifyEnd_826A0D8B4B2AF71A79AA649436631992(FName NotifyName);
    void OnNotifyBegin_826A0D8B4B2AF71A79AA649436631992(FName NotifyName);
    void OnInterrupted_826A0D8B4B2AF71A79AA649436631992(FName NotifyName);
    void OnBlendOut_826A0D8B4B2AF71A79AA649436631992(FName NotifyName);
    void OnCompleted_826A0D8B4B2AF71A79AA649436631992(FName NotifyName);
    void ReceiveBeginPlay();
    void StartSound();
    void StopSound();
    void AttackPlayer(class ABPCharacter_Demo_C* Player);
    void MC_KillSound();
    void MC_AttackAnimation();
    void Retreat();
    void ResetRetreat();
    void BndEvt__BP_Hound_KillPlayer_K2Node_ComponentBoundEvent_0_ComponentBeginOverlapSignature__DelegateSignature(class UPrimitiveComponent* OverlappedComponent, class AActor* OtherActor, class UPrimitiveComponent* OtherComp, int32 OtherBodyIndex, bool bFromSweep, const FHitResult& SweepResult);
    void ToggleIdle(bool IsIdle);
    void BringToHive();
    void ResetBringToHive();
    void DropPlayer(bool ShouldAttack);
    void StartCarry();
    void StopCarry();
    void ResetAttack();
    void MC_WarnPlayer();
    void WarnPlayer();
    void ExecuteUbergraph_BP_Moth(int32 EntryPoint);
}; // Size: 0x5B8

#endif
