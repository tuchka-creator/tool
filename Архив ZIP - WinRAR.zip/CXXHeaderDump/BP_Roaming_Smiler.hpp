#ifndef UE4SS_SDK_BP_Roaming_Smiler_HPP
#define UE4SS_SDK_BP_Roaming_Smiler_HPP

class ABP_Roaming_Smiler_C : public ACharacter
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x04C0 (size: 0x8)
    class UNiagaraComponent* SmilerParticles;                                         // 0x04C8 (size: 0x8)
    class USphereComponent* KillPlayer;                                               // 0x04D0 (size: 0x8)
    class USceneComponent* EyeSight;                                                  // 0x04D8 (size: 0x8)
    float FadeOutTimeline_FaceAlpha_769FB86144B6D854E427E98D01BA9D90;                 // 0x04E0 (size: 0x4)
    float FadeOutTimeline_SpawningAlpha_769FB86144B6D854E427E98D01BA9D90;             // 0x04E4 (size: 0x4)
    TEnumAsByte<ETimelineDirection::Type> FadeOutTimeline__Direction_769FB86144B6D854E427E98D01BA9D90; // 0x04E8 (size: 0x1)
    class UTimelineComponent* FadeOutTimeline;                                        // 0x04F0 (size: 0x8)
    float FadeInTimeline_FaceAlpha_EF9CBF9C4277DF77AE097DA92E3846B4;                  // 0x04F8 (size: 0x4)
    float FadeInTimeline_FaceCurve_EF9CBF9C4277DF77AE097DA92E3846B4;                  // 0x04FC (size: 0x4)
    TEnumAsByte<ETimelineDirection::Type> FadeInTimeline__Direction_EF9CBF9C4277DF77AE097DA92E3846B4; // 0x0500 (size: 0x1)
    class UTimelineComponent* FadeInTimeline;                                         // 0x0508 (size: 0x8)
    float Fade_Opacity_ADBC832D4681FEF92D7330A684596D62;                              // 0x0510 (size: 0x4)
    TEnumAsByte<ETimelineDirection::Type> Fade__Direction_ADBC832D4681FEF92D7330A684596D62; // 0x0514 (size: 0x1)
    class UTimelineComponent* Fade;                                                   // 0x0518 (size: 0x8)
    float Timeline_1_Speed_3CBDCD1D4510EF422C9CAF8E372DFAA5;                          // 0x0520 (size: 0x4)
    TEnumAsByte<ETimelineDirection::Type> Timeline_1__Direction_3CBDCD1D4510EF422C9CAF8E372DFAA5; // 0x0524 (size: 0x1)
    class UTimelineComponent* Timeline_1;                                             // 0x0528 (size: 0x8)
    class ANoClipVolume* NoClipVolume;                                                // 0x0530 (size: 0x8)
    FVector StartingLocation;                                                         // 0x0538 (size: 0xC)
    bool CanAttack;                                                                   // 0x0544 (size: 0x1)
    bool ShouldMove;                                                                  // 0x0545 (size: 0x1)
    class UBehaviorTree* Behavior Tree;                                               // 0x0548 (size: 0x8)
    float WalkSpeed;                                                                  // 0x0550 (size: 0x4)
    float SprintingSpeed;                                                             // 0x0554 (size: 0x4)
    class UMaterialInstanceDynamic* DynamicMat;                                       // 0x0558 (size: 0x8)
    FTimerHandle TimerHandle;                                                         // 0x0560 (size: 0x8)
    bool IsVisible;                                                                   // 0x0568 (size: 0x1)
    bool IsAttacking;                                                                 // 0x0569 (size: 0x1)

    void SetupSmilerParticles();
    void OnRep_IsVisible();
    void CheckPlayersTimer();
    void CanSeePlayer(class ABPCharacter_Demo_C* Target, bool& CanSee);
    void LookAtPlayer(class ABPCharacter_Demo_C* Target);
    void StopMovement();
    void lookAt(class ABPCharacter_Demo_C* Target);
    void Timeline_1__FinishedFunc();
    void Timeline_1__UpdateFunc();
    void Fade__FinishedFunc();
    void Fade__UpdateFunc();
    void FadeOutTimeline__FinishedFunc();
    void FadeOutTimeline__UpdateFunc();
    void FadeInTimeline__FinishedFunc();
    void FadeInTimeline__UpdateFunc();
    void ReceiveBeginPlay();
    void AttackPlayer(class ABPCharacter_Demo_C* Player);
    void MC_Jumpscare();
    void ToggleSprint(bool IsSprinting);
    void OnSpotted();
    void ResetSpotted();
    void OnQueryFinished(class UEnvQueryInstanceBlueprintWrapper* QueryInstance, TEnumAsByte<EEnvQueryStatus::Type> QueryStatus);
    void FindTeleportLocation();
    void BndEvt__Bacteria_Roaming_BP_KillPlayer_K2Node_ComponentBoundEvent_0_ComponentBeginOverlapSignature__DelegateSignature(class UPrimitiveComponent* OverlappedComponent, class AActor* OtherActor, class UPrimitiveComponent* OtherComp, int32 OtherBodyIndex, bool bFromSweep, const FHitResult& SweepResult);
    void FadeOut();
    void FadeIn();
    void FadeInParticles();
    void FadeOutParticles();
    void ExecuteUbergraph_BP_Roaming_Smiler(int32 EntryPoint);
}; // Size: 0x56A

#endif
