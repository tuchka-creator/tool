namespace FluidDynamicForceMeshType {
    enum Type {
        NewEnumerator0 = 0,
        NewEnumerator1 = 1,
        FluidDynamicForceMeshType_MAX = 2,
    };
}

