#ifndef UE4SS_SDK_BP_DroppedItem_LiDAR_HPP
#define UE4SS_SDK_BP_DroppedItem_LiDAR_HPP

class ABP_DroppedItem_LiDAR_C : public ABP_DroppedItem_C
{
    class UStaticMeshComponent* Display;                                              // 0x0270 (size: 0x8)
    class USkeletalMeshComponent* SkeletalMesh;                                       // 0x0278 (size: 0x8)

}; // Size: 0x280

#endif
