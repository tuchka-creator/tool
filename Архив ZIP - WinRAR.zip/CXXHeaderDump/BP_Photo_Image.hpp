#ifndef UE4SS_SDK_BP_Photo_Image_HPP
#define UE4SS_SDK_BP_Photo_Image_HPP

class ABP_Photo_Image_C : public AClientInteractableActor
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x0248 (size: 0x8)
    int32 PictureIndex;                                                               // 0x0250 (size: 0x4)
    class UTexture* Texture;                                                          // 0x0258 (size: 0x8)

    void UserConstructionScript();
    void OnActorUsed(class ACharacter* Character);
    void MC_UpdateImage(int32 Players);
    void ExecuteUbergraph_BP_Photo_Image(int32 EntryPoint);
}; // Size: 0x260

#endif
