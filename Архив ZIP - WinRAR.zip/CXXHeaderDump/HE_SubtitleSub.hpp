#ifndef UE4SS_SDK_HE_SubtitleSub_HPP
#define UE4SS_SDK_HE_SubtitleSub_HPP

struct FHE_SubtitleSub
{
    class AActor* AttachtoActor_41_AC97CC71400FF9784591338B5C6BC8B7;                  // 0x0000 (size: 0x8)
    bool AttachtoTaggedActorSkipSelected_37_9BFE789D4F1D8626EBACA6B1C7D34015;         // 0x0008 (size: 0x1)
    FName ActorTag_42_E5B1EB5C4F918022B4B172B7C66EF8DA;                               // 0x000C (size: 0x8)
    class USoundAttenuation* SoundAttenuation_45_CF61DBA34A0D2CF70CB600849E358855;    // 0x0018 (size: 0x8)

}; // Size: 0x20

#endif
