#ifndef UE4SS_SDK_BP_EULA_Flow_HPP
#define UE4SS_SDK_BP_EULA_Flow_HPP

class UBP_EULA_Flow_C : public UFancyUserFlow
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x00A8 (size: 0x8)
    FString GameSettings_SlotName;                                                    // 0x00B0 (size: 0x10)
    class UWidget* PrevFocusedWidget;                                                 // 0x00C0 (size: 0x8)
    bool bDidAcceptEULA;                                                              // 0x00C8 (size: 0x1)
    bool bDebugEULA;                                                                  // 0x00C9 (size: 0x1)

    void Run();
    void PrepareModal(class UUserWidget* Modal);
    void OnCompleteModal(class UUserWidget* Modal);
    void ExecuteUbergraph_BP_EULA_Flow(int32 EntryPoint);
}; // Size: 0xCA

#endif
