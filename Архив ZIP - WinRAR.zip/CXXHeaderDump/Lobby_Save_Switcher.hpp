#ifndef UE4SS_SDK_Lobby_Save_Switcher_HPP
#define UE4SS_SDK_Lobby_Save_Switcher_HPP

class ULobby_Save_Switcher_C : public UUserWidget
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x0270 (size: 0x8)
    class UButton* Left_Btn;                                                          // 0x0278 (size: 0x8)
    class UButton* Right_Btn;                                                         // 0x0280 (size: 0x8)
    class USizeBox* SizeBox_27;                                                       // 0x0288 (size: 0x8)
    class USizeBox* SizeBox_Left_Btn;                                                 // 0x0290 (size: 0x8)
    class USizeBox* SizeBox_Right_Btn;                                                // 0x0298 (size: 0x8)
    class UTextBlock* TextBlock;                                                      // 0x02A0 (size: 0x8)
    FString SelectedOption;                                                           // 0x02A8 (size: 0x10)
    bool Allow_OptionLooping?;                                                        // 0x02B8 (size: 0x1)
    FLobby_Save_Switcher_COnSaveSwitched OnSaveSwitched;                              // 0x02C0 (size: 0x10)
    void OnSaveSwitched(FString SelectedOption);
    TArray<FString> Options;                                                          // 0x02D0 (size: 0x10)
    float Widget_Width;                                                               // 0x02E0 (size: 0x4)
    float Left_Btn_Width;                                                             // 0x02E4 (size: 0x4)
    float Right_Btn_Width;                                                            // 0x02E8 (size: 0x4)
    float Widget_Height;                                                              // 0x02EC (size: 0x4)
    int32 Font Size;                                                                  // 0x02F0 (size: 0x4)

    void TitleCase(FString In, FString& Out);
    void Update Options();
    void Set_OptionButtons_Visibility(bool ShowOptionButtons?);
    void SetUp();
    void Set_SelectedOption(FString SelectedOption);
    void Switch_Option(bool Decrease?);
    void CanClose();
    void PreConstruct(bool IsDesignTime);
    void BndEvt__WB_OptionSwitcher_Decrease_Btn_K2Node_ComponentBoundEvent_0_OnButtonClickedEvent__DelegateSignature();
    void BndEvt__WB_OptionSwitcher_Increase_Btn_K2Node_ComponentBoundEvent_1_OnButtonClickedEvent__DelegateSignature();
    void ExecuteUbergraph_Lobby_Save_Switcher(int32 EntryPoint);
    void OnSaveSwitched__DelegateSignature(FString SelectedOption);
}; // Size: 0x2F4

#endif
