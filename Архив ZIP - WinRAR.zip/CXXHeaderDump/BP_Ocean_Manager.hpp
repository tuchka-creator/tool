#ifndef UE4SS_SDK_BP_Ocean_Manager_HPP
#define UE4SS_SDK_BP_Ocean_Manager_HPP

class ABP_Ocean_Manager_C : public AActor
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x0220 (size: 0x8)
    class USceneComponent* DefaultSceneRoot;                                          // 0x0228 (size: 0x8)
    float ToggleWaves_Alpha2_B7D3808C4A2D1DC6DE8224867DB25EFF;                        // 0x0230 (size: 0x4)
    float ToggleWaves_Alpha_B7D3808C4A2D1DC6DE8224867DB25EFF;                         // 0x0234 (size: 0x4)
    TEnumAsByte<ETimelineDirection::Type> ToggleWaves__Direction_B7D3808C4A2D1DC6DE8224867DB25EFF; // 0x0238 (size: 0x1)
    class UTimelineComponent* ToggleWaves;                                            // 0x0240 (size: 0x8)
    class A8_FFT_H_Ocean_Sim_C* Ocean;                                                // 0x0248 (size: 0x8)
    class AExponentialHeightFog* Fog;                                                 // 0x0250 (size: 0x8)
    float TargetAmplitude;                                                            // 0x0258 (size: 0x4)
    float TargetHeight;                                                               // 0x025C (size: 0x4)
    float TargetSpeed;                                                                // 0x0260 (size: 0x4)
    float TargetChoppyness;                                                           // 0x0264 (size: 0x4)
    float TargetWind;                                                                 // 0x0268 (size: 0x4)
    float StartingAmplitude;                                                          // 0x026C (size: 0x4)
    float StartingHeight;                                                             // 0x0270 (size: 0x4)
    float StartingSpeed;                                                              // 0x0274 (size: 0x4)
    float StartingChoppyness;                                                         // 0x0278 (size: 0x4)
    float StartingWind;                                                               // 0x027C (size: 0x4)
    float StartingTile;                                                               // 0x0280 (size: 0x4)
    float TargetFog;                                                                  // 0x0284 (size: 0x4)
    TArray<class ABP_RowBoat_C*> Boats;                                               // 0x0288 (size: 0x10)
    float StartingFog;                                                                // 0x0298 (size: 0x4)
    bool ShouldSpawn;                                                                 // 0x029C (size: 0x1)
    FTimerHandle TimerHandle;                                                         // 0x02A0 (size: 0x8)
    class ABPCharacter_Demo_C* CurrentTarget;                                         // 0x02A8 (size: 0x8)
    class ABP_Storm_Volume_C* StormZone;                                              // 0x02B0 (size: 0x8)

    void Find Target Player(class ABPCharacter_Demo_C*& TargetPlayer);
    void UpdateDrowning(bool Rising);
    void UpdateBuoyancy(bool Rising);
    void ToggleWaves__FinishedFunc();
    void ToggleWaves__UpdateFunc();
    void ToggleWaves__UpdateDrowning__EventFunc();
    void ToggleWaves__UpdateBuoyancy__EventFunc();
    void ReceiveBeginPlay();
    void StartRisingWaves();
    void StopRisingWaves();
    void UpdateWaterSettings();
    void FindTarget();
    void StartSpawnTimer();
    void StopSpawnTimer();
    void ExecuteUbergraph_BP_Ocean_Manager(int32 EntryPoint);
}; // Size: 0x2B8

#endif
