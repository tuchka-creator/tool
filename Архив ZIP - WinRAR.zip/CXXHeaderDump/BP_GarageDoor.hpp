#ifndef UE4SS_SDK_BP_GarageDoor_HPP
#define UE4SS_SDK_BP_GarageDoor_HPP

class ABP_GarageDoor_C : public AInteractableActor
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x0248 (size: 0x8)
    float OpenDoor_Z_D48E7478466D1C3E2A5AC980B047B010;                                // 0x0250 (size: 0x4)
    TEnumAsByte<ETimelineDirection::Type> OpenDoor__Direction_D48E7478466D1C3E2A5AC980B047B010; // 0x0254 (size: 0x1)
    class UTimelineComponent* OpenDoor;                                               // 0x0258 (size: 0x8)

    void OpenDoor__FinishedFunc();
    void OpenDoor__UpdateFunc();
    void OnUsedNotify();
    void Open();
    void CloseDoor();
    void OnActorUsed(class ACharacter* Character);
    void ExecuteUbergraph_BP_GarageDoor(int32 EntryPoint);
}; // Size: 0x260

#endif
