#ifndef UE4SS_SDK_BP_Lighthouse_HPP
#define UE4SS_SDK_BP_Lighthouse_HPP

class ABP_Lighthouse_C : public AActor
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x0220 (size: 0x8)
    class UStaticMeshComponent* StaticMesh1;                                          // 0x0228 (size: 0x8)
    class UStaticMeshComponent* StaticMesh;                                           // 0x0230 (size: 0x8)
    class UStaticMeshComponent* SM_Fresnel_Lens01;                                    // 0x0238 (size: 0x8)
    class USpotLightComponent* SpotLight;                                             // 0x0240 (size: 0x8)
    class USpotLightComponent* SpotLight1;                                            // 0x0248 (size: 0x8)
    class UStaticMeshComponent* SM_Fresnel_Lens_Platform;                             // 0x0250 (size: 0x8)
    class USceneComponent* DefaultSceneRoot;                                          // 0x0258 (size: 0x8)
    float Fade_Alpha_6D981B96455834514324CF9A1C18F71A;                                // 0x0260 (size: 0x4)
    TEnumAsByte<ETimelineDirection::Type> Fade__Direction_6D981B96455834514324CF9A1C18F71A; // 0x0264 (size: 0x1)
    class UTimelineComponent* Fade;                                                   // 0x0268 (size: 0x8)
    float Rotate_Rotation_D698AB5545F00D2C9CF65CB9F4EF3B02;                           // 0x0270 (size: 0x4)
    TEnumAsByte<ETimelineDirection::Type> Rotate__Direction_D698AB5545F00D2C9CF65CB9F4EF3B02; // 0x0274 (size: 0x1)
    class UTimelineComponent* Rotate;                                                 // 0x0278 (size: 0x8)
    bool IsOn;                                                                        // 0x0280 (size: 0x1)
    FTimerHandle LighthouseTimer;                                                     // 0x0288 (size: 0x8)
    class UStaticMeshComponent* GodRayMesh;                                           // 0x0290 (size: 0x8)
    float Width;                                                                      // 0x0298 (size: 0x4)
    float Length;                                                                     // 0x029C (size: 0x4)
    class UMaterialInstanceDynamic* Dynamic material;                                 // 0x02A0 (size: 0x8)
    FLinearColor Color;                                                               // 0x02A8 (size: 0x10)
    float Brightness;                                                                 // 0x02B8 (size: 0x4)
    float FadeDistance;                                                               // 0x02BC (size: 0x4)
    class UMaterialInstanceDynamic* Dynamic material_0;                               // 0x02C0 (size: 0x8)
    float StartingZ;                                                                  // 0x02C8 (size: 0x4)
    class UMaterialInstanceDynamic* DynamicLensMat;                                   // 0x02D0 (size: 0x8)

    void Play Lighthouse();
    void OnRep_IsOn();
    void UserConstructionScript();
    void Rotate__FinishedFunc();
    void Rotate__UpdateFunc();
    void Rotate__Fade__EventFunc();
    void Rotate__PlayHorn__EventFunc();
    void Fade__FinishedFunc();
    void Fade__UpdateFunc();
    void Start();
    void StartTimer();
    void StopTimer();
    void FadeOut();
    void FadeIn();
    void ReceiveBeginPlay();
    void ExecuteUbergraph_BP_Lighthouse(int32 EntryPoint);
}; // Size: 0x2D8

#endif
