#ifndef UE4SS_SDK_AnimBP_Ladder_HPP
#define UE4SS_SDK_AnimBP_Ladder_HPP

class UAnimBP_Ladder_C : public UAnimInstance
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x02C0 (size: 0x8)
    FAnimNode_Root AnimGraphNode_Root;                                                // 0x02C8 (size: 0x30)
    FAnimNode_RefPose AnimGraphNode_LocalRefPose_2;                                   // 0x02F8 (size: 0x18)
    FAnimNode_LayeredBoneBlend AnimGraphNode_LayeredBoneBlend;                        // 0x0310 (size: 0xC0)
    FAnimNode_Slot AnimGraphNode_Slot_4;                                              // 0x03D0 (size: 0x48)
    FAnimNode_Slot AnimGraphNode_Slot_3;                                              // 0x0418 (size: 0x48)
    FAnimNode_RefPose AnimGraphNode_LocalRefPose_1;                                   // 0x0460 (size: 0x18)
    FAnimNode_RefPose AnimGraphNode_LocalRefPose;                                     // 0x0478 (size: 0x18)
    FAnimNode_Slot AnimGraphNode_Slot_2;                                              // 0x0490 (size: 0x48)
    FAnimNode_Slot AnimGraphNode_Slot_1;                                              // 0x04D8 (size: 0x48)
    FAnimNode_Slot AnimGraphNode_Slot;                                                // 0x0520 (size: 0x48)

    void AnimGraph(FPoseLink& AnimGraph);
    void ExecuteUbergraph_AnimBP_Ladder(int32 EntryPoint);
}; // Size: 0x568

#endif
