#ifndef UE4SS_SDK_BP_KickedFlow_HPP
#define UE4SS_SDK_BP_KickedFlow_HPP

class UBP_KickedFlow_C : public UFancyUserFlow
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x00A8 (size: 0x8)
    class APlayerController* Player Controller;                                       // 0x00B0 (size: 0x8)
    class UWidget* FocusedWidget;                                                     // 0x00B8 (size: 0x8)

    void OnFailure_FBDAD5C446F1373DD18C038593EB13E1();
    void OnSuccess_FBDAD5C446F1373DD18C038593EB13E1();
    void Run();
    void ExecuteUbergraph_BP_KickedFlow(int32 EntryPoint);
}; // Size: 0xC0

#endif
