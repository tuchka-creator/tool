#ifndef UE4SS_SDK_ChaosVehicles_HPP
#define UE4SS_SDK_ChaosVehicles_HPP

#include "ChaosVehicles_enums.hpp"

struct FAnimNode_WheelController : public FAnimNode_SkeletalControlBase
{
}; // Size: 0xE0

struct FChaosWheelSetup
{
    TSubclassOf<class UChaosVehicleWheel> WheelClass;                                 // 0x0000 (size: 0x8)
    FName BoneName;                                                                   // 0x0008 (size: 0x8)
    FVector AdditionalOffset;                                                         // 0x0010 (size: 0xC)

}; // Size: 0x20

struct FVehicleAerofoilConfig
{
    EVehicleAerofoilType AerofoilType;                                                // 0x0000 (size: 0x1)
    FName BoneName;                                                                   // 0x0004 (size: 0x8)
    FVector Offset;                                                                   // 0x000C (size: 0xC)
    FVector UpAxis;                                                                   // 0x0018 (size: 0xC)
    float Area;                                                                       // 0x0024 (size: 0x4)
    float Camber;                                                                     // 0x0028 (size: 0x4)
    float MaxControlAngle;                                                            // 0x002C (size: 0x4)
    float StallAngle;                                                                 // 0x0030 (size: 0x4)
    float LiftMultiplier;                                                             // 0x0034 (size: 0x4)
    float DragMultiplier;                                                             // 0x0038 (size: 0x4)

}; // Size: 0x78

struct FVehicleAnimationInstanceProxy : public FAnimInstanceProxy
{
}; // Size: 0x780

struct FVehicleDifferentialConfig
{
    EVehicleDifferential DifferentialType;                                            // 0x0000 (size: 0x1)
    float FrontRearSplit;                                                             // 0x0004 (size: 0x4)

}; // Size: 0x8

struct FVehicleEngineConfig
{
    FRuntimeFloatCurve TorqueCurve;                                                   // 0x0000 (size: 0x88)
    float MaxTorque;                                                                  // 0x0088 (size: 0x4)
    float MaxRPM;                                                                     // 0x008C (size: 0x4)
    float EngineIdleRPM;                                                              // 0x0090 (size: 0x4)
    float EngineBrakeEffect;                                                          // 0x0094 (size: 0x4)
    float EngineRevUpMOI;                                                             // 0x0098 (size: 0x4)
    float EngineRevDownRate;                                                          // 0x009C (size: 0x4)

}; // Size: 0xC8

struct FVehicleInputRateConfig
{
    float RiseRate;                                                                   // 0x0000 (size: 0x4)
    float FallRate;                                                                   // 0x0004 (size: 0x4)

}; // Size: 0x8

struct FVehicleReplicatedState
{
    float SteeringInput;                                                              // 0x0000 (size: 0x4)
    float ThrottleInput;                                                              // 0x0004 (size: 0x4)
    float BrakeInput;                                                                 // 0x0008 (size: 0x4)
    float PitchInput;                                                                 // 0x000C (size: 0x4)
    float RollInput;                                                                  // 0x0010 (size: 0x4)
    float YawInput;                                                                   // 0x0014 (size: 0x4)
    float HandbrakeInput;                                                             // 0x0018 (size: 0x4)
    int32 TargetGear;                                                                 // 0x001C (size: 0x4)
    float ThrottleUp;                                                                 // 0x0020 (size: 0x4)
    float ThrottleDown;                                                               // 0x0024 (size: 0x4)

}; // Size: 0x28

struct FVehicleStabilizeControlConfig
{
    bool Enabled;                                                                     // 0x0000 (size: 0x1)
    float AltitudeHoldZ;                                                              // 0x0004 (size: 0x4)
    float PositionHoldXY;                                                             // 0x0008 (size: 0x4)

}; // Size: 0xC

struct FVehicleSteeringConfig
{
    ESteeringType SteeringType;                                                       // 0x0000 (size: 0x1)
    float AngleRatio;                                                                 // 0x0004 (size: 0x4)
    FRuntimeFloatCurve SteeringCurve;                                                 // 0x0008 (size: 0x88)

}; // Size: 0xB8

struct FVehicleTargetRotationControlConfig
{
    bool Enabled;                                                                     // 0x0000 (size: 0x1)
    bool bRollVsSpeedEnabled;                                                         // 0x0001 (size: 0x1)
    float RollControlScaling;                                                         // 0x0004 (size: 0x4)
    float RollMaxAngle;                                                               // 0x0008 (size: 0x4)
    float PitchControlScaling;                                                        // 0x000C (size: 0x4)
    float PitchMaxAngle;                                                              // 0x0010 (size: 0x4)
    float RotationStiffness;                                                          // 0x0014 (size: 0x4)
    float RotationDamping;                                                            // 0x0018 (size: 0x4)
    float MaxAccel;                                                                   // 0x001C (size: 0x4)
    float AutoCentreRollStrength;                                                     // 0x0020 (size: 0x4)
    float AutoCentrePitchStrength;                                                    // 0x0024 (size: 0x4)
    float AutoCentreYawStrength;                                                      // 0x0028 (size: 0x4)

}; // Size: 0x2C

struct FVehicleThrustConfig
{
    EVehicleThrustType ThrustType;                                                    // 0x0000 (size: 0x1)
    FName BoneName;                                                                   // 0x0004 (size: 0x8)
    FVector Offset;                                                                   // 0x000C (size: 0xC)
    FVector ThrustAxis;                                                               // 0x0018 (size: 0xC)
    float MaxThrustForce;                                                             // 0x0024 (size: 0x4)
    float MaxControlAngle;                                                            // 0x0028 (size: 0x4)

}; // Size: 0x70

struct FVehicleTorqueControlConfig
{
    bool Enabled;                                                                     // 0x0000 (size: 0x1)
    float YawTorqueScaling;                                                           // 0x0004 (size: 0x4)
    float YawFromSteering;                                                            // 0x0008 (size: 0x4)
    float YawFromRollTorqueScaling;                                                   // 0x000C (size: 0x4)
    float PitchTorqueScaling;                                                         // 0x0010 (size: 0x4)
    float RollTorqueScaling;                                                          // 0x0014 (size: 0x4)
    float RollFromSteering;                                                           // 0x0018 (size: 0x4)
    float RotationDamping;                                                            // 0x001C (size: 0x4)

}; // Size: 0x20

struct FVehicleTransmissionConfig
{
    bool bUseAutomaticGears;                                                          // 0x0000 (size: 0x1)
    bool bUseAutoReverse;                                                             // 0x0001 (size: 0x1)
    float FinalRatio;                                                                 // 0x0004 (size: 0x4)
    TArray<float> ForwardGearRatios;                                                  // 0x0008 (size: 0x10)
    TArray<float> ReverseGearRatios;                                                  // 0x0018 (size: 0x10)
    float ChangeUpRPM;                                                                // 0x0028 (size: 0x4)
    float ChangeDownRPM;                                                              // 0x002C (size: 0x4)
    float GearChangeTime;                                                             // 0x0030 (size: 0x4)
    float TransmissionEfficiency;                                                     // 0x0034 (size: 0x4)

}; // Size: 0x70

struct FWheelStatus
{
    bool bInContact;                                                                  // 0x0000 (size: 0x1)
    FVector ContactPoint;                                                             // 0x0004 (size: 0xC)
    TWeakObjectPtr<class UPhysicalMaterial> PhysMaterial;                             // 0x0010 (size: 0x8)
    float NormalizedSuspensionLength;                                                 // 0x0018 (size: 0x4)
    float SpringForce;                                                                // 0x001C (size: 0x4)
    bool bIsSlipping;                                                                 // 0x0020 (size: 0x1)
    float SlipMagnitude;                                                              // 0x0024 (size: 0x4)
    bool bIsSkidding;                                                                 // 0x0028 (size: 0x1)
    float SkidMagnitude;                                                              // 0x002C (size: 0x4)
    FVector SkidNormal;                                                               // 0x0030 (size: 0xC)

}; // Size: 0x3C

class AWheeledVehiclePawn : public APawn
{
    class USkeletalMeshComponent* Mesh;                                               // 0x0280 (size: 0x8)
    class UChaosVehicleMovementComponent* VehicleMovementComponent;                   // 0x0288 (size: 0x8)

}; // Size: 0x290

class UChaosVehicleMovementComponent : public UPawnMovementComponent
{
    uint8 bReverseAsBrake;                                                            // 0x0138 (size: 0x1)
    float Mass;                                                                       // 0x013C (size: 0x4)
    float ChassisWidth;                                                               // 0x0140 (size: 0x4)
    float ChassisHeight;                                                              // 0x0144 (size: 0x4)
    float DragCoefficient;                                                            // 0x0148 (size: 0x4)
    float DownforceCoefficient;                                                       // 0x014C (size: 0x4)
    float DragArea;                                                                   // 0x0150 (size: 0x4)
    float DebugDragMagnitude;                                                         // 0x0154 (size: 0x4)
    FVector InertiaTensorScale;                                                       // 0x0158 (size: 0xC)
    float SleepThreshold;                                                             // 0x0164 (size: 0x4)
    float SleepSlopeLimit;                                                            // 0x0168 (size: 0x4)
    TArray<FVehicleAerofoilConfig> Aerofoils;                                         // 0x0170 (size: 0x10)
    TArray<FVehicleThrustConfig> Thrusters;                                           // 0x0180 (size: 0x10)
    FVehicleTorqueControlConfig TorqueControl;                                        // 0x0190 (size: 0x20)
    FVehicleTargetRotationControlConfig TargetRotationControl;                        // 0x01B0 (size: 0x2C)
    FVehicleStabilizeControlConfig StabilizeControl;                                  // 0x01DC (size: 0xC)
    uint8 bRawHandbrakeInput;                                                         // 0x01EC (size: 0x1)
    uint8 bRawGearUpInput;                                                            // 0x01EC (size: 0x1)
    uint8 bRawGearDownInput;                                                          // 0x01EC (size: 0x1)
    uint8 bWasAvoidanceUpdated;                                                       // 0x01F0 (size: 0x1)
    FVehicleReplicatedState ReplicatedState;                                          // 0x01F4 (size: 0x28)
    float RawSteeringInput;                                                           // 0x0220 (size: 0x4)
    float RawThrottleInput;                                                           // 0x0224 (size: 0x4)
    float RawBrakeInput;                                                              // 0x0228 (size: 0x4)
    float RawPitchInput;                                                              // 0x022C (size: 0x4)
    float RawRollInput;                                                               // 0x0230 (size: 0x4)
    float RawYawInput;                                                                // 0x0234 (size: 0x4)
    float SteeringInput;                                                              // 0x0238 (size: 0x4)
    float ThrottleInput;                                                              // 0x023C (size: 0x4)
    float BrakeInput;                                                                 // 0x0240 (size: 0x4)
    float PitchInput;                                                                 // 0x0244 (size: 0x4)
    float RollInput;                                                                  // 0x0248 (size: 0x4)
    float YawInput;                                                                   // 0x024C (size: 0x4)
    float HandbrakeInput;                                                             // 0x0250 (size: 0x4)
    float IdleBrakeInput;                                                             // 0x0254 (size: 0x4)
    float StopThreshold;                                                              // 0x0258 (size: 0x4)
    float WrongDirectionThreshold;                                                    // 0x025C (size: 0x4)
    FVehicleInputRateConfig ThrottleInputRate;                                        // 0x0260 (size: 0x8)
    FVehicleInputRateConfig BrakeInputRate;                                           // 0x0268 (size: 0x8)
    FVehicleInputRateConfig SteeringInputRate;                                        // 0x0270 (size: 0x8)
    FVehicleInputRateConfig HandbrakeInputRate;                                       // 0x0278 (size: 0x8)
    FVehicleInputRateConfig PitchInputRate;                                           // 0x0280 (size: 0x8)
    FVehicleInputRateConfig RollInputRate;                                            // 0x0288 (size: 0x8)
    FVehicleInputRateConfig YawInputRate;                                             // 0x0290 (size: 0x8)
    class AController* OverrideController;                                            // 0x0380 (size: 0x8)

    void SetYawInput(float Yaw);
    void SetUseAutomaticGears(bool bUseAuto);
    void SetThrottleInput(float Throttle);
    void SetTargetGear(int32 GearNum, bool bImmediate);
    void SetSteeringInput(float Steering);
    void SetRollInput(float Roll);
    void SetPitchInput(float Pitch);
    void SetHandbrakeInput(bool bNewHandbrake);
    void SetChangeUpInput(bool bNewGearUp);
    void SetChangeDownInput(bool bNewGearDown);
    void SetBrakeInput(float Brake);
    void ServerUpdateState(float InSteeringInput, float InThrottleInput, float InBrakeInput, float InHandbrakeInput, int32 InCurrentGear, float InRollInput, float InPitchInput, float InYawInput);
    void IncreaseThrottleInput(float ThrottleDelta);
    bool GetUseAutoGears();
    int32 GetTargetGear();
    float GetForwardSpeedMPH();
    float GetForwardSpeed();
    int32 GetCurrentGear();
    void EnableSelfRighting(bool InState);
    void DecreaseThrottleInput(float ThrottleDelta);
}; // Size: 0x3A0

class UChaosVehicleWheel : public UObject
{
    class UStaticMesh* CollisionMesh;                                                 // 0x0028 (size: 0x8)
    EAxleType AxleType;                                                               // 0x0030 (size: 0x1)
    FVector Offset;                                                                   // 0x0034 (size: 0xC)
    float WheelRadius;                                                                // 0x0040 (size: 0x4)
    float WheelWidth;                                                                 // 0x0044 (size: 0x4)
    float LongitudinalFrictionForceMultiplier;                                        // 0x0048 (size: 0x4)
    float LateralFrictionForceMultiplier;                                             // 0x004C (size: 0x4)
    float SideSlipModifier;                                                           // 0x0050 (size: 0x4)
    float SlipThreshold;                                                              // 0x0054 (size: 0x4)
    float SkidThreshold;                                                              // 0x0058 (size: 0x4)
    float MaxSteerAngle;                                                              // 0x005C (size: 0x4)
    bool bAffectedBySteering;                                                         // 0x0060 (size: 0x1)
    bool bAffectedByBrake;                                                            // 0x0061 (size: 0x1)
    bool bAffectedByHandbrake;                                                        // 0x0062 (size: 0x1)
    bool bAffectedByEngine;                                                           // 0x0063 (size: 0x1)
    bool bABSEnabled;                                                                 // 0x0064 (size: 0x1)
    bool bTractionControlEnabled;                                                     // 0x0065 (size: 0x1)
    FVector SuspensionAxis;                                                           // 0x0068 (size: 0xC)
    FVector SuspensionForceOffset;                                                    // 0x0074 (size: 0xC)
    float SuspensionMaxRaise;                                                         // 0x0080 (size: 0x4)
    float SuspensionMaxDrop;                                                          // 0x0084 (size: 0x4)
    float SuspensionDampingRatio;                                                     // 0x0088 (size: 0x4)
    float WheelLoadRatio;                                                             // 0x008C (size: 0x4)
    float SpringRate;                                                                 // 0x0090 (size: 0x4)
    float SpringPreload;                                                              // 0x0094 (size: 0x4)
    int32 SuspensionSmoothing;                                                        // 0x0098 (size: 0x4)
    float RollbarScaling;                                                             // 0x009C (size: 0x4)
    ESweepShape SweepShape;                                                           // 0x00A0 (size: 0x1)
    ESweepType SweepType;                                                             // 0x00A1 (size: 0x1)
    float MaxBrakeTorque;                                                             // 0x00A4 (size: 0x4)
    float MaxHandBrakeTorque;                                                         // 0x00A8 (size: 0x4)
    class UChaosWheeledVehicleMovementComponent* VehicleSim;                          // 0x00B0 (size: 0x8)
    int32 WheelIndex;                                                                 // 0x00B8 (size: 0x4)
    float DebugLongSlip;                                                              // 0x00BC (size: 0x4)
    float DebugLatSlip;                                                               // 0x00C0 (size: 0x4)
    float DebugNormalizedTireLoad;                                                    // 0x00C4 (size: 0x4)
    float DebugWheelTorque;                                                           // 0x00CC (size: 0x4)
    float DebugLongForce;                                                             // 0x00D0 (size: 0x4)
    float DebugLatForce;                                                              // 0x00D4 (size: 0x4)
    FVector Location;                                                                 // 0x00D8 (size: 0xC)
    FVector OldLocation;                                                              // 0x00E4 (size: 0xC)
    FVector Velocity;                                                                 // 0x00F0 (size: 0xC)

    bool IsInAir();
    float GetSuspensionOffset();
    float GetSteerAngle();
    float GetRotationAngle();
    EAxleType GetAxleType();
}; // Size: 0x218

class UChaosWheeledVehicleMovementComponent : public UChaosVehicleMovementComponent
{
    bool bSuspensionEnabled;                                                          // 0x0398 (size: 0x1)
    bool bWheelFrictionEnabled;                                                       // 0x0399 (size: 0x1)
    TArray<FChaosWheelSetup> WheelSetups;                                             // 0x03A0 (size: 0x10)
    bool bMechanicalSimEnabled;                                                       // 0x03B0 (size: 0x1)
    FVehicleEngineConfig EngineSetup;                                                 // 0x03B8 (size: 0xC8)
    FVehicleDifferentialConfig DifferentialSetup;                                     // 0x0480 (size: 0x8)
    FVehicleTransmissionConfig TransmissionSetup;                                     // 0x0488 (size: 0x70)
    FVehicleSteeringConfig SteeringSetup;                                             // 0x04F8 (size: 0xB8)
    TArray<class UChaosVehicleWheel*> Wheels;                                         // 0x05B0 (size: 0x10)

    FWheelStatus MakeWheelStatus(bool bInContact, FVector& ContactPoint, class UPhysicalMaterial* PhysMaterial, float NormalizedSuspensionLength, float SpringForce, bool bIsSlipping, float SlipMagnitude, bool bIsSkidding, float SkidMagnitude, FVector& SkidNormal);
    FWheelStatus GetWheelState(int32 WheelIndex);
    int32 GetNumWheels();
    float GetEngineRotationSpeed();
    float GetEngineMaxRotationSpeed();
    void EnableWheelFriction(bool InState);
    void EnableSuspension(bool InState);
    void EnableMechanicalSim(bool InState);
    void BreakWheelStatus(const FWheelStatus& Status, bool& bInContact, FVector& ContactPoint, class UPhysicalMaterial*& PhysMaterial, float& NormalizedSuspensionLength, float& SpringForce, bool& bIsSlipping, float& SlipMagnitude, bool& bIsSkidding, float& SkidMagnitude, FVector& SkidNormal);
}; // Size: 0x6A0

class UVehicleAnimationInstance : public UAnimInstance
{
    class UChaosWheeledVehicleMovementComponent* WheeledVehicleComponent;             // 0x0A50 (size: 0x8)

    class AWheeledVehiclePawn* GetVehicle();
}; // Size: 0xA60

#endif
