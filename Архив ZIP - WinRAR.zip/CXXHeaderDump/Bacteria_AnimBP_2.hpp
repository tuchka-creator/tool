#ifndef UE4SS_SDK_Bacteria_AnimBP_2_HPP
#define UE4SS_SDK_Bacteria_AnimBP_2_HPP

class UBacteria_AnimBP_2_C : public UAnimInstance
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x02C0 (size: 0x8)
    FAnimNode_Root AnimGraphNode_Root;                                                // 0x02C8 (size: 0x30)
    FAnimNode_TransitionResult AnimGraphNode_TransitionResult_1;                      // 0x02F8 (size: 0x28)
    FAnimNode_TransitionResult AnimGraphNode_TransitionResult;                        // 0x0320 (size: 0x28)
    FAnimNode_BlendSpacePlayer AnimGraphNode_BlendSpacePlayer;                        // 0x0348 (size: 0xE8)
    FAnimNode_StateResult AnimGraphNode_StateResult_1;                                // 0x0430 (size: 0x30)
    FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer;                            // 0x0460 (size: 0x80)
    FAnimNode_StateResult AnimGraphNode_StateResult;                                  // 0x04E0 (size: 0x30)
    FAnimNode_StateMachine AnimGraphNode_StateMachine;                                // 0x0510 (size: 0xB0)
    float Speed;                                                                      // 0x05C0 (size: 0x4)

    void AnimGraph(FPoseLink& AnimGraph);
    void EvaluateGraphExposedInputs_ExecuteUbergraph_Bacteria_AnimBP_2_AnimGraphNode_TransitionResult_B6EDB8254B991F8BF52B7A8B6284EB0B();
    void EvaluateGraphExposedInputs_ExecuteUbergraph_Bacteria_AnimBP_2_AnimGraphNode_TransitionResult_A772EA35429EB252A7E8E9B61C995325();
    void BlueprintUpdateAnimation(float DeltaTimeX);
    void ExecuteUbergraph_Bacteria_AnimBP_2(int32 EntryPoint);
}; // Size: 0x5C4

#endif
