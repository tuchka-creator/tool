#ifndef UE4SS_SDK_BP_LobbySaveGame_HPP
#define UE4SS_SDK_BP_LobbySaveGame_HPP

class UBP_LobbySaveGame_C : public USaveGame
{
    TArray<FS_LevelStats> EasyStats;                                                  // 0x0028 (size: 0x10)
    TArray<FS_LevelStats> NormalStats;                                                // 0x0038 (size: 0x10)
    TArray<FS_LevelStats> HardStats;                                                  // 0x0048 (size: 0x10)

}; // Size: 0x58

#endif
