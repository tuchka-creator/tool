#ifndef UE4SS_SDK_BP_Ambience_Manager_HPP
#define UE4SS_SDK_BP_Ambience_Manager_HPP

class ABP_Ambience_Manager_C : public AActor
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x0220 (size: 0x8)
    class USceneComponent* DefaultSceneRoot;                                          // 0x0228 (size: 0x8)
    class AAmbientSound* OutdoorAmbience;                                             // 0x0230 (size: 0x8)
    class AAmbientSound* IndoorAmbience;                                              // 0x0238 (size: 0x8)

    void ResetAmbience();
    void EnterHouse();
    void ExitHouse();
    void ExecuteUbergraph_BP_Ambience_Manager(int32 EntryPoint);
}; // Size: 0x240

#endif
