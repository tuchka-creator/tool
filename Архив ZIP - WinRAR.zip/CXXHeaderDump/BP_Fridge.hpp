#ifndef UE4SS_SDK_BP_Fridge_HPP
#define UE4SS_SDK_BP_Fridge_HPP

class ABP_Fridge_C : public AActor
{
    class UStaticMeshComponent* Fridge_door_R;                                        // 0x0220 (size: 0x8)
    class UStaticMeshComponent* Fridge_door_L;                                        // 0x0228 (size: 0x8)
    class UStaticMeshComponent* Fridge_door_freezer;                                  // 0x0230 (size: 0x8)
    class UStaticMeshComponent* Fridge_Body;                                          // 0x0238 (size: 0x8)
    class USceneComponent* DefaultSceneRoot;                                          // 0x0240 (size: 0x8)

}; // Size: 0x248

#endif
