#ifndef UE4SS_SDK_Bacteria_BP_HPP
#define UE4SS_SDK_Bacteria_BP_HPP

class ABacteria_BP_C : public ACharacter
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x04C0 (size: 0x8)
    class UFancyEntitySightingComponent* FancyEntitySighting;                         // 0x04C8 (size: 0x8)
    class USceneComponent* EyeSight;                                                  // 0x04D0 (size: 0x8)
    class USphereComponent* KillPlayer;                                               // 0x04D8 (size: 0x8)
    class UAudioComponent* Audio;                                                     // 0x04E0 (size: 0x8)
    bool ShouldMove;                                                                  // 0x04E8 (size: 0x1)
    int32 CurrentSpeedLevel;                                                          // 0x04EC (size: 0x4)
    bool CanTeleport;                                                                 // 0x04F0 (size: 0x1)
    int32 MinutesElapsed;                                                             // 0x04F4 (size: 0x4)
    class UBehaviorTree* Behavior Tree;                                               // 0x04F8 (size: 0x8)
    bool CanAttack;                                                                   // 0x0500 (size: 0x1)
    bool ShouldReset;                                                                 // 0x0501 (size: 0x1)
    FVector StartingLocation;                                                         // 0x0504 (size: 0xC)
    FTimerHandle ShakeTimer;                                                          // 0x0510 (size: 0x8)
    float CurrentSoundTime;                                                           // 0x0518 (size: 0x4)
    TArray<float> ShakeTimes;                                                         // 0x0520 (size: 0x10)
    FTimerHandle TimerHandle;                                                         // 0x0530 (size: 0x8)

    void CheckPlayersTimer();
    void CanSeePlayer(class ABPCharacter_Demo_C* Target, bool& CanSee);
    void CheckShakeTime();
    void ResetPosition();
    void StopMovement();
    void LookAtEntity(class ABPCharacter_Demo_C* Target);
    void GetClosestPlayer(class ABPCharacter_Demo_C*& Closest);
    void UpdateTeleport();
    void UpdateSpeed();
    void SetNewSpeed(int32 Count, float& NewSpeed);
    void CalcLookAtRotation(class AActor* MyActor, class AActor* Target);
    void ReceiveBeginPlay();
    void StartSound();
    void StopSound();
    void FaceClosestPlayer();
    void AttackPlayer(class ABPCharacter_Demo_C* Player);
    void MC_KillSound();
    void MC_KillAnimation();
    void SetupWorldShakes();
    void OnStateChanged(EAudioComponentPlayState PlayState);
    void BndEvt__Bacteria_BP_KillPlayer_K2Node_ComponentBoundEvent_0_ComponentBeginOverlapSignature__DelegateSignature(class UPrimitiveComponent* OverlappedComponent, class AActor* OtherActor, class UPrimitiveComponent* OtherComp, int32 OtherBodyIndex, bool bFromSweep, const FHitResult& SweepResult);
    void ExecuteUbergraph_Bacteria_BP(int32 EntryPoint);
}; // Size: 0x538

#endif
