#ifndef UE4SS_SDK_BP_PitfallsHint_Trigger_HPP
#define UE4SS_SDK_BP_PitfallsHint_Trigger_HPP

class ABP_PitfallsHint_Trigger_C : public ATriggerBox
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x0228 (size: 0x8)

    void BndEvt__BP_PitfallsHint_Trigger_CollisionComponent_K2Node_ComponentBoundEvent_0_ComponentBeginOverlapSignature__DelegateSignature(class UPrimitiveComponent* OverlappedComponent, class AActor* OtherActor, class UPrimitiveComponent* OtherComp, int32 OtherBodyIndex, bool bFromSweep, const FHitResult& SweepResult);
    void ExecuteUbergraph_BP_PitfallsHint_Trigger(int32 EntryPoint);
}; // Size: 0x230

#endif
