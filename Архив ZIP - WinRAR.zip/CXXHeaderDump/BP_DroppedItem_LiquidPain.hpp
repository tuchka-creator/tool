#ifndef UE4SS_SDK_BP_DroppedItem_LiquidPain_HPP
#define UE4SS_SDK_BP_DroppedItem_LiquidPain_HPP

class ABP_DroppedItem_LiquidPain_C : public ABP_DroppedItem_C
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x0270 (size: 0x8)
    class UStaticMeshComponent* StaticMesh1;                                          // 0x0278 (size: 0x8)
    class UStaticMeshComponent* StaticMesh;                                           // 0x0280 (size: 0x8)
    float Flicker_Intensity_3E1E3A82480AD561393A36ACF538BD22;                         // 0x0288 (size: 0x4)
    TEnumAsByte<ETimelineDirection::Type> Flicker__Direction_3E1E3A82480AD561393A36ACF538BD22; // 0x028C (size: 0x1)
    class UTimelineComponent* Flicker;                                                // 0x0290 (size: 0x8)
    class APointLight* Bulb;                                                          // 0x0298 (size: 0x8)

    void Flicker__FinishedFunc();
    void Flicker__UpdateFunc();
    void ReceiveBeginPlay();
    void ExecuteUbergraph_BP_DroppedItem_LiquidPain(int32 EntryPoint);
}; // Size: 0x2A0

#endif
