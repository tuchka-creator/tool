#ifndef UE4SS_SDK_BP_Destructible_HPP
#define UE4SS_SDK_BP_Destructible_HPP

class IBP_Destructible_C : public IInterface
{

    void Damage(class ACharacter* Character);
}; // Size: 0x28

#endif
