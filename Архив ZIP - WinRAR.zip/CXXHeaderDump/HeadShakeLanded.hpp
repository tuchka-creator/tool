#ifndef UE4SS_SDK_HeadShakeLanded_HPP
#define UE4SS_SDK_HeadShakeLanded_HPP

class UHeadShakeLanded_C : public UMatineeCameraShake
{
}; // Size: 0x1B0

#endif
