#ifndef UE4SS_SDK_BP_UnblockPlayerFlow_HPP
#define UE4SS_SDK_BP_UnblockPlayerFlow_HPP

class UBP_UnblockPlayerFlow_C : public UFancyUserFlow
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x00A8 (size: 0x8)
    FString PlayerName;                                                               // 0x00B0 (size: 0x10)
    class UWidget* PrevFocusedWidget;                                                 // 0x00C0 (size: 0x8)
    FBPUniqueNetId NetId;                                                             // 0x00C8 (size: 0x28)
    EFancyPlatform PlayerPlatform;                                                    // 0x00F0 (size: 0x1)

    void MakeExplanation(TArray<class UW_ReportPlayer_ReasonButton_C*>& SelectedReasonButtons, FString& Explanation);
    void ResetInputAndComplete();
    void Run();
    void UnblockPlayerComplete(bool bSuccess, const FBPUniqueNetId& NetId, FString Name);
    void PrepareModal(class UUserWidget* Modal);
    void OnComplete(class UUserWidget* Modal);
    void ExecuteUbergraph_BP_UnblockPlayerFlow(int32 EntryPoint);
}; // Size: 0xF1

#endif
