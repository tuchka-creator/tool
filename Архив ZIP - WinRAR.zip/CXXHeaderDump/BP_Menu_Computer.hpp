#ifndef UE4SS_SDK_BP_Menu_Computer_HPP
#define UE4SS_SDK_BP_Menu_Computer_HPP

class ABP_Menu_Computer_C : public AInteractablePawn
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x0308 (size: 0x8)
    class UWidgetComponent* Widget;                                                   // 0x0310 (size: 0x8)
    class UStaticMeshComponent* umbrella_id_card_03_Metal_01;                         // 0x0318 (size: 0x8)
    class UStaticMeshComponent* umbrella_id_card_03_Strap;                            // 0x0320 (size: 0x8)
    class UStaticMeshComponent* umbrella_id_card_03_Rectangle001;                     // 0x0328 (size: 0x8)
    class UStaticMeshComponent* umbrella_id_card_03_Metal_03;                         // 0x0330 (size: 0x8)
    class UStaticMeshComponent* umbrella_id_card_03_Metal_02;                         // 0x0338 (size: 0x8)
    class USceneComponent* Scene1;                                                    // 0x0340 (size: 0x8)
    class UWidgetInteractionComponent* WidgetInteraction2;                            // 0x0348 (size: 0x8)
    class UWidgetInteractionComponent* WidgetInteraction1;                            // 0x0350 (size: 0x8)
    class UWidgetInteractionComponent* WidgetInteraction;                             // 0x0358 (size: 0x8)
    class UWidgetComponent* Screen;                                                   // 0x0360 (size: 0x8)
    bool CanUse;                                                                      // 0x0368 (size: 0x1)
    bool UpdateLogin;                                                                 // 0x0369 (size: 0x1)
    class UNiagaraComponent* LeftBeam;                                                // 0x0370 (size: 0x8)
    class UNiagaraComponent* RightBeam;                                               // 0x0378 (size: 0x8)

    void Update Beam();
    void ToggleWidgetInteraction(bool Enable);
    void InpActEvt_Interact_K2Node_InputActionEvent_2(FKey Key);
    void InpActEvt_AnyKey_K2Node_InputKeyEvent_2(FKey Key);
    void InpActEvt_AnyKey_K2Node_InputKeyEvent_1(FKey Key);
    void InpActEvt_Use_K2Node_InputActionEvent_1(FKey Key);
    void InpActEvt_Use_K2Node_InputActionEvent_0(FKey Key);
    void InpActEvt_Escape_K2Node_InputKeyEvent_0(FKey Key);
    void ReceivePossessed(class AController* NewController);
    void OnPossess();
    void UnPossess();
    void InpAxisKeyEvt_MouseWheelAxis_K2Node_InputAxisKeyEvent_1(float AxisValue);
    void OnVRPossess(bool bPossess);
    void ToggleScreen(bool IsHidden);
    void ExecuteUbergraph_BP_Menu_Computer(int32 EntryPoint);
}; // Size: 0x380

#endif
