#ifndef UE4SS_SDK_BP_DroppedItem_HPP
#define UE4SS_SDK_BP_DroppedItem_HPP

class ABP_DroppedItem_C : public ADroppedItem
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x0258 (size: 0x8)
    class UWidgetComponent* Widget;                                                   // 0x0260 (size: 0x8)
    bool EnableForFocus;                                                              // 0x0268 (size: 0x1)

    void ExamineModeOn();
    void ExamineModeOff();
    void CollisionOn();
    void CollisionOff();
    void ReceiveBeginPlay();
    void OnEndFocus();
    void OnBeginFocus();
    void OnEventLoaded(uint8 EventType);
    void ToggleEvent(bool Enable);
    void ExecuteUbergraph_BP_DroppedItem(int32 EntryPoint);
}; // Size: 0x269

#endif
