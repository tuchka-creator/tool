#ifndef UE4SS_SDK_BacktraceBlueprintLibrary_HPP
#define UE4SS_SDK_BacktraceBlueprintLibrary_HPP

class UBacktraceBlueprintLibrary : public UBlueprintFunctionLibrary
{

    void Crash();
}; // Size: 0x28

#endif
