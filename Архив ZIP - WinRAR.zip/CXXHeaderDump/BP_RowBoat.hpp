#ifndef UE4SS_SDK_BP_RowBoat_HPP
#define UE4SS_SDK_BP_RowBoat_HPP

class ABP_RowBoat_C : public ABoatPawn
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x0328 (size: 0x8)
    class UBoxComponent* Collision3;                                                  // 0x0330 (size: 0x8)
    class UBoxComponent* Collision2;                                                  // 0x0338 (size: 0x8)
    class UBoxComponent* Collision1;                                                  // 0x0340 (size: 0x8)
    class UBoxComponent* Collision;                                                   // 0x0348 (size: 0x8)
    class UBoxComponent* Collision4;                                                  // 0x0350 (size: 0x8)
    class UStaticMeshComponent* StaticMesh5;                                          // 0x0358 (size: 0x8)
    class UStaticMeshComponent* StaticMesh4;                                          // 0x0360 (size: 0x8)
    class USkeletalMeshComponent* SkeletalMesh1;                                      // 0x0368 (size: 0x8)
    class UStaticMeshComponent* StaticMesh3;                                          // 0x0370 (size: 0x8)
    class UStaticMeshComponent* StaticMesh2;                                          // 0x0378 (size: 0x8)
    class USkeletalMeshComponent* SkeletalMesh;                                       // 0x0380 (size: 0x8)
    float Bob_Buoyancy_BBCAF16E44F03C8EA7F96D944744C90E;                              // 0x0388 (size: 0x4)
    TEnumAsByte<ETimelineDirection::Type> Bob__Direction_BBCAF16E44F03C8EA7F96D944744C90E; // 0x038C (size: 0x1)
    class UTimelineComponent* Bob;                                                    // 0x0390 (size: 0x8)
    float Timeline_2_Alpha_F29818AD45D576B700E4C888ABCA1273;                          // 0x0398 (size: 0x4)
    TEnumAsByte<ETimelineDirection::Type> Timeline_2__Direction_F29818AD45D576B700E4C888ABCA1273; // 0x039C (size: 0x1)
    class UTimelineComponent* Timeline_2;                                             // 0x03A0 (size: 0x8)
    TEnumAsByte<ETimelineDirection::Type> Timeline_1__Direction_A8B0AB574F32E48C188E48BD0302DAFF; // 0x03A8 (size: 0x1)
    class UTimelineComponent* Timeline_1;                                             // 0x03B0 (size: 0x8)
    float Timeline_0_X_72EF829B4333A04EF68203BDFCAE61CC;                              // 0x03B8 (size: 0x4)
    TEnumAsByte<ETimelineDirection::Type> Timeline_0__Direction_72EF829B4333A04EF68203BDFCAE61CC; // 0x03BC (size: 0x1)
    class UTimelineComponent* Timeline_0;                                             // 0x03C0 (size: 0x8)
    bool IsVisible;                                                                   // 0x03C8 (size: 0x1)
    class ABPCharacter_Demo_C* Player;                                                // 0x03D0 (size: 0x8)
    int32 LookAtActorSequenceCounter;                                                 // 0x03D8 (size: 0x4)
    FRotator PlayerCurrentRotation;                                                   // 0x03DC (size: 0xC)
    bool Looking;                                                                     // 0x03E8 (size: 0x1)
    bool CanMove;                                                                     // 0x03E9 (size: 0x1)
    float Offset;                                                                     // 0x03EC (size: 0x4)
    float BoatSwayMultiplier;                                                         // 0x03F0 (size: 0x4)
    float CameraSwayMultiplier;                                                       // 0x03F4 (size: 0x4)
    class A8_FFT_H_Ocean_Sim_C* Ocean;                                                // 0x03F8 (size: 0x8)
    FVector LastWaterZ;                                                               // 0x0400 (size: 0xC)
    bool DidPossess;                                                                  // 0x040C (size: 0x1)
    FVector TeleportLoc;                                                              // 0x0410 (size: 0xC)
    float Delta Seconds;                                                              // 0x041C (size: 0x4)
    float TurnRate;                                                                   // 0x0420 (size: 0x4)
    float MouseSensitivity;                                                           // 0x0424 (size: 0x4)

    void UpdateWaterLevel();
    void OnRep_DidPossess();
    float GetWaterWorldZ_0(FVector2D InLocation);
    float GetWaterWorldZ(FVector2D InLocation);
    void SetInput(bool Enabled);
    void OnRep_IsVisible();
    void Timeline_0__FinishedFunc();
    void Timeline_0__UpdateFunc();
    void Timeline_1__FinishedFunc();
    void Timeline_1__UpdateFunc();
    void Timeline_2__FinishedFunc();
    void Timeline_2__UpdateFunc();
    void Bob__FinishedFunc();
    void Bob__UpdateFunc();
    void InpActEvt_Interact_K2Node_InputActionEvent_0(FKey Key);
    void InpAxisEvt_LookUp_K2Node_InputAxisEvent_40(float AxisValue);
    void InpAxisEvt_Turn_K2Node_InputAxisEvent_47(float AxisValue);
    void InpAxisEvt_MoveForward_K2Node_InputAxisEvent_79(float AxisValue);
    void InpAxisEvt_MoveRight_K2Node_InputAxisEvent_90(float AxisValue);
    void ReceiveBeginPlay();
    void PlayScare();
    void StartSway();
    void PlayWarning();
    void Lookat2(class USkeletalMeshComponent* Mesh);
    void StartLookAt(FRotator StartRot, FRotator EndRot);
    void OnPossess();
    void ReceivePossessed(class AController* NewController);
    void UnPossess();
    void ReceiveUnpossessed(class AController* OldController);
    void FindLand();
    void OnQueryFinished(class UEnvQueryInstanceBlueprintWrapper* QueryInstance, TEnumAsByte<EEnvQueryStatus::Type> QueryStatus);
    void ResetDelay();
    void StartDelay();
    void StartBuoyancy();
    void StopBuoyancy();
    void InpAxisEvt_VRTurn_X_K2Node_InputAxisEvent_5(float AxisValue);
    void InpAxisEvt_VRTurn_Y_K2Node_InputAxisEvent_6(float AxisValue);
    void InpAxisEvt_VRMove_Y_K2Node_InputAxisEvent_7(float AxisValue);
    void InpAxisEvt_VRMove_X_K2Node_InputAxisEvent_8(float AxisValue);
    void InpAxisEvt_TurnRate_K2Node_InputAxisEvent_0(float AxisValue);
    void InpAxisEvt_LookUpRate_K2Node_InputAxisEvent_9(float AxisValue);
    void Turn(float Value);
    void LookUp(float Value);
    void ReceiveTick(float DeltaSeconds);
    void ExecuteUbergraph_BP_RowBoat(int32 EntryPoint);
}; // Size: 0x428

#endif
