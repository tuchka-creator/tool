#ifndef UE4SS_SDK_BP_DroppedItem_Crowbar_HPP
#define UE4SS_SDK_BP_DroppedItem_Crowbar_HPP

class ABP_DroppedItem_Crowbar_C : public ABP_DroppedItem_C
{
    class UStaticMeshComponent* StaticMesh;                                           // 0x0270 (size: 0x8)

}; // Size: 0x278

#endif
