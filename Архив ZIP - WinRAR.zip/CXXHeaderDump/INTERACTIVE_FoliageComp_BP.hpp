#ifndef UE4SS_SDK_INTERACTIVE_FoliageComp_BP_HPP
#define UE4SS_SDK_INTERACTIVE_FoliageComp_BP_HPP

class UINTERACTIVE_FoliageComp_BP_C : public UFoliageInstancedStaticMeshComponent
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x06B0 (size: 0x8)
    float Trample_BendAngle_WEIGHT;                                                   // 0x06B8 (size: 0x4)
    float Trample_Z-Scale_WEIGHT;                                                     // 0x06BC (size: 0x4)
    float Trample_BendDuration_MULTIPLIER;                                            // 0x06C0 (size: 0x4)
    float BendAway_Angle_WEIGHT;                                                      // 0x06C4 (size: 0x4)
    float BendAway__Z-Scale_WEIGHT;                                                   // 0x06C8 (size: 0x4)
    float BendAway_Duration_MULTIPLIER;                                               // 0x06CC (size: 0x4)
    class AInteractiveGrassManager_BP_C* Manager;                                     // 0x06D0 (size: 0x8)
    TArray<int32> trampledInstances;                                                  // 0x06D8 (size: 0x10)
    float UnDeformSpeed;                                                              // 0x06E8 (size: 0x4)
    float UnDeformSpeedWhenTrampled;                                                  // 0x06EC (size: 0x4)
    FINTERACTIVE_FoliageComp_BP_CUnloadedViaStreaming UnloadedViaStreaming;           // 0x06F0 (size: 0x10)
    void UnloadedViaStreaming();
    float chunkSize_;                                                                 // 0x0700 (size: 0x4)
    bool okToChunk;                                                                   // 0x0704 (size: 0x1)
    FVector upperLeftBBoxCorner;                                                      // 0x0708 (size: 0xC)
    float upperLeftCorner_X;                                                          // 0x0714 (size: 0x4)
    float upperLeftCorner_Y;                                                          // 0x0718 (size: 0x4)
    float upperLeftCorner_Z;                                                          // 0x071C (size: 0x4)
    int32 X;                                                                          // 0x0720 (size: 0x4)
    int32 chunkAmount_X;                                                              // 0x0724 (size: 0x4)
    int32 chunkAmount_Y;                                                              // 0x0728 (size: 0x4)
    int32 I;                                                                          // 0x072C (size: 0x4)
    int32 J;                                                                          // 0x0730 (size: 0x4)
    TArray<class UINTERACTIVE_FoliageComp_BP_C*> chunkedComponents;                   // 0x0738 (size: 0x10)
    int32 quarterOfInstances;                                                         // 0x0748 (size: 0x4)
    int32 chunkNrX;                                                                   // 0x074C (size: 0x4)
    int32 chunkNrY;                                                                   // 0x0750 (size: 0x4)
    FTransform Transform;                                                             // 0x0760 (size: 0x30)
    TMap<int32, FInstanceData> InstanceData;                                          // 0x0790 (size: 0x50)
    float DeformingOptimization;                                                      // 0x07E0 (size: 0x4)
    TArray<FTransform> TEMP_InstancesToAdd;                                           // 0x07E8 (size: 0x10)

    void Start New Instance Offset(int32 Instance, FVector NewOffset, float DeformDuration, float UnDeformSpeed, bool UpdateComponent, float IgnoreIfGrowing);
    void ForceMarkDirty();
    void GetCurrentInstanceUN-DeformAlpha(int32 InstanceIndex, bool& hasInstanceData, float& CurrentAlpha);
    void GetCurrentInstanceGPU_Offset(int32 InstanceIndex, bool AtSpecifiedAlpha, float SpecifiedAlpha, FVector& CurrentOffset);
    void GetCurrentInstanceDeformAlpha(int32 InstanceIndex, bool& hasInstanceData, float& CurrentAlpha);
    void Copy&SetFoliageParameters_FromClass(TSubclassOf<class UINTERACTIVE_FoliageComp_BP_C> copyFrom, class UStaticMesh* meshToSet);
    void Copy&SetFoliageParameters(class UINTERACTIVE_FoliageComp_BP_C* copyFrom);
    void RemoveAnyActiveStatuses(int32 InstanceIndex);
    void IsTrampled?(int32 InstanceIndex, bool& ?);
    void RemoveInstanceStatus(int32 InstanceIndex, TEnumAsByte<InstanceStatus::Type> Status);
    void AddInstanceStatus(int32 InstanceIndex, TEnumAsByte<InstanceStatus::Type> Status);
    void ReceiveBeginPlay();
    void ReceiveEndPlay(TEnumAsByte<EEndPlayReason::Type> EndPlayReason);
    void DivideIntoChunks_InfLoopWorkaround(float chunkSize);
    void ExecuteUbergraph_INTERACTIVE_FoliageComp_BP(int32 EntryPoint);
    void UnloadedViaStreaming__DelegateSignature();
}; // Size: 0x7F8

#endif
