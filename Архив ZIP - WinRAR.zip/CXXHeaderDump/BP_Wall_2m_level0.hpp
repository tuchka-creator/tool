#ifndef UE4SS_SDK_BP_Wall_2m_level0_HPP
#define UE4SS_SDK_BP_Wall_2m_level0_HPP

class ABP_Wall_2m_level0_C : public AActor
{
    class USceneComponent* DefaultSceneRoot;                                          // 0x0220 (size: 0x8)

}; // Size: 0x228

#endif
